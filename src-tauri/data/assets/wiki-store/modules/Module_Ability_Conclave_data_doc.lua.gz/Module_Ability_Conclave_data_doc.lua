{{Archived|Currently unused on the wiki.}}
Data store for [[Conclave]] ability data.
[[Category:Databases]]