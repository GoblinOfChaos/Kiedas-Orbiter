{{UpdateMe|Add [[Railjack]] abilities like [[Phoenix Blaze]]}}
Database of abilities in [[WARFRAME]].
{{LatestEdit}}
__TOC__
==Ability Entry Schema==
<syntaxhighlight lang="lua">
	["Ability Name"] = {
		CardImage = "CardImageName.png",
		Cost = 100,
		CostType = "Mutation",
		Description = "In-game ability description",
		Icon = "AbilityIcon.png",
  		InternalName = "/Lotus/Powersuits/PowersuitAbilities/",
		Introduced = "29",
		Key = 4,
		Link = "Page Name",
		Name = "Ability Name",
		Powersuit = "Warframe/Necramech/Archwing Name",
		Preview = "AbilityPreview.webm",
		PreviewFallback = "AbilityPreview.jpg",
		Subsumable = false,
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Augments</code> || Table (of strings) || ❌ || List of augment mods names associated with ability || <code>{ "Chromatic Blade" }</code>
|-
| <code>CardImage</code> || String || ✔️ || Image file name of the ability card as uploaded to the wiki || <code>"AirburstModU15.png"</code>
|-
| <code>Cost</code> || Number (int) || ✔️ || Cost for casting the abiltiy ( most of the time [[Energy]]) , used in conjonction with ''CostType''|| <code>50</code>
|-
| <code>CostType</code> || Type (String) || ❌ || Alternate Cost for casting an ability . Ex :  [[File:MutationGauge.png|20px|link=Mutation]][[Mutation]] for {{WF|Nidus|Nidus'}} {{A|Ravenous}} . Defined in [[Module:Ability/infobox]]|| <code>Mutation</code>
|-
| <code>Description</code> || String || ✔️ || In-game description of ability || <code>"Nyx absorbs all incoming damage and channels that collected energy into an explosive radial discharge. Nyx's Weapon damage is buffed based on incoming absorbed damage when the Ability ends."</code>
|-
| <code>Icon</code> || String || ✔️ || Image file name of the ability icon as uploaded to the wiki; icon must be in black || <code>"Airburst130xDark.png"</code>
|-
| <code>InternalName</code> || String || ✔️ || The full unique name of an ability formatted as a file path || <code>"/Lotus/Powersuits/PowersuitAbilities/HelminthStrengthAbility"</code>
|-
| <code>Introduced</code> || String || ✔️ || The game version in which the ability was first introduced in the global build of [[WARFRAME]]. <code>Introduced</code> keys can be cross-referenced with [[Module:Warframes/data]], but note that some abilities were introduced later on with Warframe reworks or are not associated with an individual Warframe at all (e.g. [[Helminth]] abilities). || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Key</code> || Number (int) || ✔️ || Default [[Key Bindings|key binding]] on PC for ability || <code>4</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the ability on the wiki || <code>"Amp (Ability)"</code>
|-
| <code>Name</code> || String || ✔️ || Name of ability || <code>"Amp"</code>
|-
| <code>Powersuit</code> || String || ✔️ || Name of player avatar that comes with ability by default; for [[Helminth]] abilities put in "Helminth" || <code>"Excalibur"</code> or <code>"Helminth"</code>
|-
| <code>Preview</code> || String || ❌ || Video file name of the ability preview as uploaded to the wiki. Should use .webm for smaller file sizes. || <code>"AirburstPreview.webm"</code>
|-
| <code>PreviewFallback</code> || String || ❌ || Image file name of the ability preview as uploaded to the wiki. This is for fallback in case preview video doesn't load || <code>"AirburstPreview.jpg"</code>
|-
| <code>Subsumable</code> || Boolean || ❌ || For abilities that can be injected into other Warframes through [[Helminth]] || <code>true</code>
|-
|}

==Ability Data==
[[Category:Databases]]