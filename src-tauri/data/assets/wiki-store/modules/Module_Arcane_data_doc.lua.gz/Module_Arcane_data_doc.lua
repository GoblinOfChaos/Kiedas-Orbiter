Database of [[Arcane Enhancement]]s.
__TOC__
{{LatestEdit}}
==Arcane Entry Schema==
<syntaxhighlight lang="lua">
	["Arcane Name"] = {
		CodexSecret = true,
		Description = "Description",
		Dissolution = 20,
		Icon = "ArcaneIcon.png",
		Image = "ArcaneImage.png",
		Introduced = "29",
		IsRefreshable = true,
		Link = "Page Name",
		MaxRank = 5,
		Name = "Arcane Name",
		Rarity = "Rare",
		Type = "Primary",
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! [[Arsenal]] EN L10n !! [[Public Export]] Equivalent !! Internal Equivalent !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>CodexSecret</code> || N/A || <code>codexSecret</code> || <code>CodexSecret</code> || Boolean || ✔️ || Whether or not the Arcane has an entry in the [[Codex]] before the player acquires it; defaults to true || <code>true</code>
|-
| <code>CompatibilityTags</code> || N/A || N/A || <code>CompatibilityTags</code> || Table (array of strings) || ❌ || Tags that denote item compatibility. In other words, an item with one these tags can have this particular Arcane installed. || <code>{ "POWER_WEAPON" }</code>
|-
| <code>Description</code> || N/A || <code>levelStats</code> || <code>EnhancementTag</code> || String || ✔️ || Description of arcane at max rank || <code>"3% chance for +30% Shield Recharge for 12s"</code>
|-
| <code>Dissolution</code> || N/A || N/A || N/A || Number (integer) || ✔️ || Amount of [[Vosfor]] for [[Arcane Dissolution]] || <code>20</code>
|-
| <code>Icon</code> || N/A || N/A || N/A || String || ✔️ || Image file name of the resized arcane image to x64 as uploaded to the wiki || <code>"ArcaneAegis64x.png"</code>
|-
| <code>Image</code> || N/A || <code>textureLocation</code> || <code>Icon</code> || String || ✔️ || Image file name of the arcane as uploaded to the wiki || <code>"ArcaneAegis.png"</code>
|-
| <code>IncompatibilityTags</code> || N/A || N/A || <code>IncompatibilityTags</code> || Table (array of strings) || ❌ || Tags that denote item incompatibility. In other words, items with these tags cannot have this particular Arcane installed. || <code>{ "OPERATOR_SUIT" }</code>
|-
| <code>InternalName</code> || N/A || <code>uniqueName</code> || <code>TypeName</code> || String || ❌ || The full unique name of an arcane formatted as a file path || <code>"/Lotus/Upgrades/CosmeticEnhancers/Offensive/LongGunSpeedOnCrit"</code>
|-
| <code>Introduced</code> || N/A || N/A || N/A || String || ✔️ || The game version in which the arcane was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>IsRefreshable</code> || N/A || N/A || <code>CanReproc</code> || Boolean || ✔️ || Whether or not the arcane's effect(s) are refreshable in duration while active || <code>true</code>
|-
| <code>Link</code> || N/A || N/A || N/A || String || ✔️ || Page/article link to the arcane on the wiki || <code>"Arcane Energize"</code>
|-
| <code>MaxRank</code> || N/A || N/A || <code>FusionLimit</code> || Number (integer) || ✔️ || Maximum rank that arcane can be upgraded to || <code>5</code>
|-
| <code>Name</code> || N/A || <code>name</code> || <code>LocalizeTag</code> || String || ✔️ || Name of arcane || <code>"Arcane Energize"</code>
|-
| <code>Rarity</code> || N/A || <code>rarity</code> || <code>Rarity</code> || String || ✔️ || Rarity of the arcane || <code>"Legendary"</code>
|-
| <code>Type</code> || N/A || N/A || <code>ItemCompatibility</code> || String || ✔️ || The class of items that the arcane can be equipped on || <code>"Warframe"</code>
|-
| <code>UpgradeTypes</code> || N/A || N/A || <code>UpgradeType</code> || String || ❌ || Upgrade tags associated with the Arcane for categorization and to reflect the specific internal bonus it adds (sometimes localized description does not explain full functionality). Arcanes whose functionality are derived from Lua scripts (i.e. complex/unorthodox behavior) will not have this key set. This key is solely for Arcanes that provide simple stat bonuses. || <code>GAMEPLAY_FACTION_DAMAGE</code>
|-
|}

==Data Validation==
===Checking for required keys===
{{Column|3|
{{#invoke:Arcane/data/validate|checkRequiredKeysExist}}
}}

===Validating data types of values===
{{Column|3|
{{#invoke:Arcane/data/validate|validateDataTypes}}
}}

[[Category:Databases]]