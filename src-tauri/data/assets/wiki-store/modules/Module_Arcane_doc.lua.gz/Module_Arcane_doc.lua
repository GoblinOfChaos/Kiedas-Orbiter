<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Module ===
<syntaxhighlight lang="lua">
local p = {}
local Arcane = require('Module:Arcane')

local function func(arcaneName, valName)
    return Arcane._getValue(arcaneName, valName)
end
</syntaxhighlight>
}}</onlyinclude>