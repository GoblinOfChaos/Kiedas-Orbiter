Database for [[WARFRAME]]'s depreciated [[Avionics]] system (since {{ver|29.10}}).
[[Category:Databases]]