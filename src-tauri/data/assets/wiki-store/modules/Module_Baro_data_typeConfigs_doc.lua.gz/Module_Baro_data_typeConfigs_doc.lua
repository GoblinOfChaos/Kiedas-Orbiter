Configuration file for categorizing and formatting item names in [[Module:Baro]].
{{LatestEdit}}
__TOC__
==Notes==
* '''Consistency''': Keys (e.g., "Booster", "Primed Mod (Warframe)") must exactly match the <code>Type</code> field in [[Module:Baro/data]] (case-sensitive).
* '''GalleryCategory''': Determines which tab the item appears in [[Baro Ki'Teer/Current PC Items]].
* '''HistoryCategory''': Determines which tab the item appears in [[Baro Ki'Teer/Trades]].
* '''TooltipModule''': Specifies the module name used to fetch and format the item's custom display with icons and tooltips (e.g., <code>Void</code> will display as {{#invoke:Tooltips|full|Axi A2|Void|r=Axi A2 Relic}}).



==Config Schema==
<syntaxhighlight lang="lua">
	["Item Type"] = {
		GalleryCategory = "Appearance",
		HistoryCategory = "Cosmetic",
		TooltipModule = "Cosmetics"
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type !! Required? !! Explanation/Description !! Example(s)
|-
| <code>GalleryCategory</code> || String || ✔️ || Defines the tab grouping for <code>buildGallery</code> via <code>buildTabbers</code>. || <code>"Miscellaneous"</code>
|-
| <code>HistoryCategory</code> || String || ✔️ || Defines the tab grouping for <code>buildHistoryTable</code> via <code>buildTabbers</code>. || <code>"Relic"</code>
|-
| <code>TooltipModule</code> || String || ❌ || The database key configured in [[Module:Tooltips/icon]] used to fetch corresponding data and icons (e.g., <code>"Void"</code>, <code>"Weapons"</code>, <code>"Cosmetics"</code>). || <code>"Void"</code>
|-
|}

==Configuration Data==
[[Category:Databases]]