Contents of [[Module:Baro/data]] indexed by dates, with each table entry containing the items that Baro has offered on a particular visit. <code>ConsoleBaroVisits</code> subtable will contain all Baro visits on console while <code>PCBaroVisits</code> will contain all Baro visits on PC. <code>TennoConBaroVisits</code> will contain all Baro visits on the [[TennoCon]] relay during TennoCon.
__TOC__
==Data==
Automatically generated based on [[Module:Baro/data]]:
{{#invoke:LuaSerializer|serialize|Baro/data/visits}}

==Code==