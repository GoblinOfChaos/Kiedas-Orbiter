<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Template ===
In template: <code><nowiki>{{#invoke:Baro|__main}}</nowiki></code><br />
In articles: <code><nowiki>{{template|function|input1|input2|...}}</nowiki></code>

== Product Backlog ==
{{(!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Last Update
{{!}}-

{{!)}}

==Finished Issues==
{{(!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Last Update
{{!}}-
{{ProjectTableRow
|name=New <code>Visits</code> subtable
|type=Dev
|status=Completed
|priority=Low
|contact=[[User:Cephalon Scientia]]
|desc=Add a new subtable to <code>/data</code> that uses Baro visit dates to access table entries. Each entry would represent a Baro visit and contain the names of items that were available to be purchased on both PC and Console. Ignore evergreen offerings like Inaros' quest and Fae Step Ephemera.

18:27, 30 October 2021 (UTC) update: Table is automatically generated through [[Module:Baro/data/visits]] instead of being a subtable in [[Module:Baro/data]].
|start=05:56, 19 July 2021 (UTC)
|end=[https://warframe.fandom.com/wiki/Module:Baro/data/visits?oldid=2237664 05:25, 23 October 2021 (UTC)]
}}
{{!)}}

}}</onlyinclude>