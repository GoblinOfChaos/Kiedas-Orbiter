{{UpdateMe}}
Database for blueprint recipes. Includes crafting requirements for [[Railjack]] armaments. Used on [[Template:BuildRequire]] and [[Template:BuildAutomatic]] through [[Module:Tooltips]].

Costs for Dojo [[Decorations]] can be found in [[Module:Decorations/data]] instead.
{{LatestEdit}}
==Blueprint Entry Schema==
<syntaxhighlight lang="lua">
	["Item Name"] = {
		Credits = 25000,
		InternalName = "/Lotus/Types/Recipes/ItemNameBlueprint",
		MarketCost = 240,
		Name = "Blueprint Name",
		Parts = {
			{ Count = 5, Name = "Neurodes", Type = "Resource" },
			{ Count = 2000, Name = "Hexenon", Type = "Resource" },
			{ Count = 925, Name = "Plastids", Type = "Resource" },
			{ Count = 8000, Name = "Nano Spores", Type = "Resource" } 
		},
		Result = "Item Name",
		Rush = 10,
		Time = 6 
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>BPCost</code> || Number (int) || ❌ || The [[Credits]] cost for buying the blueprint from the [[Market]] || <code>35000</code>
|-
| <code>Credits</code> || Number (int) || ✔️ || The [[Credits]] cost for crafting the item || <code>25000</code>
|-
| <code>InternalName</code> || String || ❌ || The full unique name of a blueprint formatted as a file path || <code>"/Lotus/Types/Recipes/WarframeRecipes/MummyBlueprint"</code>
|-
| <code>Introduced</code> || String || ❌ || The game version in which the blueprint was first introduced in the global build of [[WARFRAME]]. Optional since other item databases may include that information. || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || String || ❌ || Page/article link to the blueprint on the wiki || <code>"Ack & Brunt"</code>
|-
| <code>MarketCost</code> || Number (int) || ❌ || The [[Platinum]] cost of buying the item directly from the [[Market]] || <code>500</code>
|-
| <code>Name</code> || String || ✔️ || Name of blueprint || <code>"Ack & Brunt Blueprint"</code>
|-
| <code>Parts</code> || Table (of tables) || ✔️ || A table containing the crafting components used to build the item || <pre>
{
	{ Count = 4, Name = "Neurodes", Type = "Resource" },
	{ Count = 1200, Name = "Alloy Plate", Type = "Resource" },
	{ Count = 700, Name = "Ferrite", Type = "Resource" },
	{ Count = 1000, Name = "Polymer Bundle", Type = "Resource" } 
}
</pre>
|-
| <code>Result</code> || String || ✔️ || Name of item that the blueprint is for || <code>"Ack & Brunt"</code>
|-
| <code>Rush</code> || Number (int) || ✔️ || The base [[Platinum]] cost to skip the build time || <code>35</code>
|-
| <code>Time</code> || Number (int) || ✔️ || The time in seconds to build an item. Some important values for quick reference:
*60 = 1 minute
*300 = 5 minutes
*3600 = 1 hour
*43200 = 12 hours
*82800 = 23 hours
*86400 = 24 hours
*259200 = 72 hours (3 days)
| <code>60</code>
|-
| <code>Type</code> || String || ✔️ || The item's category || <code>"Warframe"</code>
|-
|}

==Templates==
For copying and pasting:
===Generic Item===
<syntaxhighlight lang="lua">
		["Item Name"] = {
			Name = "Item Name Blueprint",
			Result = "Item Name",
			Credits = 35000,
			Parts = {
				{ Count = 1, Name = "Morphics", Type = "Resource" },
				{ Count = 1, Name = "Neural Sensors", Type = "Resource" },
				{ Count = 1, Name = "Neurodes", Type = "Resource" },
				{ Count = 1, Name = "Orokin Cell", Type = "Resource" }
			},
			Rush = 10,
			Time = 82800 
		},
</syntaxhighlight>

===New Warframe===
<syntaxhighlight lang="lua">
		Warframe = {
			BPCost = 35000,
			Credits = 25000,
			MarketCost = 275,
			Name = "Warframe Blueprint",
			Parts = {
				{ Count = 1, Name = "Neuroptics", Type = "Item" },
				{ Count = 1, Name = "Chassis", Type = "Item" },
				{ Count = 1, Name = "Systems", Type = "Item" },
				{ Count = 1, Name = "Orokin Cell", Type = "Resource" } 
			},
			ProductCategory = "Suits",
			Result = "Warframe",
			Rush = 50,
			Time = 259200 
		},
		["Warframe Chassis"] = {
			Credits = 15000,
			Name = "Warframe Chassis Blueprint",
			Parts = {
				{ Count = 200, Name = "Oxium", Type = "Resource" },
				{ Count = 900, Name = "Nano Spores", Type = "Resource" },
				{ Count = 50, Name = "Rubedo", Type = "Resource" },
				{ Count = 1, Name = "Orokin Cell", Type = "Resource" } 
			},
			ProductCategory = "Suits",
			Result = "Warframe Chassis",
			Rush = 25,
			Time = 43200 
		},
		["Warframe Neuroptics"] = {
			Credits = 15000,
			Name = "Warframe Neuroptics Blueprint",
			Parts = {
				{ Count = 150, Name = "Circuits", Type = "Resource" },
				{ Count = 200, Name = "Oxium", Type = "Resource" },
				{ Count = 200, Name = "Polymer Bundle", Type = "Resource" },
				{ Count = 500, Name = "Salvage", Type = "Resource" } 
			},
			ProductCategory = "Suits",
			Result = "Warframe Neuroptics",
			Rush = 25,
			Time = 43200 
		},
		["Warframe Systems"] = {
			Credits = 15000,
			Name = "Warframe Systems Blueprint",
			Parts = {
				{ Count = 1, Name = "Control Module", Type = "Resource" },
				{ Count = 200, Name = "Oxium", Type = "Resource" },
				{ Count = 500, Name = "Polymer Bundle", Type = "Resource" },
				{ Count = 400, Name = "Plastids", Type = "Resource" } 
			},
			ProductCategory = "Suits",
			Result = "Warframe Systems",
			Rush = 25,
			Time = 43200 
		},
</syntaxhighlight>

===New Prime Warframe===
<syntaxhighlight lang="lua">
		["Warframe Prime"] = {
			Credits = 25000,
			Name = "Warframe Prime Blueprint",
			Parts = {
				{ Count = 1, Name = "Prime Neuroptics", Type = "Item" },
				{ Count = 1, Name = "Prime Chassis", Type = "Item" },
				{ Count = 1, Name = "Prime Systems", Type = "Item" },
				{ Count = 5, Name = "Orokin Cell", Type = "Resource" } 
			},
			ProductCategory = "Suits",
			Result = "Warframe Prime",
			Rush = 50,
			Time = 259200 
		},
		["Warframe Prime Chassis"] = {
			Credits = 15000,
			Name = "Warframe Prime Chassis Blueprint",
			Parts = {
				{ Count = 200, Name = "Oxium", Type = "Resource" },
				{ Count = 900, Name = "Nano Spores", Type = "Resource" },
				{ Count = 50, Name = "Rubedo", Type = "Resource" },
				{ Count = 1, Name = "Orokin Cell", Type = "Resource" } 
			},
			ProductCategory = "Suits",
			Result = "Warframe Prime Chassis",
			Rush = 25,
			Time = 43200 
		},
		["Warframe Prime Neuroptics"] = {
			Credits = 15000,
			Name = "Warframe Prime Neuroptics Blueprint",
			Parts = {
				{ Count = 150, Name = "Circuits", Type = "Resource" },
				{ Count = 200, Name = "Oxium", Type = "Resource" },
				{ Count = 200, Name = "Polymer Bundle", Type = "Resource" },
				{ Count = 500, Name = "Salvage", Type = "Resource" } 
			},
			ProductCategory = "Suits",
			Result = "Warframe Prime Neuroptics",
			Rush = 25,
			Time = 43200 
		},
		["Warframe Prime Systems"] = {
			Credits = 15000,
			Name = "Warframe Prime Systems Blueprint",
			Parts = {
				{ Count = 1, Name = "Control Module", Type = "Resource" },
				{ Count = 200, Name = "Oxium", Type = "Resource" },
				{ Count = 500, Name = "Polymer Bundle", Type = "Resource" },
				{ Count = 400, Name = "Plastids", Type = "Resource" } 
			},
			ProductCategory = "Suits",
			Result = "Warframe Prime Systems",
			Rush = 25,
			Time = 43200 
		},
</syntaxhighlight>

==Collections==
Data store has two collections:
*<code>Suits</code> - Warframe blueprints and component blueprints
*<code>Blueprints</code> - everything else

==Data==
[[Category:Databases]]