<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Source ==
For more documentation and original source see https://www.wowace.com/projects/libcompress
}}
</onlyinclude>