{{UpdateMe|Once [[Module:Enemies/data]] is populated, can probably make this module store a subset of that data for relevant Codex information.

Also include [[Synthesis]] information.
}}
Database for [[Codex]] entries. There are 2 lists (Enemy and Object) and entries will be displayed in the order found here, so add new ones in the correct place!

==Codex Entry Schema==
<syntaxhighlight lang="lua">
		["Codex Entry Name"] = {
			FlipImage = false,
			Image = "ImageName.png",
			Name = "Codex Entry Name",
			Section = "Grineer" 
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>FlipImage</code> || Boolean || ❌ || Reflect wiki uploaded image across vertical axis to match in-game Codex representation || <code>true</code>
|-
| <code>Image</code> || String || ✔️ || Image file name of the item as uploaded to the wiki || <code>"002-ER.png"</code>
|-
| <code>Name</code> || String || ✔️ || Name of item || <code>"002-ER"</code>
|-
| <code>Section</code> || String || ✔️ || The tab the entry appears on in-game || <code>"Grineer"</code>
|-
|}

==Codex Data==
[[Category:Databases]]