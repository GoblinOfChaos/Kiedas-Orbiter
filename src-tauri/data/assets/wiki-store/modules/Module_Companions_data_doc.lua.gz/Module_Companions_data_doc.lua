Database for [[WARFRAME]]'s [[companions]] (pets).
{{LatestEdit}}
==Companion Entry Schema==
<syntaxhighlight lang="lua">
	["Companion Name"] = {
		Armor = 100,
		Description = "Description",
		Health = 100,
		Image = "CompanionName.png",
		InternalName = "",
		Introduced = "29",
		Link = "Page Name",
		MaxRank = 30,
		Name = "Companion Name",
		Polarities = { "Penjaga", "Penjaga", "Penjaga", "Penjaga" },
		SellPrice = 5000,
		Shield = 100,
		SquadPortrait = "CompanionNameLargePortrait.png",
		Type = "Kubrow",
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! [[Public Export]] Equivalent !! Internal Equivalent !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Armor</code> || <code>armor</code> || <code>ArmourRatingOverride</code> || Number (integer) || ✔️ || Companion's base [[Armor]] at Rank 0 || <code>100</code>
|-
| <code>CompatibilityTags</code> || N/A || <code>CompatibilityTags</code> || Table (array of strings) || ❌ || Tags that denote item compatibility. In other words, items with these tags can/cannot have a particular mod installed with the same tag. || <code>{ "HELMINTH_MOD" }</code>
|-
| <code>Description</code> || <code>description</code> || <code>LocalizeDescTag</code> || String || ✔️ || Description of companion as seen in-game || <code>"Piercing eyes reflect deadly instincts."</code>
|-
| <code>Health</code> || <code>health</code> || <code>MaxHealthOverride</code> || Number (integer) || ✔️ || Companion's base [[Health]] at Rank 0 || <code>100</code>
|-
| <code>Image</code> || <code>textureLocation</code> || <code>Icon</code> || String || ✔️ || Image file name of the companion as uploaded to the wiki || <code>"SmeetaKavat.png"</code>
|-
| <code>InternalName</code> || <code>uniqueName</code> || <code>TypeName</code> || String || ✔️ || The full unique name of the companion formatted as a file path || <code>"/Lotus/Types/Game/CatbrowPet/MirrorCatbrowPetPowerSuit"</code>
|-
| <code>Introduced</code> || N/A || N/A || String || ✔️ || The game version in which the companion was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || N/A || N/A || String || ✔️ || Page/article link to the companion on the wiki || <code>"Shade/Prisma"</code>
|-
| <code>MaxRank</code> || N/A || <code>LevelCap</code> || Number (integer) || ❌ || The maximum rank that they can level up to || <code>30</code>
|-
| <code>Name</code> || <code>name</code> || <code>LocalizeTag</code> || String || ✔️ || Name of companion || <code>"Prisma Shade"</code>
|-
| <code>Polarities</code> || N/A || <code>ArtifactSlots</code> || Table (array of strings) || ✔️ || Full names of the companion's non-Universal [[polarity|polarities]] || <code>{ "Naramon", "Madurai" }</code>
|-
| <code>SellPrice</code> || N/A || <code>SellingPrice</code> || Number (integer) || ❌ || For sellable companions, the sell price in [[Credits]] when removed from the player's inventory || <code>100</code>
|-
| <code>Shield</code> || <code>shield</code> || <code>MaxShieldOverride</code> || Number (integer) || ✔️ || Companion's base [[Shield]] at Rank 0 || <code>100</code>
|-
| <code>SquadPortrait</code> || N/A || N/A || String || ✔️ || Squad icon image file name of Companion/Avatar as uploaded to the wiki || <code>"AdarzaKavatLargePortrait.png"</code>
|-
| <code>Type</code> || N/A || N/A || String || ✔️ || The class of companion (e.g. "Kubrow", "Kavat", "MOA", "Vulpaphyla", "Predasite", "Hound") || <code>"Hound"</code>
|-
|}

==Companion Data==
[[Category:Databases]]