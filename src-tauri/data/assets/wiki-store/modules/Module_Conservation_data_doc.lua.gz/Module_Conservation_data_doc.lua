__TOC__
Hey! You! Here to update something that's out of date? Follow these easy steps:
#Use <code>CTRL+F</code> to find the data for the animal
#Find the thing that's wrong
#Change the thing and save the page
That's it! After you've done that, the data will proliferate out to all the relevant pages.

If you're adding new data instead of just changing existing data, try to use an example of how things are entered if you're not quite sure what to do.

(Oh, order doesn't matter, but spelling and capitalization do. For example, it doesn't matter if Disposition is first or last)

Thanks, you're awesome!

{{LatestEdit}}
==Animal Entry Schema==
<syntaxhighlight lang="lua">
["Animal Name"] = {
    Family = "Species Name",
    Introduced = "29.0",
    Codex = "A shy, bizarre-looking, semi-aquatic creature that seldom attacks unless provoked.",
    CodexScans = 20,
    Quotes = {
    	Quote1 = { 
            Quote = "A Quote about the animal.",
            Quotee = "A Guy"
        },
    	Quote2 = { 
            Quote = "A second Quote about the animal.",
            Quotee = "Another Guy"
        }
    },
    Image ="UmberUndazoa.png",
    Call = "PobberCall.ogg",
    Intro = "A Text shown above the Table of Rewards. Used to emphasis important Quirks of the Animal",
    Notes = "A Text shown below the Table of Rewards. Used to show minor Quirks of the Animal.",
    Reward = "The Main Reward you get, usually a specific standing",
    Standing = "How much standing you get for a bad capture",
    MinWeight = "1 kg",
    MaxWeight = "1000 kg",
    MinAge = { Month = 3, Year = 0 },
    MaxAge = { Month = 11, Year = 50},
    Origin = "Cambion Drift",
    Faction = "Prey"
}
</syntaxhighlight>
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Armor</code> || Number (integer) || ✔️ || [[Armor]] value of animal || <code>50</code>
|-
| <code>Call</code> || String || ✔️ || The file name of the call of the animal as stored on the wiki || <code>"PobberCall.ogg"</code>
|-
| <code>Codex</code> || String || ✔️ || The [[Codex]] entry of the animal || <code>"A shy, bizarre-looking, semi-aquatic creature that seldom attacks unless provoked."</code>
|-
| <code>CodexScans</code> || Number (integer) || ✔️ || The number of Codex scans needed to complete its entry || <code>20</code>
|-
| <code>Faction</code> || String || ✔️ || The faction, specified in the Codex entry of the animal || <code>"Prey"</code>
|-
| <code>Family</code> || String || ✔️ || Name of the species || <code>"Pobber"</code> or <code>"Vulpaphyla"</code> 
|-
| <code>Health</code> || Number (integer) || ✔️ || [[Health]] value of animal || <code>1</code>
|-
| <code>Introduced</code> || String || ✔️ || The version-number the animal got introduced || <code>"30.5"</code> or <code>"Specters Of The Rail"</code>
|-
| <code>Image</code> || String || ✔️ || The file name of the image of the animal as stored on the wiki || <code>"CommonPobber.png"</code>
|-
| <code>Intro</code> || String || ✔️ || Text displayed above the reward table used to emphasis important details || <code>"Only appears during [[Fass (Deimos)|Fass]]"</code>
|-
| <code>MaxAge</code> || Table || ✔️ || The maximum age of the animal in years and months stored as a table with key/value pairs || <code>{ Month = 0, Year = 30 }</code>
|-
| <code>MaxWeight</code> || Number (float) || ✔️ || The maximum weight of the animal in kg || <code>60.0</code>
|-
| <code>MinAge</code> || Table || ✔️ || The minimum age of the animal in years and months stored as a table with key/value pairs || <code>{ Month = 10, Year = 0 }</code>
|-
| <code>MinWeight</code> || Number (float) || ✔️ || The minimum weight of the animal in kg || <code>1.0</code>
|-
| <code>Notes</code> || String || ❌ || Trivia or not so important notes about the animal || <code>"Closely resembles the Jerboa"</code>
|-
| <code>Rarity</code> || String || ✔️ || Integer that represents rarity of animal ("Common", "Uncommon", "Rare") || <code>"Common"</code>
|-
| <code>Reward</code> || String || ✔️ || The most important type of reward you get for capturing the animal || <code>"Ostron Standing"</code> 
|-
| <code>Standing</code> || Number (integer) || ✔️ || The amount of the type of standing specified for getting a ''''bad'''' capture ('Good' and 'Perfect' captures scales 1.5x and 2x respectively) || <code>500</code> or <code>0</code>
|-
| <code>Origin</code> || String || ✔️ || The origin of the animal  || <code>"Cambion Drift"</code>
|-
| <code>Quotes</code> || Table (map of strings) || ❌ || A table of quotes with the quotee || <code>{ Quote = "this is a quote" Quotee = "myself" }</code>
|-
| <code>TranqsNeeded</code> || Number (integer) || ✔️ || Number of [[Tranq Rifle]] shots to subdue the animal for capture || <code>2</code>
|-
|}

==Conservation Data==
[[Category:Databases]]