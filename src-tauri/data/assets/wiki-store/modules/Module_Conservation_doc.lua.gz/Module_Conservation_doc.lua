<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Template ===
In template and articles: <code><nowiki>{{#invoke:Conservation|function|input1|input2|...}}</nowiki></code>
}}
</onlyinclude>