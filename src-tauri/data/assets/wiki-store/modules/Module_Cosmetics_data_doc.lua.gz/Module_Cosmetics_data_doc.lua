{{UpdateMe|Under construction}}
Database of [[WARFRAME]]'s [[Warframes]], [[weapons]], [[Operator]], [[companion]] cosmetics, and etc.

==Where to Update Data==
To update user data schema:
* [[Module:Cosmetics/userdata]]

To update [[Warframe]] cosmetics:
* [[Module:Cosmetics/data/animationset]]
* [[Module:Cosmetics/data/armor]]
* [[Module:Cosmetics/data/auxiliary]]
* [[Module:Cosmetics/data/emblem]]
* [[Module:Cosmetics/data/ephemera]]
* [[Module:Cosmetics/data/signa]]
* [[Module:Cosmetics/data/syandana]]
* [[Module:Cosmetics/data/texture]] -- Voidshell
* [[Module:Cosmetics/data/warframehelmet]]
* [[Module:Cosmetics/data/warframeskin]]
* [[Module:Sigils/data]]
* [[Module:TennoGen/data]]

To update [[Weapon]] cosmetics:
* [[Module:Cosmetics/data/holster]]
* [[Module:Cosmetics/data/sugatra]]
* [[Module:Cosmetics/data/parazonskin]]
* [[Module:Cosmetics/data/weaponskin]]

To update [[Companion]] cosmetics:
* [[Module:Cosmetics/data/emotionmodule]] -- MOA
* [[Module:Cosmetics/data/genemaskingkit]]
* [[Module:Cosmetics/data/kubrowarmor]]
* [[Module:Cosmetics/data/kubrowcollar]]
* [[Module:Cosmetics/data/kavatarmor]]
* [[Module:Cosmetics/data/moaskin]]
* [[Module:Cosmetics/data/pattern]]
* [[Module:Cosmetics/data/sentinelarmor]] -- Mask, Wing, Tail
* [[Module:Cosmetics/data/sentinelskin]]

To update [[Operator]]/[[Drifter]] customization and cosmetics:
* [[Module:Cosmetics/data/face]] -- Face, Head, Hair, Beard, Somatics
* [[Module:Cosmetics/data/facialaccessory]]
* [[Module:Cosmetics/data/transferencesuit]]
* [[Module:Cosmetics/data/visageink]]

To update [[Landing Craft]] cosmetics:
* [[Module:Cosmetics/data/landingcraftlivery]]
* [[Module:Cosmetics/data/sumdali]]

To update [[Vehicle]] cosmetics:
* [[Module:Cosmetics/data/archwingskin]]
* [[Module:Cosmetics/data/kdriveskin]]
* [[Module:Cosmetics/data/scrawl]] -- K-Drive Scrawl
* [[Module:Cosmetics/data/necramechskin]]
* [[Module:Cosmetics/data/railjackskin]]
* [[Module:Cosmetics/data/kaithe]]
* [[Module:Cosmetics/data/atomicyclelivery]]

To update [[Lotus]] customization:
* [[Module:Cosmetics/data/lotusskin]]

To update [[Kahl]] cosmetics:
* [[Module:Cosmetics/data/kahlarmor]]

To update uncategorized cosmetics :
* [[Module:Cosmetics/data/uncategorized]]

==Cosmetics Data Schema==
<syntaxhighlight lang="lua">
		["Cosmetic Name"] = {
			CodexSecret = false,
			Description = "The standard issue skin for the Atlas Warframe.",
			ExcludeFromCodex = true,
			Image = "ImageName.png",
			InternalName = "/Lotus/Upgrades/Skins/Brawler/AtlasPrimeSkin",
			Introduced = "99",
			Link = "Cosmetic Page",
			Name = "Cosmetic Name",
			Type = "Skin"
		},
</syntaxhighlight>

==Cosmetics Data Schema (TennoGen Cosmetics)==
<syntaxhighlight lang="lua">
		["Cosmetic Name"] = {
		    Artists = { "Artist 1", "Artist 2" },  -- artist names in a table
			CodexSecret = false,
			ConsolePrice = "100",  -- in platinum
			Description = "The standard issue skin for the Atlas Warframe.",
			ExcludeFromCodex = true,
			Image = "ImageName.png",
			InternalName = "/Lotus/Upgrades/Skins/Brawler/AtlasPrimeSkin",
			Introduced = "99",
			Link = "Cosmetic Page",
			Name = "Cosmetic Name",
			PcPrice = "$5.99",  -- include currency sign
			Round = "12",  -- TennoGen round number or name
			SteamLink = "https://steamcommunity.com/sharedfiles/filedetails/?id=1266378613",  -- entire URL of Steam workshop page
			Type = "Skin"
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! [[Arsenal]] EN L10n !! [[Public Export]] Equivalent !! Internal Equivalent !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Artists</code> || N/A || N/A || N/A || Table (of strings) || ✔️ (Only TennoGen) || Name of artists who contributed || <code>{ "malaya", "Cobalt" }</code>
|-
| <code>CodexSecret</code> || N/A || <code>codexSecret</code> || <code>CodexSecret</code> || Boolean || ✔️ || Whether or not the Cosmetic has an entry in the [[Codex]] before the player acquires it; defaults to false || <code>false</code>
|-
| <code>ConsolePrice</code> || N/A || N/A || N/A || String || ✔️ (Only TennoGen) || Price in [[Platinum]] on consoles || <code>"200"</code>
|-
| <code>Description</code> || N/A || <code>description</code> || <code>LocalizeDescTag</code> || String || ✔️ || In-game description || <code>"The standard issue skin for the Atlas Warframe."</code>
|-
| <code>ExcludeFromCodex</code> || N/A || N/A || <code>ExcludeFromCodex</code> || Boolean || ✔️ || Whether or not the Cosmetic will always be excluded from Codex || <code>false</code>
|-
| <code>Image</code> || N/A || <code>textureLocation</code> || <code>Icon</code> || String || ✔️ || Image file name of the Cosmetic as seen in in-game menus || <code>"InarosHelmet.png"</code>
|-
| <code>InternalName</code> || N/A || <code>uniqueName</code> || <code>TypeName</code> || String || ✔️ || The full unique name of a Cosmetic formatted as a file path || <code>"/Lotus/Upgrades/Skins/Brawler/AtlasPrimeSkin"</code>
|-
| <code>Introduced</code> || N/A || N/A || N/A || String || ✔️ || The game version in which the Cosmetic was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || N/A || N/A || N/A || String || ✔️ || Page/article link to the Cosmetic on the wiki || <code>"Ephemera"</code>
|-
| <code>Name</code> || N/A || <code>name</code> || <code>LocalizeTag</code> || String || ✔️ || Cosmetic's name || <code>"Braton Conclave Skin"</code>
|-
| <code>PcPrice</code> || N/A || N/A || N/A || String || ✔️ (Only TennoGen) || Price in US dollars on PC || <code>"$5.99"</code>
|-
| <code>Round</code> || N/A || N/A || N/A || String || ✔️ (Only TennoGen) || TennoGen round number or name || <code>"12"</code>
|-
| <code>SteamLink</code> || N/A || N/A || N/A || String || ✔️ (Only TennoGen) || Entire URL of Steam workshop page || <code>"https://steamcommunity.com/sharedfiles/filedetails/?id=1266378613"</code>
|-
| <code>Type</code> || N/A || N/A || N/A || String || ✔️ || Cosmetic type || <code>"Skin"</code>
|-
|}

==Data Validation==
<!--
===Checking for required keys===
{{Column|3|
{{#invoke:Resources/data/validate|checkRequiredKeysExist}}
}}

===Validating data types of values===
{{Column|3|
{{#invoke:Resources/data/validate|validateDataTypes}}
}}
-->
===Checking naming scheme of image names===
{{Column|3|
{{#invoke:Cosmetics/data/validate|checkImageNames}}
}}

==Cosmetic Data==
[[Category:Databases]]