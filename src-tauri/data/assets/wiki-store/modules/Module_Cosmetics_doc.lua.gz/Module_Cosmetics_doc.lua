<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Cosmetics|function|input1|input2|...}}</nowiki></code>

=== Template ===
In template: <code><nowiki>{{#invoke:Cosmetics|function|input1|input2|...}}</nowiki></code><br />
In articles: <code><nowiki>{{Cosmetics|input1|input2|...}}</nowiki></code>

=== Module ===
<syntaxhighlight lang="lua">
local Cosmetics = require('Module:Cosmetics')
</syntaxhighlight>
}}</onlyinclude>