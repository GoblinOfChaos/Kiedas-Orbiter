==Users Data Schema==
'''Users''' collection maps items to the cosmetics they can equip in the respective cosmetic slot.
<syntaxhighlight lang="lua">
		["Item Name"] = {
			Equipments = {
				["Animation Set"] = {
					"Animation Set Name",
				},
				Auxiliary = {
					"Auxiliary Name",
				},
				Armor = {
					"Armor Name",
				},
				Emblem = {
					"Emblem Name",
				},
				Ephemera = {
					"Ephemera Name",
				},
				Helmet = {
					"Helmet Name",
				},
				Holster = {
					"Holster Name",
				},
				Livery = {
					"Livery Name",
				},
				Skin = {
					"Skin Name",
				},
			},
			Type = "Weapon/Warframe/Attachment/Vehicle/Companion",
		},
</syntaxhighlight>

*Supported <code>Equipments</code> tables:
**Animation Set
**Auxiliary
**Armor
**Beard
**Body Suit
**Chamfron
**Collar
**Coronet
**Ear
**Emblem
**Emotion Module
**Ephemera
**Eye
**Face
**Facial
**Gene-Masking Kit
**Hair
**Helmet
**Holster
**Hood
**Leggings
**Livery
**Markings
**Pattern
**Pedigree
**Saddle
**Scrawl
**Skin
**Sleeves
**Sumdali
**Tail
**Visage Ink
**Waistband
**Wing