__TOC__
== Health Class Entry Schema==
<syntaxhighlight lang="lua">
		["Health Class"] = {
			Bypass = {  },
			CSSTextColorClass = "var(--css-var-name)",
			Faction = { "Grineer", "Corpus", "Infested" },
			InternalName = "",
			Link = "Page name",
            Name = "Health Class",
			Negatives = { { "Slash", 50 }, { "Magnetic", 50 }, { "Electricity", 50 } },
			Nickname = "Nickname",
			Positives = { { "Cold", 25 }, { "Puncture", 15 }, { "Radiation", 75 } },
			Type = "Armor, Health, or Shield" 
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Bypass</code> || Table (of 2-element tables) || ✔️ || Damage types that ignore this health class || <code>{ { "True", 0 } }</code> or <code>{  }</code> 
|-
| <code>Color</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSTextColorClass</code> instead. Default HSL color value (hue, saturation) || <code>"250, 10%"</code>
|-
| <code>CSSTextColorClass</code> || String || ✔️ || The name of the CSS variable in [[MediaWiki:Common.css]] for text color || <code>var(--faction-tenno-text-color)</code>
|-
| <code>DarkModeColor</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSTextColorClass</code> instead. Dark mode HSL color value (hue, saturation) || <code>"250, 10%"</code>
|-
| <code>Faction</code> || Table (of strings) || ✔️ || Name of enemy factions that use this health class || <code>{ "Grineer", "Infested" }</code>
|-
| <code>InternalName</code> || String || ✔️ || The internal name/code name || <code>"RK_HULKING_ARMOR"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the weapon on the wiki || <code>"Infested (Health)"</code>
|-
| <code>Name</code> || String || ✔️ || Name of health class || <code>"Infested"</code>
|-
| <code>Negatives</code> || Table (of 2-element tables) || ✔️ || Damage types that have a negative [[Damage Type Modifier]] against this health class || <code>{ { "Slash", 50 }, { "Magnetic", 50 } }</code> or <code>{  }</code> 
|-
| <code>Nickname</code> || String || ✔️ || Short name for health class || <code>"Ferrite"</code>
|-
| <code>Positives</code> || Table (of 2-element tables) || ✔️ || Damage types that have a positive [[Damage Type Modifier]] against this health class || <code>{ { "Cold", 25 }, { "Puncture", 15 } }</code> or <code>{  }</code> 
|-
| <code>Type</code> || String || ✔️ || Type of health class ("Armor", "Health", or "Shield") || <code>"Shield"</code>
|-
|}

== Status Effect Entry Schema ==
<syntaxhighlight lang="lua">
		["Status Effect"] = {
			CSSBackgroundColorClass = "var(--css-var-name)",
			CSSBorderColorClass = "var(--css-var-name)",
			CSSTextColorClass = "var(--css-var-name)",
			GlyphImage = "Glyph .png image name",
			Icon = "64px .png icon name",
			InternalName = "",
			Link = "Page name",
			Name = "Name",
			Status = { "Stagger" },
			StatusNotes = { 1, 2 } 
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Bypass</code> || Table (of strings) || ❌ || For Toxin procs, the health classes that are ignored by this status effect's DoT || <code>{ "Shield", "Proto Shield", "Tenno Shield" }</code>
|-
| <code>BypassNotes</code> || Table (of ints) || ❌ || For non-empty Bypass key, indices of additional notes as stored in <code>Notes</code> subtable || <code>{ 5 }</code>
|-
| <code>Color</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSTextColorClass</code> instead. Default color hex code associated with damage/status type || <code>"#3d5e5e"</code>
|-
| <code>ColorBackground</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSBackgroundColorClass</code> instead. Color hex code associated with damage/status type; for use on damage tooltips ([[Template:D]]) || <code>"#cad8d8"</code>
|-
| <code>ColorBorder</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSBorderColorClass</code> instead. Color hex code associated with damage/status type; for use on damage tooltips ([[Template:D]]) || <code>"#486061"</code>
|-
| <code>CSSBackgroundColorClass</code> || String || ✔️ || The name of the CSS variable in [[MediaWiki:Common.css]] for background color || <code>var(--dt-impact-background-color)</code>
|-
| <code>CSSBorderColorClass</code> || String || ✔️ || The name of the CSS variable in [[MediaWiki:Common.css]] for border color || <code>var(--dt-impact-border-color)</code>
|-
| <code>CSSTextColorClass</code> || String || ✔️ || The name of the CSS variable in [[MediaWiki:Common.css]] for text color || <code>var(--dt-impact-text-color)</code>
|-
| <code>DarkModeColor</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSTextColorClass</code> instead. Color hex code associated with damage/status type for dark mode || <code>"#80c4c4"</code>
|-
| <code>GlyphImage</code> || String || ❌ || Image file name of the damage [[Glyph]] as uploaded to the wiki || <code>"EssentialImpactGlyph.png"</code>
|-
| <code>Icon</code> || String || ✔️ || Image file name of the 64px damage icon as uploaded to the wiki || <code>"DmgImpactSmall64.png"</code>
|-
| <code>InternalName</code> || String || ✔️ || The internal name/code name || <code>"PT_FLASHBANG"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the status effect on the wiki || <code>"Damage/Viral Damage"</code>
|-
| <code>Name</code> || String || ✔️ || Name of status effect || <code>"Bleeding"</code>
|-
| <code>Status</code> || Table (of strings) || ✔️ || Description of effects that occur from the proccing its [[Status Effect]] || <code>{ "Tesla Chain", "Stun" }</code> or <code>{  }</code> 
|-
| <code>StatusNotes</code> || Table (of ints) || ✔️ || Indices of additional notes as stored in <code>Notes</code> subtable || <code>{ 1, 2 }</code> or <code>{  }</code> 
|-
|}

== Damage Type Entry Schema ==
<syntaxhighlight lang="lua">
		["Damage Type"] = {
			CSSBackgroundColorClass = "var(--css-var-name)",
			CSSBorderColorClass = "var(--css-var-name)",
			CSSTextColorClass = "var(--css-var-name)",
			GlyphImage = "Glyph .png image name",
			Icon = "64px .png icon name",
			InternalName = "",
			Link = "Page name",
			Name = "Name",
			Negatives = { { "Flesh", 25 }, { "Cloned Flesh", 25 }, { "Tenno Shield", 25 } },
			Positives = { { "Shield", 50 }, { "Machinery", 25 }, { "Proto Shield", 15 } },
			ProcInternalName = "",
			Status = { "Stagger" },
			StatusNotes = { 1, 2 } 
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Bypass</code> || Table (of strings) || ❌ || For Toxin damage, the health classes that are ignored by this damage type || <code>{ "Shield", "Proto Shield", "Tenno Shield" }</code>
|-
| <code>BypassNotes</code> || Table (of ints) || ❌ || For non-empty Bypass key, indices of additional notes as stored in <code>Notes</code> subtable || <code>{ 5 }</code>
|-
| <code>Color</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSTextColorClass</code> instead. Color hex code associated with damage/status type || <code>"#3d5e5e"</code>
|-
| <code>ColorBackground</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSBackgroundColorClass</code> instead. Color hex code associated with damage/status type; for use on damage tooltips ([[Template:D]]) || <code>"#cad8d8"</code>
|-
| <code>ColorBorder</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSBorderColorClass</code> instead. Color hex code associated with damage/status type; for use on damage tooltips ([[Template:D]]) || <code>"#486061"</code>
|-
| <code>CSSBackgroundColorClass</code> || String || ✔️ || The name of the CSS variable in [[MediaWiki:Common.css]] for background color || <code>var(--dt-impact-background-color)</code>
|-
| <code>CSSBorderColorClass</code> || String || ✔️ || The name of the CSS variable in [[MediaWiki:Common.css]] for border color || <code>var(--dt-impact-border-color)</code>
|-
| <code>CSSTextColorClass</code> || String || ✔️ || The name of the CSS variable in [[MediaWiki:Common.css]] for text color || <code>var(--dt-impact-text-color)</code>
|-
| <code>DarkModeColor</code> || String || ❌ || Depreciated as of 2025-03-16, use <code>CSSTextColorClass</code> instead. Color hex code associated with damage/status type for dark mode || <code>"#80c4c4"</code>
|-
| <code>GlyphImage</code> || String || ❌ || Image file name of the damage [[Glyph]] as uploaded to the wiki || <code>"EssentialImpactGlyph.png"</code>
|-
| <code>Icon</code> || String || ✔️ || Image file name of the 64px damage icon as uploaded to the wiki || <code>"DmgImpactSmall64.png"</code>
|-
| <code>InternalName</code> || String || ✔️ || The internal name/code name || <code>"DT_EXPLOSION"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the damage type on the wiki || <code>"Damage/Viral Damage"</code>
|-
| <code>Name</code> || String || ✔️ || Name of damage type || <code>"Electricity"</code>
|-
| <code>Negatives</code> || Table (of 2-element tables) || ✔️ || Health class types that have a negative [[Damage Type Modifier]] for this damage type || <code>{ { "Flesh", 25 }, { "Cloned Flesh", 25 } }</code> or <code>{  }</code> 
|-
| <code>Positives</code> || Table (of 2-element tables) || ✔️ || Health class types that have a positive [[Damage Type Modifier]] for this damage type || <code>{ { "Shield", 50 }, { "Machinery", 25 } }</code> or <code>{  }</code> 
|-
| <code>ProcInternalName</code> || String || ✔️ || For damage types, the internal name/code name of its [[Status Effect]] || <code>"PT_FLASHBANG"</code>
|-
| <code>Status</code> || Table (of strings) || ✔️ || Description of effects that occur from the proccing its [[Status Effect]] || <code>{ "Tesla Chain", "Stun" }</code> or <code>{  }</code> 
|-
| <code>StatusNotes</code> || Table (of ints) || ✔️ || Indices of additional notes as stored in <code>Notes</code> subtable || <code>{ 1, 2 }</code> or <code>{  }</code> 
|-
|}

== Visual Tests ==
<div style="display: flex; flex-wrap: wrap;">
<div>
; Against article background
<div style="padding:10px; width:500px;">
{{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}

{{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}

{{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}

{{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
</div>
</div>
<div>
; Against flat light background (#ebebeb)
<div style="background-color:#ebebeb; padding:10px; width:500px;">
{{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}

{{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}

{{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}

{{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
</div>
</div>
<div>
; Against flat dark background (#0d1717)
<div style="background-color:#0d1717; padding:10px; width:500px;">
{{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}

{{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}

{{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}

{{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
</div>
</div>
<div>
; Against flat dark monochrome background (#202020)
<div style="background-color:#202020; padding:10px; width:500px;">
{{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}

{{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}

{{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}

{{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
</div>
</div>
</div>

; Against <code>navbox</code> table background
{| class="navbox" style="width:100%; margin:0px 0px;"
|-
! colspan=2 class="navboxhead" | Test
|-
| class="navboxgroup" | Test
| {{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}
|-
| class="navboxgroup" | Test
| {{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}
|-
| class="navboxgroup" | Test
| {{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}
|-
| class="navboxgroup" | Test
| {{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
|-
| colspan=2 class="navboxhead" | {{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}
|-
| colspan=2 class="navboxhead" | {{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}
|-
| colspan=2 class="navboxhead" | {{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}
|-
| colspan=2 class="navboxhead" | {{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
|-
|}
<br/>
; Against <code>wikitable</code> table background
{| class="wikitable" style="width:100%; margin:0px 0px;"
|-
! colspan=2 | {{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}
|-
! colspan=2 | {{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}
|-
! colspan=2 | {{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}
|-
! colspan=2 | {{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
|-
| Test
| {{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}
|-
| Test
| {{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}
|-
| Test
| {{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}
|-
| Test
| {{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
|-
|}
<br/>
; Against infobox background
{{Infobox
| Box title = Test
| image     = Panel.png
| Row 1 title = Test
| Row 1 info  = {{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}
| Row 2 title = Test
| Row 2 info = {{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}
| Row 3 title = Test
| Row 3 info = {{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}
| Row 4 title = Test
| Row 4 info = {{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
}}
{{clr}}
; Against T&#58;AbilityU10.3 background
{{AbilityU10.3|
| cardonly       = 
| name           = Slash Dash
| misc    = {{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}

{{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}

{{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}

{{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
}}

; Against <code>emodtable</code> table header background
{| class="emodtable" style="width:100%; margin:0px 0px;"
|-
! {{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}
|-
! {{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}
|-
! {{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}
|-
! {{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
|-
| Test
|-
|}
<br/>
; Against T&#58;Codex background
{{Codex|
{{D|Impact}} {{D|Puncture}} {{D|Slash}}<br/>
{{D|Cold}} {{D|Electricity}} {{D|Heat}} {{D|Toxin}}<br/>
{{D|Blast}} {{D|Corrosive}} {{D|Gas}} {{D|Magnetic}} {{D|Radiation}} {{D|Viral}}<br/>
{{D|Tau}} {{D|True}} {{D|Void}}

{{D|Knockback}} {{D|Weakened}} {{D|Bleed}}<br/>
{{D|Freeze}} {{D|Tesla Chain}} {{D|Ignite}} {{D|Poison}}<br/>
{{D|Detonate}} {{D|Corrosion}} {{D|Gas Cloud}} {{D|Disrupt}} {{D|Confusion}} {{D|Virus}}<br/>
{{D|Status Vulnerability}} {{D|Bullet Attractor}}<br/>
{{D|Impair}} {{D|Knockdown}} {{D|Lifted}} {{D|Ragdoll}} {{D|Stagger}}

{{D|Tenno Shield}} {{D|Tenno Armor}} {{D|Tenno Flesh}}<br/>
{{D|Cloned Flesh}} {{D|Ferrite Armor}} {{D|Alloy Armor}} {{D|Machinery}}<br/>
{{D|Shield}} {{D|Proto Shield}} {{D|Flesh}} {{D|Robotic}}<br/>
{{D|Infested}} {{D|Infested Flesh}} {{D|Fossilized}} {{D|Infested Sinew}}

{{D|Corpus}} {{D|Corpus Amalgam}} {{D|Grineer}} {{D|Infested}} {{D|Infested Deimos}}<br/>
{{D|Kuva Grineer}} {{D|Narmer}} {{D|Object}} {{D|Overguard}} {{D|Orokin}}<br/>
{{D|Scaldra}} {{D|Sentient}} {{D|Techrot}} {{D|Tenno}} {{D|The Murmur}} {{D|Zariman}}
}}

== DamageType Data ==
[[Category:Databases]]