<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:DamageType|function|input1|input2|...}}</nowiki></code>

=== Template ===
<code><nowiki>{{d|type name}}</nowiki></code>

<code><nowiki>{{d/img|type name}}</nowiki></code>

<code><nowiki>{{#invoke:DamageType|damagetable|type name}}</nowiki></code>

<code><nowiki>{{#invoke:DamageType|healthtable|type name}}</nowiki></code>

==Icons==
{{#lsth:Module:DamageTypes/data/doc|Visual Tests}}
}}
</onlyinclude>