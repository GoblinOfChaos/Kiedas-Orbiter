<includeonly>{{#invoke:ModuleTest|main}}</includeonly>
==Visual test cases==
<pre>{{#invoke:DamageTypes|damagetable|Impact}}</pre>
{{#invoke:DamageTypes|damagetable|Impact}}
<hr/>
<pre>{{#invoke:DamageTypes|healthtable|Ferrite Armor}}</pre>
{{#invoke:DamageTypes|healthtable|Ferrite Armor}}
{{clr}}
==Scribunto tests code==
<noinclude>[[Category:Lua test suites]]</noinclude>