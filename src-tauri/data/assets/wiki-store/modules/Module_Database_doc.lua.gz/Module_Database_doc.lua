<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Module ===
<syntaxhighlight lang="lua">
local Database = require('Module:Database')
</syntaxhighlight>
}}
</onlyinclude>