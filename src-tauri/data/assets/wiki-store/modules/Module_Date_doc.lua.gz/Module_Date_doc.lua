Lua module for creating Date objects for date calculations and manipulation not covered by either Mediawiki or [[mw:Extension:Scribunto|Scribunto]]'s <code>mw.language:formatDate()</code>. See https://tieske.github.io/date/ ([https://web.archive.org/web/20221129184917/https://tieske.github.io/date/ Archived]) for documentation.

{{ModuleNav}}