{{UpdateMe|Add [[Dormizone]] decorations here}}
Database of [[WARFRAME]]'s [[Decorations]].

==Decoration Entry Schema==
<syntaxhighlight lang="lua">
	["Decoration Name"] = {
		Name = "Decoration Name",
		Image = "DecoDecorationName.png",
		Description = "Description",
		Cost = {
			Capacity = 5,
			Time = 24,
			Credits = 500,
			Resources = {
				{ Count = 300, Name = "Ferrite" },
				{ Count = 200, Name = "Salvage" },
				{ Count = 100, Name = "Polymer Bundle" },
				{ Count = 0.07, Name = "Control Module" }
			}
		}
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! [[Public Export]] Equivalent || Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Cost</code> || N/A || Table (of key-value pairs) || ✔️ || Cost data of decoration || See [[#Cost Table Schema]]
|-
| <code>Description</code> || <code>description</code> || String || ✔️ || Description of decoration as seen in-game || <code>"Changes the entry point for Tenno arriving in the Dojo. Only one Arrival Gate can be placed in a Dojo."</code>
|-
| <code>Image</code> || <code>textureLocation</code> || String || ✔️ || Image file name of the decoration as uploaded to the wiki || <code>"DecoArrivalGate.png"</code>
|-
| <code>InternalName</code> || <code>uniqueName</code> || String || ❌ || The full unique name of a decoration formatted as a file path || <code>"/Lotus/Types/Recipes/WarframeRecipes/MummyBlueprint"</code>
|-
| <code>Introduced</code> || N/A || String || ❌ || The game version in which the decoration was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Name</code> || <code>name</code> || String || ✔️ || Name of decoration || <code>"Beacon"</code>
|-
|}

===Cost Subtable Schema===
<syntaxhighlight lang="lua">
		Cost = {
			Capacity = 5,
			Time = 24,
			Credits = 500,
			Resources = {
				{ Count = 300, Name = "Ferrite" },
				{ Count = 200, Name = "Salvage" },
				{ Count = 100, Name = "Polymer Bundle" },
				{ Count = 0.07, Name = "Control Module" }
			}
		}
</syntaxhighlight>
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Capacity</code> || Number (int) || ✔️ || The room capacity cost for placing decoration || <code>5</code>
|-
| <code>Credits</code> || Number (int) || ✔️ || The [[Credits]] cost for crafting the decoration || <code>25000</code>
|-
| <code>Resources</code> || Table (of tables) || ✔️ || A table containing the crafting components used to build the decoration and the amounts required at Ghost Clan rank || <pre>
{
	{ Count = 4, Name = "Neurodes" },
	{ Count = 1200, Name = "Alloy Plate" },
	{ Count = 700, Name = "Ferrite" },
	{ Count = 1000, Name = "Polymer Bundle" } 
}
</pre>
|-
| <code>Time</code> || Number (int) || ✔️ || The time in hours to build an item || <code>24</code>
|-
|}

==Data==
[[Category:Databases]]