{{UpdateMe}}
Database for [[Decree]]s.

==Decree Entry Schema==

==Decree Data==
[[Category:Databases]]