<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<pre>{{#invoke:DependencyGraph|main}}</pre>

== Module DOT Output==
=== Non-clustered ===
<div align="center"><div class="mw-customtoggle-clustered" style="cursor:pointer; position:relative; width:85%; background: linear-gradient(#768993, #55646d); display:inline-block; padding:0px 2px; margin:2px; line-height:20px; color:white; font-size:13px;border-radius: 3px;">View DOT file<span style="position:absolute;left:5px;">&#9662;</span><span style="position:absolute;right:5px;">&#9662;</span></div></div>
<div id="mw-customcollapsible-clustered" class="mw-collapsible mw-collapsed" style="display:flow-root;">
{{#invoke:DependencyGraph|main}}
</div>

=== Clustered ===
<div align="center"><div class="mw-customtoggle-non-clustered" style="cursor:pointer; position:relative; width:85%; background: linear-gradient(#768993, #55646d); display:inline-block; padding:0px 2px; margin:2px; line-height:20px; color:white; font-size:13px;border-radius: 3px;">View DOT file<span style="position:absolute;left:5px;">&#9662;</span><span style="position:absolute;right:5px;">&#9662;</span></div></div>
<div id="mw-customcollapsible-non-clustered" class="mw-collapsible mw-collapsed" style="display:flow-root;">
{{#invoke:DependencyGraph|main|cluster=true}}
</div>

=== Cleaning up non-clustered graph ===
If using <code>dot</code> algorithm to render a non-clustered graph, then use the [https://linux.die.net/man/1/unflatten unflatten] preprocessor to improve graph's aspect ratio:
<pre>unflatten -f -l5 -c13 fileName.dot</pre>

== Wiki's Dependency Graphs ==
Dependency graphs of this wiki's codebase can be viewed on the [[:Category:Dependency Graphs]] category.
}}
</onlyinclude>