Command line interface (CLI) of [[Module:Docbunto]]. Forked from https://dev.fandom.com/wiki/Module:Docbunto/cli

==Usage==
Commands can be executed using the debug console which can only be accessed at the bottom of [[Module:Docbunto/cli]]'s edit page (https://wiki.warframe.com/w/Module:Docbunto/cli?action=edit).

For a list of available commands and arguments, type:
<syntaxhighlight lang="lua">
=p "help"
</syntaxhighlight>

==Code==