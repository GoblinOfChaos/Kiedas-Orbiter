{{UpdateMe|Instead of storing JSON data in Lua tables, put them in on a page outside of Module namespace with a JSON content model like [[NightwaveActs.json]]. You can parse JSON data with mw.loadJsonData() in these Lua modules.}}
This module is a WIP, but eventually it'll (hopefully) be able to replace the clunky manual drop tables!

Data from [https://github.com/WFCD/warframe-drop-data/tree/gh-pages/data here]

{{Special:PrefixIndex/Module:DropTables/JSON/}}