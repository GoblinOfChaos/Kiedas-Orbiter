{{UpdateMe|{{ver|33}} and Duviri}}
Manually updated fork of the public [[Drop Tables]] provided by DE:
*https://warframe-web-assets.nyc3.cdn.digitaloceanspaces.com/uploads/cms/hnfvc0o3jnfvc873njb03enrf56.html or
<!--DE historically used Highwinds Network Group for CDN: https://n8k6e2y6.ssl.hwcdn.net/repos/hnfvc0o3jnfvc873njb03enrf56.html. This changed sometime in early 2024 to DigitalOcean Spaces-->
*https://www.warframe.com/droptables

See [[Module:DropTables]] to see what various things this is being used for right now.
{{LatestEdit}}
== How To Update Drop Tables ==
#Login to your wiki account and click "Edit Source" at the top right corner of the page. These pages are usually protected from anonymous editors.
#*If you are an anon and don't want to make an account, you can contribute by writing exactly what you want changed in reference to the official drop tables on the talk page ([[Module talk:DropTables/data]]) to streamline the update process for editors.
#*Newly created accounts have to wait ~3 days until their account becomes "autoconfirmed".
#CTRL+F the name of the relevant drop table, usually typing the mission type/enemy name should suffice.
#*If you still can't find the relevant drop table then you can reference the "Locations" section on any mission type article in the navigation box below to see what drop table alias a particular mission node uses. These drop table aliases are editor-defined for ease of reference since DE doesn't publicly name their drop tables.
#**Alternatively, you can go directly to the mission data stored on the wiki [[Module:Missions/data]] and see exactly what drop table alias a particular node is mapped to.
#*For [[Bounty|bounties]], search by the name of the hub that a particular bounty is associated with (e.g. [[Cetus]], [[Fortuna]], [[Necralisk]]) and its enemy level range. [[Zariman Ten Zero]] bounties are called "Zariman".
#Change drop names or drop chances in accordance to the below schemas. Use EN localization for item names.
#Updated data should proliferate across relevant pages across the wiki. If something isn't changed on an article then you can purge the page's cache by adding the query parameter <code>?action=purge</code> at the end of the URL.

{{MissionsNav}}

== Mod Drop Table Schema ==
<syntaxhighlight lang="lua">
{
	{ "Endo", "Resource", 75.88, 15 },
	{ "Hawk Eye", "Mod", 7.37 },
	{ "Shotgun Barrage", "Mod", 7.37 },
	{ "Endo", "Resource", 7.37, 50 },
	{ "Shock Absorbers", "Mod", 1.01 },
	{ "Endo", "Resource", 1.01, 80 } 
}
</syntaxhighlight>

# First element in each table element will be the mod's name as a string (required)
# Second element in each table element will be the item's type as a string (required)
# Third element in each table element will be the individual drop chance of said mod as a float (required)
# Forth element in each table element will represent drop count of [[Endo]] as an integer (required if first element is "Endo")

== General Drop Table Schema ==
<syntaxhighlight lang="lua">
{
	{ "Morphic Transformer", "Mod", 5.64 },
	{ "Automatic Trigger", "Mod", 38.72 },
	{ "Phaedra Receiver", "Item", 5.64 },
	{ "Extend", "Mod", 38.72 },
	{ "Shell Rush", "Mod", 5.64 },
	{ "Shell Rush", "Mod", 5.64 } 
}
</syntaxhighlight>

# First element in each table element will be the item's name as a string (required)
# Second element in each table element will represent item type as a string (required)
#* Possible values include <code>"Mod", "Blueprint", "Relic", "Resource", "Arcane", "Item", "Scene"</code>
# Third element in each table element will be the individual drop chance of said item as a float (required)
# Fourth element in each table element will represent drop count of said item as an integer (optional)

== Enemies Entry Schema ==
<syntaxhighlight lang="lua">
		["Enemy Name"] = {
			ModChance = 3,
			Mods = {
				{ "Mod 1 Name", "Mod", 25 },
				{ "Mod 2 Name", "Mod", 25 },
				{ "Endo", "Resource", 25, 15 },
				{ "Endo", "Resource", 25, 80 }
			},
			Name = "Enemy Name",
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>_IgnoreEntry</code> || Boolean || ❌ || Denotes drop tables that are in the official repository but should be ignored when parsing tables for the wiki since its contents cannot be dropped in-game || <code>true</code>
|-
| <code>BlueprintChance</code> || Number (float) || ❌ || [[Blueprints|Blueprint]]/Item drop table chance of rolling its rewards as a percentage; a value between 0 exclusive and 100 inclusive || <code>5</code>
|-
| <code>Blueprints</code> || Table (of tables) || ❌ || Blueprint/Item drop table contents as seen in the official drop table repo, each table element is a table that contains the name of blueprint/item and the percentage chance of that blueprint/item dropping. Required if <code>BlueprintChance</code> is a non-nil value. || <code>{ { "War Blade", 50 }, { "War Hilt", 50 } }</code>
|-
| <code>ItemChance</code> || Number (float) || ❌ || Additional Items drop table chance of rolling its rewards as a percentage; a value between 0 exclusive and 100 inclusive || <code>100</code>
|-
| <code>Items</code> || Table (of tables) || ❌ || Additional Items drop table contents as seen in the official drop table repo, each table element is a table that contains the name of item and the percentage chance of that item dropping. Required if <code>ItemChance</code> is a non-nil value. || <code>{ { "Powercell", 100 } }</code>
|-
| <code>ModChance</code> || Number (float) || ❌ || [[Mods|Mod]] drop table chance of rolling its rewards as a percentage; a value between 0 exclusive and 100 inclusive || <code>3</code>
|-
| <code>Mods</code> || Table (of tables) || ❌ || Mod drop table contents as seen in the official drop table repo, each table element is a table that contains the name of mod and the percentage chance of that mod dropping; if reward is [[Endo]], also add a third element containing the amount of Endo rewarded. Required if <code>ModChance</code> is a non-nil value. || <pre>
{
	{ "Regen", "Mod", 18.97 },
	{ "Calculated Redirection", "Mod", 18.97 },
	{ "Rupture", "Mod", 18.97 },
	{ "Endo", "Resource", 18.97, 15 },
	{ "Convulsion", "Mod", 7.37 },
	{ "Speed Trigger", "Mod", 7.37 },
	{ "Fracturing Wind", "Mod", 7.37 },
	{ "Endo", "Resource", 2.01, 80 } 
}
</pre>
|-
| <code>Name</code> || String || ✔️ || Name of enemy || <code>"Elite Lancer"</code>
|-
| <code>PigmentChance</code> || Number (float) || ❌ || [[Pigment]] drop table chance of rolling its rewards as a percentage; a value between 0 exclusive and 100 inclusive. Note that in-game, this chance only applies if the [[Clan]] that player is in is actively researching the pigment in question || <code>100</code>
|-
| <code>Pigments</code> || Table (of tables) || ❌ || [[Pigment]] drop table contents. Note that in-game, this chance only applies if the [[Clan]] that player is in is actively researching the pigment in question. Required if <code>PigmentChance</code> is a non-nil value. || <pre>
{
	{ "Boiler Red Pigment", "Resource", 100, 2 }
}
</pre>
|-
| <code>RelicChance</code> || Number (float) || ❌ || [[Resources|Resource]] drop table chance of rolling its rewards as a percentage; a value between 0 exclusive and 100 inclusive || <code>20</code>
|-
| <code>Relics</code> || Table (of tables) || ❌ || [[Void Relic|Relic]] drop table contents as seen in the official drop table repo, each table element is a table that contains the name of relic and the percentage chance of that relic dropping. Required if <code>RelicChance</code> is a non-nil value. || 
<pre>
{
	{ "Lith T7", "Relic", 15.49 },
	{ "Lith N7", "Relic", 15.49 },
	{ "Meso B5", "Relic", 15.49 },
	{ "Meso S10", "Relic", 15.49 },
	{ "Meso B6", "Relic", 15.49 },
	{ "Neo N16", "Relic", 3.76 },
	{ "Neo T5", "Relic", 3.76 },
	{ "Neo N17", "Relic", 3.76 },
	{ "Axi A14", "Relic", 3.76 },
	{ "Axi I2", "Relic", 3.76 },
	{ "Axi M2", "Relic", 3.76 } 
}
</pre>
|-
| <code>ResourceChance</code> || Number (float) || ❌ || [[Resources|Resource]] drop table chance of rolling its rewards as a percentage; a value between 0 exclusive and 100 inclusive || <code>7</code>
|-
| <code>Resources</code> || Table (of tables) || ❌ || Resource drop table contents as seen in the official drop table repo, each table element is a table that contains the name of resource and the percentage chance of that resource dropping. Required if <code>ResourceChance</code> is a non-nil value. || <code>{ { "Region Resource", 77.44 }, { "Nav Coordinate", 22.56 } }</code>
|-
| <code>SigilChance</code> || Number (float) || ❌ || [[Sigils|Sigil]] drop table chance of rolling its rewards as a percentage; a value between 0 exclusive and 100 inclusive || <code>100</code>
|-
| <code>Sigils</code> || Table (of tables) || ❌ || Sigil drop table contents as seen in the official drop table repo, each table element is a table that contains the name of sigil and the percentage chance of that sigil dropping. Required if <code>SigilChance</code> is a non-nil value. || <code>{ { "Alad V Sigil", 100 } }</code>
|-
|}

== Missions Entry Schema ==
<syntaxhighlight lang="lua">
		Spy1 = {
			Alias = "Spy1",
			Link = "Spy",
			Name = "Tier 1",
			Rewards = {
				A = {
					{ "Credits Cache", "Credits", 14.29, 1500 },
					{ "Credits Cache", "Credits", 14.29, 1500 },
					{ "Endo", "Resource", 14.29, 100 },
					{ "Endo", "Resource", 14.29, 100 },
					{ "Reflection", "Mod", 14.29 },
					{ "Reflex Guard", "Mod", 14.29 },
					{ "Parry", "Mod", 14.29 } 
				},
				B = {
					{ "Lith G4", "Relic", 14.29 },
					{ "Lith T7", "Relic", 14.29 },
					{ "Lith K7", "Relic", 14.29 },
					{ "Lith N7", "Relic", 14.29 },
					{ "Lith G4", "Relic", 14.29 },
					{ "Lith I1", "Relic", 14.29 },
					{ "Lith N8", "Relic", 14.29 } 
				},
				C = {
					{ "Master Key", "Mod", 10 },
					{ "Reflection", "Mod", 10 },
					{ "Parry", "Mod", 10 },
					{ "Heavy Impact", "Mod", 10 },
					{ "Serration", "Mod", 10 },
					{ "Hornet Strike", "Mod", 10 },
					{ "Metal Auger", "Mod", 10 },
					{ "Volcanic Edge", "Mod", 10 },
					{ "Vicious Frost", "Mod", 10 },
					{ "Ivara Systems Blueprint", "Blueprint", 10 } 
				} 
			},
			Type = "Spy" 
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Alias</code> || String || ✔️ || User-defined name for the drop table group. Many missions share the same drop tables so this is how we refer to a specific drop table group. <code>"Survival1"</code>
|-
| <code>InternalName</code> || String || ❌ || The full unique name of a drop table formatted as a file path || <code>"/Lotus/Types/Game/MissionDecks/InvasionRewards"</code>
|-
| <code>Link</code> || String || ✔️ || Name of page on the wiki of the mission associated with drop table || <code>"Spy"</code>
|-
| <code>Name</code> || String || ✔️ || User-defined name of drop table to be displayed to readers || <code>"Tier 1 Spy"</code>
|-
| <code>Rewards</code> || Table (of key-value pairs) || ✔️ || Contains at least three drop tables (named A, B, and C) associated with a specific drop table group.
|
|-
| <code>Tier</code> || String || ✔️ || Name of tier associated with mission type for the drop table || <code>"All"</code> or <code>"Tier 2"</code>
|-
| <code>Type</code> || String || ✔️ || Name of mission type associated with drop table || <code>"Survival"</code>
|-
|}

==Rewards Subtable Collection==
Any reward entries added to the <code>Enemies</code> and <code>Missions</code> collections are automatically populated into the Rewards collection, indexed by item name and with the following schema:

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| Number index || Table (of table entries) || ✔️ || Each item name is mapped to an array-like table containing table entries about their drop source.
|
<syntaxhighlight lang="lua">
["Ambassador Blueprint"] = {
		{
			[1] = "Missions",
			[2] = "VeilProximaSurvival",
			[3] = "C"
			[4] = 2,
			Entry = { "Ambassador Blueprint", "Blueprint", 16.67 },
			Probability: 0.1667,
			Source = reference to original table entry,
		},
		{
			[1] = "Missions",
			[2] = "NeptuneProximaSurvival",
			[3] = "C",
			[4] = 5,
			Entry = { "Ambassador Blueprint", "Blueprint", 8.33 },
			Probability = 0.0833,
			Source = reference to original table entry,
		},
			[1] = "Missions",
			[2] = "PlutoProximaSurvival",
			[3] = "C",
			[4] = 5,
			Entry = { "Ambassador Blueprint", "Blueprint", 8.33 },
			Probability = 0.0833,
			Source = reference to original table entry,
		},
		{
			[1] = "Missions",
			[2] = "VenusProximaSurvival",
			[3] = "C",
			[4] = 5,
			Entry = { "Ambassador Blueprint", "Blueprint", 8.33 },
			Probability = 0.0833,
			Source = reference to original table entry,
		},
}
</syntaxhighlight>
|-
|}

===Viewing Contents via API Call===
{{JSWarning}}

For debugging purposes in browser console:
<syntaxhighlight lang="javascript">
let origin = "https://wiki.warframe.com";
// MediaWiki's Action API endpoint
let path = "/api.php";
// Passing Lua code to Action API to convert Lua tables containing drop table data into JSON
let params = {
	action: "scribunto-console",
	format: "json",
	title: "Module:DropTables/data",
	content: "",
	question: `
local DropData = require('Module:DropTables/data').Rewards
local json = require('Module:JSON')
print(json.stringify(DropData))`,
	clear: 1
};

// [ ["action", "scribunto-console"], ["format","json"], ... ] to "action=scribunto-console&format=json&..."
let queryString = new URLSearchParams([ ...Object.entries(params) ]).toString();

let url = new URL(`${origin}${path}?${queryString}`);

fetch(url)
	.then((data) => data.json())
	.then((json) => {
		if (json.print !== undefined) {
			console.log(JSON.parse(json.print));
		} else {
			throw json.html;	// Lua script error has occurred
		}
	})
	.catch((error) => console.log(error));
</syntaxhighlight>

==Differences Between Official Repo And Wiki's Drop Tables==
'''The official drop table repository and the wiki's repo are not one-to-one, just as the official repo is not one-to-one with actual in-game drop tables.''' Entries are manually edited and audited for the purposes of rendering content properly on the wiki. '''DO NOT ASSUME THIS IS THE SAME AS THE OFFICIAL REPO OR IN-GAME DROP TABLES.'''

;Wiki's repo
*[[Void Relic]]s do not have " Relic" in their name unlike in the official repo.
*Chassis components for gun weapons are named "<Weapon_Name> Gun Chassis" instead of "<Weapon_Name> Chassis" to differentiate between Warframe chassis and weapon chassis
*Includes the chances that a new [[Invasion]] node will roll a specific reward for both sides. This data was sourced from a datamined resource which may or may not be outdated.
*Includes [[Orokin Tower#Treasure Rooms|Orokin Tower Containers]]
*Includes [[Requiem Relic]] drop chances of [[Kuva Thrall]]s and [[Hound]]s
*Enemy names will be formatted to their in-game representation (like "Raptor Mt" to "[[Raptor MT]]")
**"Nechramech" is renamed to "Necramech" to match in-game presentation
**Duplicate "Vomvalyst" entry is not included in wiki's repo. Use "Eidolon Vomvalyst" instead.
**Exception would be "MOA" as in the Corpus enemy. Game is inconsistent with capitalization, using both "MOA" and "Moa". "MOA" is the original spelling.
*Drop chances may be rounded to more decimal places than two
*[[Void Relic]] drop tables are stored in [[Module:Void/data]] and we only store the items in relic drop tables since drop chances at different relic refinements are the same across all relics (i.e. drop chances can be derived, no need to store additional data)
*Since some mission types of the same tier/difficulty share drop tables, we will not store duplicate drop tables in the wiki's repo to save space
*Contains [[Pigment]] drop chance data
*For items that appear more than once in the same drop table, we consolidate these drop chances into one entry for simplicity and for sorting by highest/lowest drop chances in wikitables, even if that is not the actual internal implementation
**For example, as of 2022-12-14, we see duplicate [[Void Relic]] entries for Void/Taranis (Defense) Rotation A drop table<ref>{{Ref|title=Official Drop Table Repo|year=2022|month=12|day=14|publisher=Digital Extremes|url=https://www.warframe.com/droptables|access-date=2022-12-22|archive-url=https://web.archive.org/web/20221217011721/https://n8k6e2y6.ssl.hwcdn.net/repos/hnfvc0o3jnfvc873njb03enrf56.html|archive-date=2022-12-17}}</ref>

;Official repo
*Contains drop tables of outdated event/Star Chart nodes like [[Camenae]], Sedna (Defense) and [[Viver]], Eris (Caches)
*Contains drop tables of enemies that cannot be normally spawned like "Terra Cestra Manker" or "Kuva Lich Agor Rok (Level 0 - 69)"
*Contains entries that share the name as others like Common Corpus Storage Container. In the wiki's repo, the second instance of these drop tables will have " (2)" appended to the name so that keys stay unique.
*Labels all Railjack mission nodes as the "Skirmish" mission type. The wiki uses the mission type as shown in menus in-game.
*May contain unreleased content<ref>{{Ref|title=Official Drop Table Repo|year=2022|month=12|day=14|publisher=Digital Extremes|url=https://www.warframe.com/droptables|access-date=2022-12-26|archive-url=https://web.archive.org/web/20221217011721/https://n8k6e2y6.ssl.hwcdn.net/repos/hnfvc0o3jnfvc873njb03enrf56.html|archive-date=2022-12-17|extra=Lith A5, Lith V9, Meso T6, Meso V8, Neo A7, Neo D6, and Axi F1 are included in 2022-12-14 update of drop table repo, representing a future Atlas/Vauban Prime rerun}}</ref>

==Updating Relic Drop Locations Notes==
{{Transclude|Module:Void/data/doc#Updating Notes}}

==References==
{{Reflist}}

==Drop Table Data==
[[Category:Databases]]