{{#invoke:DropTables/dev|getItemDropList|Life Strike}}
{{#invoke:DropTables/dev|getItemDropList|Serration}}
{{#invoke:DropTables/dev|getRewardTable|Survival1}}
{{#invoke:DropTables/dev|getRewardTable|VenusProximaSurvival}}
<infobox>
    <title source="name">
        <default><span style="font-weight:bold;">Test</span></default>
    </title>
    <image source="image">
        <format>[[File:{{#setmainimage:{{{image|Mod.png}}}}}|246px]][[Category:InfoboxOverride]]</format>
        <default>[[{{#invoke:Mods|getValue|{{#var:Name}}|image}}|246px]]</default>
    </image>
    <group>
        <data source="transmutable">
            <default>{{#ifeq: {{#invoke:Mods|getValue|{{#var:Name}}|Transmutable}} | true 
                |<div style="text-align:center; font-weight:bold; font-size:15px;">[[Transmutation|{{text|green|Transmutable}}]]</div>[[Category:Transmutable Mods]]
                |<div style="text-align:center; font-weight:bold; font-size:15px;">[[Transmutation|{{text|red|Untransmutable}}]]</div>[[Category:Untransmutable Mods]]
                }}
            </default>
            <format><div style="text-align:center; font-weight:bold; font-size:15px;">[[Transmutation|{{text|red|Untransmutable}}]]</div>[[Category:Untransmutable Mods]][[Category:InfoboxOverride]]</format>
        </data>
        <header>Description</header>
        <data>
        	<default><div style="text-align:center; font-weight:bold;">Description</div></default>
    	</data>
        <header>Statistics</header>
        <data source="introduced">
            <label>Introduced</label>
            <format>{{{introduced}}}[[Category:InfoboxOverride]]</format>
            <default>Version</default>
        </data>
        <data source="type">
            <label>Type</label>
            <format>{{{type}}}[[Category:InfoboxOverride]]</format>
            <default>Primary</default>
        </data>
        <data source="polarity">
            <label>[[Polarity]]</label>
            <format>{{{polarity}}}[[Category:InfoboxOverride]]</format>
            <default>Madurai</default>
        </data>
        <data source="rarity">
            <label>Rarity</label>
            <format>{{{rarity}}}[[Category:{{{rarity}}} Mods]][[Category:InfoboxOverride]]</format>
            <default>Rare</default>
        </data>
        <data source="incompatible">
            <label>Incompatibility</label>
            <format>{{{incompatible}}}[[Category:InfoboxOverride]]</format>
            <default>None</default>
        </data>
        <data source="exilus">
            <label>Exilus</label>
            <format>{{{exilus}}}[[Category:InfoboxOverride]]</format>
            <default>false</default>
        </data>
        <data source="tradable">
            <label>Tradable</label>
            <format>{{{tradable}}}[[Category:InfoboxOverride]]</format>
            <default>true</default>
        </data>
        <data source="tax">
            <label>[[Trade System|Trading Tax]]</label>
            <format>{{cc|{{{tax|}}}}}[[Category:InfoboxOverride]]</format>
            <default>8,000</default>
        </data>
        <data source="droppedby">
            <label>Dropped by</label>
            <format>{{{droppedby|}}}[[Category:Manual Mod Drops]][[Category:InfoboxOverride]]</format>
        </data>
        <data source="autoDrops">
            <label>Source(s)</label>
            <format>{{#var:Drops}}{{#ifeq: {{{autoDrops|}}}|auto|
                |{{#if: {{#var:Drops}}
                    |<br/>|}}'''Other:'''<br/>{{{autoDrops|}}}[[Category:Manual Mod Drops]]
                }}</format>
            <default>{{#invoke:DropTables/dev|getItemDropList|Vitality}}</default>
        </data>
    </group>
</infobox>