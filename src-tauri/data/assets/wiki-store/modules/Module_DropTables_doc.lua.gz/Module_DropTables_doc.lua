<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Template ===
In template: <code><nowiki>{{#invoke:DropTables|function|input1|input2|...}}</nowiki></code><br />
In articles: <code><nowiki>{{template|function|input1|input2|...}}</nowiki></code>

=== Module ===
<syntaxhighlight lang="lua">
local DropTable = require('Module:DropTables')
</syntaxhighlight>
}}
</onlyinclude>