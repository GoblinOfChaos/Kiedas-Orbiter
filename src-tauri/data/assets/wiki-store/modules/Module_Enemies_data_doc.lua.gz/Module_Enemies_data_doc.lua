{{UpdateMe|Finishing seeding database with all enemy entries}}
Database for all [[Enemy|enemies]] in [[WARFRAME]]. Enemy drop tables can be updated on [[Module:DropTables/data]].

Enemy damage data based on https://docs.google.com/spreadsheets/d/1sS0OYvBXBkAsUGnlnBzyCA6GSTvLYfQzXka1plH7kxg/edit?usp=sharing credit to [[User:ArbitraryMary]].
{{LatestEdit}}
__TOC__

==Horizontal Partitions (and where to update data)==
*[[Module:Enemies/data/grineer]] - {{Faction|Grineer}} enemies
*[[Module:Enemies/data/corpus]] - {{Faction|Corpus}} enemies
*[[Module:Enemies/data/infestation]] - {{Faction|Infested}} enemies
*[[Module:Enemies/data/orokin]] - {{Faction|Orokin}} enemies
*[[Module:Enemies/data/sentient]] - {{Faction|Sentient}} enemies
*[[Module:Enemies/data/stalker]] - {{Faction|Stalker}} enemies
*[[Module:Enemies/data/narmer]] - {{Faction|Narmer}} enemies
*[[Module:Enemies/data/themurmur]] - {{Faction|The Murmur}} enemies
*[[Module:Enemies/data/scaldra]] - {{Faction|Scaldra}} enemies
*[[Module:Enemies/data/techrot]] - {{Faction|Techrot}} enemies
*[[module:Enemies/data/anarchs]] - {{Faction|Anarchs}} enemies
*[[Module:Enemies/data/unaffiliated]] - Enemies that don't fit into any of the previous partitions (e.g. {{Faction|Wild}}, {{Faction|Duviri}})

Please also update the corresponding [[Codex]] entry for enemy units on [[Module:Codex/data]].

==Enemy Entry Schema==
<syntaxhighlight lang="lua">
		["Heavy Gunner"] = {
			General = {
            	Abilities = { "Seismic Shockwave" },
				Actor = "",
				CodexSecret = false,
				Description = "High damage minigun",
				Faction = "Grineer",
				Image = "HeavyGunnerDE.png",
				Introduced = "Vanilla",
				Missions = {},
 				Planets = {},
				Scans = 3,
  				TileSets = { "Grineer Asteroid", "Grineer Galleon", "Grineer Shipyard", "Orokin Moon" },
				Type = "Ranged",
				Weapons = { "Gorgon", "Sheev" },
			},
			Stats = {
				Health = 300,
				Shield = 0,
				Armor = 500,
                Overguard = 0,
				Affinity = 500,
				BaseLevel = 8,
				SpawnLevel = 8,
				Multis = { "Head: 3.0x" },
				ProcResists = {},
			}
		},
</syntaxhighlight>

===General Subtable Schema===
<syntaxhighlight>
			General = {
				Abilities = { "Seismic Shockwave" },
				Actor = "",
				CodexSecret = false,
				Description = "Codex description of enemy",
				Faction = "Grineer",
				Missions = {},
				Image = "EnemyImage.png",
				InternalName = "",
				Introduced = "29",
				Link = "Page Name",
				Name = "Enemy Name",
 				Planets = {},
				Scans = 3,
				Type = "Ranged",
 				Weapons = { "Gorgon", "Sheev" },
			},
</syntaxhighlight>
<!-- See https://web.archive.org/web/20171225190648/http://wf.poedb.tw/item.php?n=ANGST for sample internal data; likely outdated but may serve some insight on how gameplay devs define certain attributes -->
{| class="wikitable sortable"
|-
! Key/Column Name || Internal Equivalent || Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Abilities</code> || N/A || Table (of strings) || ❌ || Array of abilities names || <code>{}</code>
|-
| <code>Actor</code> || N/A || String || ❌ || Voice actor of enemy || <code>"[DE]Rebecca"</code>
|-
| <code>CodexSecret</code> || <code>CodexSecret</code> || Boolean || ✔️ || Whether or not the enemy has an entry in the Codex before the player scans it; defaults to false || <code>true</code>
|-
| <code>Description</code> || <code>ShortDesc</code> || String || ❌ || Description of enemy as seen in the [[Codex]] || <code>"High damage minigun"</code>
|-
| <code>ExcludedFromSimulacrum</code> || <code>ExcludedFromSimulacrum</code> || Boolean || ❌ || Whether or not the enemy cannot be spawned in the [[Simulacrum]] || <code>true</code>
|-
| <code>Faction</code> || <code>Faction</code> || String || ✔️ || Associated [[Faction]] || <code>"Corpus"</code>
|-
| <code>FactionDamageOverride</code> || N/A || String || ❌ || Override for enemies with different faction resistance value instead of that usually matches their faction. || <code>"Grineer"</code>
|-
| <code>Image</code> || <code>Icon</code> || String || ✔️ || Image file name of the enemy as uploaded to the wiki. || <code>"CrewmanTech.png"</code>
|-
| <code>InternalName</code> || N/A || String || ✔️ || The full unique name of an enemy formatted as a file path || <code>"/Lotus/Types/Enemies/Grineer/AIWeek/Avatars/HeavyFemaleGrineerAvatar"</code>
|-
| <code>Introduced</code> || N/A || String || ✔️ || The game version in which the enemy was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || N/A || String || ✔️ || Page/article link to the enemy on the wiki || <code>"Scorch"</code>
|-
| <code>Missions</code> || N/A || Table (of strings) || ❌ || [[Star Chart]] mission nodes/mission types that enemy can appear in || <code>{ "Kuva Siphon" }</code>
|-
| <code>Name</code> || <code>LocTag</code> || String || ✔️ || Name of enemy || <code>"Scorch"</code>
|-
| <code>Planets</code> || N/A || Table (of strings) || ✔️ || [[Star Chart]] regions that enemy can appear in as seen in enemy's [[Codex]] entry || <code>{ "Earth", "Void", "Lua" }</code>
|-
| <code>Scans</code> || <code>CodexScansRequiredOverride</code> || Number (int) || ✔️ || Number of scans required to unlock the enemy's [[Codex]] entry || <code>3</code>
|-
| <code>Type</code> || N/A || String || ✔️ || Informal enemy categorization based on common characteristics and/or mechanics (e.g. can only perform [[Mercy]] finisher on "heavy" units) || <code>"Boss"</code>, <code>"Sniper"</code>, <code>"Heavy"</code>, or <code>"Light"</code>
|-
| <code>Weapons</code> || N/A || Table (of strings) || ❌ || Names of weapons that the enemy wields as stored in [[Module:Weapons/data]] (i.e. player usable weapons only) || <code>"Grakata"</code> or <code>"Dera"</code>
|-
|}

===Stats Subtable Schema===
<syntaxhighlight>
			Stats = {
				Affinity = 500,
				Armor = 500,
				BaseLevel = 8,
				Health = 300,
				Multis = { "Head: 3.0x" },
				ProcResists = {},
				Shield = 0,
				SpawnLevel = 8,
			}
</syntaxhighlight>
{| class="wikitable sortable"
|-
! Key/Column Name || Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Affinity</code> || Number (int) || ✔️ || Base [[Affinity]] value at base level || <code>500</code>
|-
| <code>Armor</code> || Number (int) || ❌ || Base [[Armor]] value at base level || <code>500</code>
|-
| <code>ArmorType</code> || String || ❌ (depreciated as of {{ver|36}}) || [[Armor]] class || <code>"Alloy Armor"</code>
|-
| <code>Attacks</code> || Table (of tables) || ❌ || Attack tables defining the base stats of enemy attacks || <code></code>
|-
| <code>BaseLevel</code> || Number (int) || ✔️ || Base enemy level used for [[Enemy Level Scaling]] || <code>1</code>
|-
| <code>Health</code> || Number (int) || ✔️ || Base [[Health]] value at base level || <code>300</code>
|-
| <code>HealthType</code> || String || ✔️ (depreciated as of {{ver|36}}) || [[Health]] class || <code>"Tenno Flesh"</code>
|-
| <code>Multis</code> || Table (of strings) || ❌ || Array of [[Enemy Body Parts]] multipliers || <code>{ "Head: 3.0x" }</code>
|-
| <code>Overguard</code> || Number (int) || ❌ || Base [[Overguard]] value at base level || <code>12</code>
|-
| <code>ProcResists</code> || Table (of strings) || ❌ || Array of [[Status Effect]]s that cannot be applied to enemy; can use "All" as a shorthand for all procs. || <code>{ "Virus", "Stagger" }</code>
|-
| <code>Shield</code> || Number (int) || ❌ || Base [[Shield]] value at base level || <code>0</code>
|-
| <code>ShieldType</code> || String || ❌ (depreciated as of {{ver|36}}) || [[Shield]] class || <code>"Proto Shield"</code>
|-
| <code>SpawnLevel</code> || Number (int) || ❌ || Enemy level at which enemy will first spawn at || <code>8</code>
|-
|}

====Attacks Subtable Schema====
<syntaxhighlight>
				Attacks = {
					{
						AttackName = "Normal Attack",
						CritChance = 0.3,
						CritMultiplier = 2,
						DamageDistribution = { Impact = 0.5, Puncture = 0.25, Slash = 0.25 },
						Multishot = 2,
						StatusChance = 0.3,
						BurstCount = 5,
						TotalDamage = 100,
					},
					{
						AttackName = "Melee Attack",
						CritChance = 0.3,
						CritMultiplier = 2,
						DamageDistribution = { Impact = 0.5, Puncture = 0.25, Slash = 0.25 },
						Multihit = 2,
						StatusChance = 0.3,
						BurstCount = 5,
						TotalDamage = 100,
					},
				}
</syntaxhighlight>
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>AttackName</code> || String || ✔️ || Editor-defined attack name || <code>"Normal Attack"</code>
|-
| <code>CritChance</code> || Number (float) || ❌ || Attack's [[Critical Chance]] || <code>0.5</code>
|-
| <code>CritMultiplier</code> || Number (float) || ❌ || Attack's [[Critical Multiplier]] || <code>2</code>
|-
| <code>DamageDistribution</code> || Table (dictionary-like) || ✔️ || Distribution of [[damage]] types as decimals || <code>{ Impact = 0.5, Puncture = 0.25, Slash = 0.25 }</code>
|-
| <code>Multishot</code> || Number (int) || ❌ || Attack's [[Multishot]] || <code>2</code>
|-
| <code>Multihit</code> || Number (int) || ❌ || Attack's [[Multihit]] || <code>2</code>
|-
| <code>StatusChance</code> || Number (float) || ❌ || Attack's [[Status Chance]] || <code>0.3</code>
|-
| <code>BurstCount</code> || Number (int) || ❌ || Attack's Burst Count || <code>5</code>
|-
| <code>Note</code> || String || ❌ || Editor-defined attack note || <code>Used when flying.</code>
|-
| <code>TotalDamage</code> || Number (int) || ✔️ || Attack's total base [[damage]] before enemy level scaling is applied || <code>75</code>
|-
|}

[[Category:Databases]]