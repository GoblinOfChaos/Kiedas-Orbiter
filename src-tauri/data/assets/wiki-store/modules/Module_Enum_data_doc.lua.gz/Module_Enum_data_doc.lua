Some examples of enums used by [[WARFRAME]]. For [[Upgrade]]s, see [[Module:Upgrades/data]]. See [[Text Icons]] for examples of text codes used in source strings before being interpreted as icons.

Information retrieved from manually looking into content within <code><script id="__NEXT_DATA__" type="application/json"></script></code> on different item pages on https://overframe.gg/ as well as looking into any JS scripts sent from static.overframe.gg on page load (look into browser developer tool debugger).
*See _next/static/chunks/pages/_app-<hash>.js

[[Category:Databases]]