Database for WARFRAME-specific [[languages]] and their glyphs.
[[Category:Databases]]