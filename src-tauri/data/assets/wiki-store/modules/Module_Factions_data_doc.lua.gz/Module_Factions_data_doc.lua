Database for [[WARFRAME]]'s [[Factions]].

==Faction Entry Schema==
<syntaxhighlight lang="lua">
	["Faction Name"] = {
		Description = "Faction Description",
		Image = "FactionName.png",
		Introduced = "31",
		Link = "Link Name",
		Name = "Faction Name",
	},
</syntaxhighlight>
{| class="wikitable"
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Description</code> || String || ✔️ || Description of faction as seen in-game || <code>"Support and rewards for Tenno fighting in active operations."</code>
|-
| <code>Image</code> || String || ✔️ || Image file name of the faction icon as uploaded to the wiki. Preferably using the "FactionName.png" naming convention. || <code>"SteelMeridian.png"</code>
|-
| <code>Introduced</code> || String || ✔️ || The game version in which the faction was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the faction on the wiki || <code>"The Holdfasts"</code>
|-
| <code>Name</code> || String || ✔️ || Name of faction || <code>"Arbiters of Hexis"</code>
|-
|}
[[Category:Databases]]