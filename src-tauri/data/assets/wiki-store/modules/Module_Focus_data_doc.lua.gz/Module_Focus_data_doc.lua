Database of [[WARFRAME]]'s [[Focus]] system.
[[Category:Databases]]