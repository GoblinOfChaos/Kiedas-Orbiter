<includeonly>{{#invoke:ModuleTest|main}}</includeonly>
==Visual test cases==
{{clr}}
<!-- Testing for:
* Mod variants
* Mods sharing page names (e.g. Scorch with Scorch (Mod))
* Seeing if unique symbols in mod name works, like apostraphes (') or dashes (-)
* Non standard mod images with Requiem and Peculiar mods
* Gallery wrapping to next row
-->
<pre>{{#invoke:Gallery|buildModGallery|Amalgam Barrel Diffusion|Barrel Diffusion|Primed Continuity|Scorch|Hunter's Bonesaw}}</pre>
{{CustomCollapsible||mod}}
{{#invoke:Gallery|buildModGallery|Amalgam Barrel Diffusion|Barrel Diffusion|Primed Continuity|Scorch|Seeker|Exalted Blade|Hunter's Bonesaw|Zazvat-Kar|Calm & Frenzy|Fass|Peculiar Growth}}
{{CustomCollapsible/End}}
<hr/>
<pre>{{#invoke:Gallery|buildWeaponGallery|Opticor Vandal|Opticor|MK1-Kunai|Dual Heat Swords|Exalted Blade}}</pre>
{{CustomCollapsible||weapon}}
{{#invoke:Gallery|buildWeaponGallery|Opticor Vandal|Opticor|MK1-Kunai|Dual Heat Swords|Exalted Blade}}
{{CustomCollapsible/End}}
{{clr}}
==Scribunto tests code==
<noinclude>[[Category:Lua test suites]]</noinclude>