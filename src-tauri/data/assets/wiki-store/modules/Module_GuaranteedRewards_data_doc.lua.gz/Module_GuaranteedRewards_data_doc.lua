Database for "guaranteed" rewards that are merit-based after completing some sort of milestone. Typically reserved for events that guarantee a reward to players that complete some sort of task. [[Quest]] rewards are also valid content to store in here.

==Reward Entry Schema==
<syntaxhighlight lang="lua">
{
	{ "Endo", "Resource", 15 },
	{ "Hawk Eye", "Mod" },
	{ "Shotgun Barrage", "Mod" },
	{ "Endo", "Resource", 50 },
	{ "Shock Absorbers", "Mod" },
	{ "Endo", "Resource", 100 } 
}
</syntaxhighlight>

# First element in each table element will be the mod's name as a string (required)
# Second element in each table element will be the item's type as a string (required)
# Third element in each table element will represent drop count as an integer (optional)

== Source Entry Schema ==
<syntaxhighlight lang="lua">
		["Event Name"] = {
			Link = "Event Article Name",
			Name = "Event Name",
			Rewards = {
				{ "Endo", "Resource", 15 },
				{ "Hawk Eye", "Mod" },
				{ "Shotgun Barrage", "Mod" },
				{ "Endo", "Resource", 50 },
				{ "Shock Absorbers", "Mod" },
				{ "Endo", "Resource", 100 } 
			},
			Type = "Event" 
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>InternalName</code> || String || ❌ || The full unique name of a reward table formatted as a file path || <code>""</code>
|-
| <code>Link</code> || String || ✔️ || Name of page on the wiki of the mission associated with reward table || <code>"Daily Tribute"</code>
|-
| <code>Name</code> || String || ✔️ || User-defined name of reward table to be displayed to readers || <code>"Daily Tribute"</code>
|-
| <code>Rewards</code> || Table (of tables) || ✔️ || Contains rewards that are guaranteed to be given to players ||
|-
| <code>Type</code> || String || ✔️ || Type of reward source || <code>"Event"</code>
|-
|}

==Reward Data==
[[Category:Databases]]