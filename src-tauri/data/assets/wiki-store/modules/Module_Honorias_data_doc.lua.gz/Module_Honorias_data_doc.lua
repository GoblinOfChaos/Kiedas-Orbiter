Database for all [[Honoria]]s in [[WARFRAME]]. Preferably put new honorias in the correct alphabetical order, but it is not necessary.
{{LatestEdit}}
__TOC__
==Honoria Entry Schema==
<syntaxhighlight lang="lua">
    ["Honoria Name"] = {
        Name = "Honoria Name",
        Link = "Honoria Name",
        Description = "How to obtain it",
        Position = "Suffix",
        Price = { ["Vainthorn"] = 70 },
        Introduced = "41",
        InternalName = "/Lotus/Types/Items/Titles/RoatheTitles/TitleDagath",
        CodexSecret = true,
        ExcludeFromCodex = true,
        Tags = { "Roathe" }
    },
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! [[Honoria]] EN L10n !! [[Public Export]] Equivalent !! Internal Equivalent !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>_IgnoreEntry</code> || N/A || N/A || N/A || Boolean || ❌ || For wiki internal use, denotes entries to ignore for usage on the wiki and data validation || <code>true</code>
|-
| <code>CodexSecret</code> || N/A || <code>codexSecret</code> || <code>CodexSecret</code> || Boolean || ❌ || Whether or not the Honoria title is hidden in the Codex prior to unlocking || <code>true</code>
|-
| <code>Description</code> || N/A || <code>description</code> || <code>description</code> || String || ❌ || Description or flavor text of the Honoria title || <code>"Awarded for beginning a relationship with..."</code>
|-
| <code>ExcludeFromCodex</code> || N/A || <code>excludeFromCodex</code> || <code>ExcludeFromCodex</code> || Boolean || ❌ || Denotes whether this title should be completely hidden/excluded from Codex tracking || <code>true</code>
|-
| <code>InternalName</code> || N/A || <code>uniqueName</code> || <code>TypeName</code> || String || ✔️ || Full internal unique name formatted as a file path || <code>"/Lotus/Types/Items/Titles/RoatheTitles/TitleDagath"</code>
|-
| <code>Introduced</code> || N/A || N/A || N/A || String || ✔️ || Game update version in which the title was introduced in [[WARFRAME]] || <code>"41"</code>
|-
| <code>Link</code> || N/A || N/A || N/A || String || ✔️ || Target wiki article name for the title || <code>"Abyssal Thorn"</code>
|-
| <code>Name</code> || N/A || <code>name</code> || <code>LocalizeTag</code> || String || ✔️ || Display name of the Honoria title || <code>"Abyssal Thorn"</code>
|-
| <code>Position</code> || N/A || N/A || N/A || String || ✔️ || Placement of the title relative to the player's username ("Prefix", "Suffix", or "Suffix & Prefix") || <code>"Suffix"</code>
|-
| <code>Price</code> || N/A || N/A || N/A || Table (dictionary) || ❌ || Cost/resources required to purchase or craft the title, formatted as resource-quantity key-value pairs || <code>{ ["Vainthorn"] = 70 }</code>
|-
| <code>Tags</code> || N/A || N/A || <code>Tags</code> || Table (array of strings) || ❌ || Classification tags associated with the title for filtering and categorization || <code>{ "Roathe" }</code>
|-
| <code>Rank</code> || N/A || N/A || N/A || Number || ❌ || Display order bypassing the alphabetical one (only works when filtering by tag) || <code>1</code>
|}

==Data Validation==

<pre>Checking for required keys</pre>
{{Column|3|
{{#invoke:Honorias/data/validate|checkRequiredKeysExist}}
}}
<hr />
<pre>Validating data types of values</pre>
{{Column|3|
{{#invoke:Honorias/data/validate|validateDataTypes}}
}}
<hr />
<pre>Validating data types of values</pre>
{{Column|3|
{{#invoke:Honorias/data/validate|validateFieldValues}}
}}


==References==
{{Reflist}}

==Honoria Data==
[[Category:Databases]]