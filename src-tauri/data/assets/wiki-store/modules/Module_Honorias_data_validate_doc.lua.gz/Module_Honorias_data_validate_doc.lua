== Examples ==

<code><nowiki>{{#invoke:Honorias/data/validate|checkRequiredKeysExist}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias/data/validate|validateDataTypes}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias/data/validate|validateFieldValues}}</nowiki></code>

===Checking for required keys===
{{Column|3|
{{#invoke:Honorias/data/validate|checkRequiredKeysExist}}
}}

===Validating data types of values===
{{Column|3|
{{#invoke:Honorias/data/validate|validateDataTypes}}
}}

===Validating data types of values===
{{Column|3|
{{#invoke:Honorias/data/validate|validateFieldValues}}
}}