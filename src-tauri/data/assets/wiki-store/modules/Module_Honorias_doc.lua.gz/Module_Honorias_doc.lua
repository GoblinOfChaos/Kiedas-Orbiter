<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Template ===
In template and articles: <code><nowiki>{{#invoke:Honorias|function|input1|input2|...}}</nowiki></code>

== Examples ==

<code><nowiki>{{#invoke:Honorias|getHonoriaCount}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|getHonoriaCount|position=Prefix}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|getHonoriaCount|position=Suffix}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|getHonoriaCount|position=Suffix & Prefix}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|getHonoriaCount|tag=Roathe}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|getHonoriaCount|tag=Hunhow}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|buildHonoriaTable}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|buildHonoriaTable|checklist=true|columns=Name, Position, Requirement}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|buildHonoriaTable|tag=Roathe|columns=Name, Position, Requirement, Tags}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|buildHonoriaTable|force=true|tag=Founder|columns=Name, Position, Requirement}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|buildHonoriaTable|checklist=true|rank=true|tag=Mastery|columns=Name, Position, Requirement}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|simpleHonoriaNameList}}</nowiki></code>

<code><nowiki>{{#invoke:Honorias|getValue|Abyssal Thorn|Name}}</nowiki></code>
}}

</onlyinclude>