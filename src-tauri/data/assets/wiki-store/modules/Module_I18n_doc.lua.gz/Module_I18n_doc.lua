{{UpdateMe|With latest update to MediaWiki v1.39, migrate message data stores from MediaWiki namespace to either Main or Template so that non-admins can contribute to localization on the wiki. There is now a native way to import JSON data to Lua modules.}}
{{Docbunto|I18n| preface =
== Usage ==
To use the module, you need to set up your messages in the appropriate place and correct format. The format of your messages should be as follows:

<syntaxhighlight lang="lua">
return {
    ["en"] = {
        ["message-name"] = "value"
    },
    ["pl"] = {
        ["message-name"] = "value"
    }
}
</syntaxhighlight>

Messages can have arguments for substitution in templates/modules - these should be specified in the form <code>$n</code> where n is a integer greater than 0, e.g, <code>"Hello, $1, my name is $2"</code>.

== Fetching the messages ==
The message loader will expect your messages to be in a Dev Wiki page such as <code>Module:PAGENAME/i18n</code>, where PAGENAME should be the name of your module. Alternatively, an absolute path can be supplied ('''if''' PAGENAME contains a ":").

Once you've set up the messages, there are two ways to fetch them.

1. Import the module into a Lua module and create a datastore instance using the '''<code>i18n.loadMessages</code>''' method:
<syntaxhighlight lang="lua">
local i18n = require('Module:I18n').loadMessages('PAGENAME', 'PAGENAME2')
-- If a PAGENAME contains a ":" the path will be treated as absolute!
</syntaxhighlight>

2. Fetch messages directly within your template:

<pre>
Template installation: {{#invoke:i18n|main}}

Template usage: {{i18n|getMsg|<PAGENAME>|<key>}}
</pre>

== Editing the messages ==
The editor used for I18n-js translations has also been made to work with translations using this module. Make sure you switch to Lua translations using the option in the edit dropdown on the [[Special:BlankPage/I18nEdit|translation picker screen]].

== Changelog ==
{{Scrollbox|1=<nowiki/>
;June 10, 2018 [ALPHA]
:[[User:KockaAdmiralac|KockaAdmiralac]]: JSON-centric prototype and template testing.
;June 12, 2018 (v0.5.0-v0.7.0)
:[[User:MACH-59330|MACH-59330]]: Port of [[I18n-js]] functions and Lua datastore support.
;June 13, 2018 (v0.8.0)
:[[User:MACH-59330|MACH-59330]]: Functional Lua prototype. Code cleanup and testing.
;June 16, 2018 (v0.9.0-v0.9.4)
:[[User:KockaAdmiralac|KockaAdmiralac]], [[User:MACH-59330|MACH-59330]]: Testing and tweaks.
<dl style="margin: -6px 0;"><dd>
* Failed testing of JSON support and caching.
* Subpage <code>/lang</code> detection fix.
</dd></dl>
;July 5, 2018 (v1.0.0 - v.1.0.2) [STABLE]
:[[User:MACH-59330|MACH-59330]]: Support for absolute source paths.
:[[User:Technobliterator|Technobliterator]]: Scope default datastore path to w:c:dev.
;July 12, 2018 (v1.0.3) [STABLE]
:[[User:KockaAdmiralac|KockaAdmiralac]]: Support for multiple message datastores.
;July 13, 2018 (v1.0.4)
:[[User:MACH-59330|MACH-59330]]: Permit wikitext parsing in messages.
;July 14, 2018 (v1.0.5)
:[[User:MACH-59330|MACH-59330]]: Respect <code>uselang</code> template parameter when fetching user language.
;July 20, 2018 (v1.0.6)
:[[User:KockaAdmiralac|KockaAdmiralac]]: Add <code>i18nd:in*</code> functions to reflect I18n-js's [[Special:Diff/80749|recently added functionality]].
;July 26, 2018 (v1.0.7)
:[[User:MACH-59330|MACH-59330]]: Add support for <code>qqx</code> message keys.
;July 28, 2018 (v1.0.7)
:[[User:MACH-59330|MACH-59330]]: Add <code>i18nd:getLang</code> for Lua modules.
;July 28, 2018 (v1.1.0)
:[[User:MACH-59330|MACH-59330]]: Language detection fixes; <code>uselang</code> as override.
;August 15, 2018 (v1.1.1)
:[[User:MACH-59330|MACH-59330]]: Language detection for <code>qqx</code>.
;September 12, 2018 (v1.1.2 - v1.2.0)
:[[User:MACH-59330|MACH-59330]]: Add <code>i18nd:fromSource</code>; support named parameters in <code>i18nd:msg</code>.
;September 12, 2018 (v1.3.0)
:[[User:MACH-59330|MACH-59330]]: Add template wrapper support through <code>i18n.main</code>.
;September 12, 2018 (v1.3.0)
:[[User:MACH-59330|MACH-59330]]: Add template wrapper support through <code>i18n.main</code>.
;November 6 & 13, 2018 (v1.3.1)
:[[User:MACH-59330|MACH-59330]]: Prioritise subpage language over user language by default.
:[[User:KockaAdmiralac|KockaAdmiralac]]: Add content language fallback for wikis without [[MediaWiki:Lang|<code><nowiki>{{int:lang}}</nowiki></code>]].
;November 19, 2018 (v1.3.2)
:[[User:MACH-59330|MACH-59330]]: Fix subpage test in <code>i18n.getLang</code>.
;November 20, 2018 (v1.3.2)
:[[User:MACH-59330|MACH-59330]]: Remove support for <code>qqx</code> detection (broken).
| collapse = 1
| padding = 1em
}}
}}