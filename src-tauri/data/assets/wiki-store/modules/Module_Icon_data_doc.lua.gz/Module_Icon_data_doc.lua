Database for miscellaneous icons used in [[WARFRAME]]. Some categories of items/icons/content are not large enough or unique enough in terms of properties to justify having their own database.

==Icon Entry Schema==
Item template:
<syntaxhighlight lang="lua">
	["Item name"] = {
		Description = "Item Description",
		Image = "ItemName.png",
		Link = "Link Name",
		Name = "Page Name",
		CssClasses = "CSS Classes"
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Description</code> || Boolean || ❌ || Description of icon || <code>"Modifies the Duration of Warframe Abilities and the Energy cost of toggled Abilities. Hover over each Ability to see how its stats are affected."</code>
|-
| <code>Image</code> || String || ✔️ || Image file name of the icon as uploaded to the wiki || <code>"Health.png"</code>
|-
| <code>Link></code> || String || ✔️ || Page/article link to the mod on the wiki || <code>"Health"</code>
|-
| <code>Name</code> || String || ✔️ || Name of item || <code>"Health"</code>
|-
| <code>CssClasses</code> || String || ❌ || CSS classes to be applied when icon is used in tooltips || <code>"light-invert"</code>
|-
|}

[[Category:Databases]]