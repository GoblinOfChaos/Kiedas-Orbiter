<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Template ===
In template: <code><nowiki>{{#invoke:Icon|function|input1|input2|...}}</nowiki></code><br />
In articles: <code><nowiki>{{Icon|Type|input1|input2|...}}</nowiki></code>

=== Module ===
<syntaxhighlight lang="lua">
local p = {}
local Icon = require('Module:Icon')

local function func(iconname, textexist, imagesize)
    return Icon._Item(iconname, textexist, imagesize)
end
</syntaxhighlight>
}}</onlyinclude>