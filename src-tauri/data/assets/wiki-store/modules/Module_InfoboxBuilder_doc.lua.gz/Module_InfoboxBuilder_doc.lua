<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
==Usage==
This module is meant to be used in other modules for constructing wikitext related to infoboxes. CSS rules for formatting infoboxes are located on [[MediaWiki:Common.css]].

A series of chaining functions will mimic the XML-like format of infoboxes:
<syntaxhighlight lang="lua">
local InfoboxBuilder = require('Module:InfoboxBuilder')
--...
local sampleInfobox = Infobox('WARFRAME Wiki:L10n/general.json', 'WARFRAME Wiki:L10n/meta.json')
	:title('Item Name')
	:image('Panel.png')
    :group()
    	:header('General Information')
			:row('type', 'Type', 'Resource')
			:row('rarity', 'Rarity', 'Rare')
		:done()
	:done()

mw.log(sampleInfobox)
--[=[
The above prints:
<div class="infobox"><div class="title">Item Name</div>[[File:Panel.png|300px|class=main-image]]<div class="group"><div class="header">General Information</div><div class="row"><div class="label left">Type</div><div class="value right">Resource</div></div><div class="row"><div class="label left">Rarity</div><div class="value right">Rare</div></div></div></div>

Prettified:
<div class="infobox">
	<div class="title">Item Name</div>
	[[File:Panel.png|300px|class=main-image]]
	<div class="group">
		<div class="header">General Information</div>
		<div class="row">
			<div class="label left">Type</div>
			<div class="value right">Resource</div>
		</div>
		<div class="row">
			<div class="label left">Rarity</div>
			<div class="value right">Rare</div>
		</div>
	</div>
</div>
--]=]
</syntaxhighlight>
}}
</onlyinclude>