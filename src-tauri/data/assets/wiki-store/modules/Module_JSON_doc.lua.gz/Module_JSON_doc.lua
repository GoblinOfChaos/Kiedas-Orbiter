<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Module ===
<syntaxhighlight lang="lua">
local JSON = require('Module:JSON')
</syntaxhighlight>

== External Links ==
*See http://lua-users.org/wiki/JsonModules for more JSON (de)serializer Lua modules
}}</onlyinclude>