Database for [[Quest]]s and [[Keys]]. See ExportKeys file on [[Public Export]] for initial data seeding.
{{LatestEdit}}
==Quest Entry Schema==
<syntaxhighlight lang="lua">
{
	CodexSecret = false,
	Description = "Quest in-game description",
	Image = "QuestName.png",
	InternalName = "/Lotus/Types/Keys/",
	Introduced = "Vanilla",
	Link = "Quest article name",
	Name = "Quest name",
	NextQuest = "",
	PreviousQuest = "",
    Replayable = false,
	Type = "Quest type",
},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>CodexSecret</code> || Boolean || ✔️ || Whether or not the quest has an entry in the [[Codex]] before the player has access to it; defaults to false || <code>true</code>
|-
| <code>Description</code> || String || ✔️ || In-game description of quest as shown in Codex || <code>"Void Storms gather in Corpus lanes... could a mysterious vessel somehow be the cause?"</code>
|-
| <code>ExcludeFromCodex</code> || Boolean || ❌ || Whether or not the quest has an entry in the [[Codex]] regardless if the player has access to it or not; defaults to false || <code>true</code>
|-
| <code>Image</code> || String || ✔️ || Image file name of quest as uploaded to the wiki || <code>"AngelsoftheZariman.png"</code>
|-
| <code>InternalName</code> || String || ✔️ || Internal code name of quest || <code>"/Lotus/Types/Keys/ZarimanQuest/ZarimanQuestKeyChain"</code>
|-
| <code>Introduced</code> || String || ✔️ || The game version in which the quest was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the quest on the wiki || <code>"Vox Solaris (Quest)"</code>
|-
| <code>Name</code> || String || ✔️ || Quest name || <code>"Vox Solaris"</code>
|-
| <code>NextQuest</code> || String || ❌ || Name of the next quest in sequence || <code>"The New War"</code>
|-
| <code>PreviousQuest</code> || String || ❌ || Name of the previous quest in sequence || <code>"Erra"</code>
|-
| <code>Replayable</code> || Boolean || ✔️ || Whether or not the quest is replayable after completion || <code>true</code>
|-
| <code>Type</code> || String || ✔️ || Quest type as defined by editors || <code>"Main Quest"</code>
|-
|}
[[Category:Databases]]