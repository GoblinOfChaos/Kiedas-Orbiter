<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==

=== Module ===
<syntaxhighlight lang="lua">
local Localization = require('Module:Localization')

local function func(input)
    return Localization._getLocalizationMessages(fileName, messagePath)
end
</syntaxhighlight>


== Localization Details ==
WARFRAME's localization messages are in the form of a file path, usually starting with "/Lotus/Language/". As of {{ver|41}}, these are the third-level directories:
{{Column|4|
* 1999
* 1999Bounties
* 1999Challenges
* 1999Coda
* 1999Demo
* 1999Echoes
* 1999PvPvE - [[Faceoff]]
* 1999Quest - [[The Hex (Quest)]]
* Alchemy - [[Alchemy]]
* Alerts
* Apostasy - [[Apostasy Prologue]]
* Arcanes - [[Arcane Enhancement]]
* Archive
* Armour
* BardQuest - [[Octavia's Anthem]]
* BaroTreasureBox
* Blessings
* Boosters
* Bosses - [[Bosses]]
* Bundles
* CapturaScenes - [[Captura]]
* Challenges
* Champions - [[Rathuum]]
* Changyou - [[WARFRAME (China)]]
* Chimera - [[Chimera Prologue]]
* CircleOfHell - [[The Descendia]]
* CitrinesLastWish
* ClanTech - [[Research]]
* Codex - [[Codex]]
* CommunityMessages
* Consumables
* CorpusGasCity - [[Corpus Gas City]]
* CorpusRailjack
* Cosmetics
* CraftingComponents
* CrewShip - [[Railjack]]
* Currency
* DagathUpdate - [[Abyss of Dagath]]
* DanteUnbound - [[Dante Unbound]]
* DeadlockProtocol - [[The Deadlock Protocol]]
* Deluxe - [[Deluxe Skins]]
* DisruptionMission - [[Disruption]]
* Dojo - [[Clan Dojo]]
* DojoDecos1999
* DojoDecosCorpus
* DojoDecosDuviri
* DojoDecosFestive
* DojoDecosGrineer
* DojoDecosInfested
* DojoDecosNpcs
* DojoDecosOrokin
* DojoDecosOstron
* DojoDecosSolaris
* DojoDecosTenno
* DojoDecosZariman
* DojoPaints - [[Pigment]] and [[Backdrop]]
* Duviri - [[Duviri]]
* EidolonPlains - [[Plains of Eidolon]]
* Emotes - [[Emotes]]
* Enemies
* EnemyLeaders - [[Prosecutor]]
* Entrati - [[Entrati]]
* EntratiLab - [[Albrecht's Laboratories]]
* Ephemera - [[Ephemera]]
* Episodes - [[Nightwave]]
* Equipment
* Events - [[Event]]
* Fish - [[Fishing]]
* FiveFates - [[Koumei and the Five Fates]]
* Focus - [[Focus]]
* Fragments - [[Fragments]]
* G1Quests - 1st Generation of [[Quest]]
* G1Taunts
* Game
* GameModes
* Gems - [[Mining]]
* Gifts
* GlassQuest - [[Saya's Vigil]]
* Glyphs - [[Glyph]]
* Heirloom - [[Heirloom Skins]]
* HolsterCustomizations
* Horse - [[Kaithe]]
* Hoverboards - [[K-Drive]]
* Inbox
* InfestedBand - [[Technocyte Coda]]
* InfestedMicroplanet - [[Deimos]]
* InfestedMicroplanetQuest - [[Heart of Deimos]]
* Intrinsics - [[Intrinsics]]
* Isleweaver - [[Isleweaver]]
* ItemDescription
* Items
* JadeShadows - [[Jade Shadows]]
* JunctionReworkChallenges - [[Junction]]
* KahlQuest - [[Veilbreaker]]
* Kingpins - [[Adversary System]]
* LastWish - [[Citrine's Last Wish]]
* Locations - [[Star Chart]]
* LotusEaters - [[The Lotus Eaters]]
* Marketing
* Menu
* Messages
* Missions
* ModQuest - [[The Teacher]]
* Mods - [[Mod]]
* Narmer - [[Narmer]]
* Necromech - [[Necramech]]
* NewPlayerQuest - [[Awakening]]
* NewWar - [[The New War]]
* NewWarIntro
* Ngen - 8th Generation Console Skins
* NightwaveChallenges
* NightwaveSeasonThree
* NokkoColony - [[The Vallis Undermind]]
* Npcs
* Objectives
* Objects
* OldPeace - [[The Old Peace]]
* Omega - [[Riven Mods]]
* Onslaught - [[Sanctuary Onslaught]]
* Operator - [[Operator]]
* Oraxia - [[Oraxia]]
* OstronCrafting - [[Amp]], [[Zaw]]
* OstronJobs - [[Cetus Bounty]]
* PersonalQuarters
* Pets - [[Companion]]
* Plants
* PrimePacks - [[Prime Vault]]
* Primes
* PrimeStore - [[Prime Resurgence]]
* Props
* Quests - [[Quest]]
* Railjack - [[Empyrean]]
* RelayReconstruction - [[The Pyrus Project]]
* Relics - [[Void Relic]]
* Resources - [[Resources]]
* RevenantQuest - [[Mask of the Revenant]]
* Sacrifice - [[The Sacrifice]]
* Scans - [[Codex]]
* Seasonal
* ShipDecorations - [[Orbiter Decorations]]
* ShipFeatureItems
* Sigils - [[Sigils]]
* Skins
* SolarisJobs - [[Fortuna Bounties]]
* SolarisQuest - [[Vox Solaris (Quest)]]
* SolarisVenus - [[Orb Vallis]]
* SquadLink - [[Operation: Orphix Venom]]
* SteamWorkshop - [[TennoGen]]
* Stickers
* Subtitles
* Suits - [[Warframes]] and Warframe [[Abilities]]
* Syandanas - [[Syandana]]
* SyndicateRewards
* Syndicates - [[Syndicate]]
* Synthetics
* Tarot - [[Prex]]
* TauPrequel - [[The Old Peace]]
* Titles - [[Honoria]]
* Tokens - [[Granum Crown]]
* UIStyle
* UnrealTournament - [[Unreal Tournament Skins]]
* Upgrades
* Veilbreaker - [[Veilbreaker]]
* VoidEclipse - [[Zariman Ten Zero]]
* WarframeCrafting
* Weapons - [[Weapons]]
* WraithQuest - [[Call of the Tempestarii]]
* YareliQuest - [[Waverider]]
* Zariman - [[Zariman]] and [[Incarnon]]
* ZarimanApartment - [[Dormizone]]
* ZarimanQuest - [[Angels of the Zariman]]
}}

}}</onlyinclude>