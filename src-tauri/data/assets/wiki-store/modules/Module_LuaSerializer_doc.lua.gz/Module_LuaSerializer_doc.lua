<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:LuaSerializer|serialize|input1}}</nowiki></code>

For example, input <code><nowiki>{{#invoke:LuaSerializer|serialize|Acquisition}}</nowiki></code> to [[Special:ExpandTemplates]] in order to get the prettified version of the table returned by [[Module:Acquisition/data]].
}}</onlyinclude>