<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:MasteryRank|function|input1|input2|...}}</nowiki></code>
}}</onlyinclude>