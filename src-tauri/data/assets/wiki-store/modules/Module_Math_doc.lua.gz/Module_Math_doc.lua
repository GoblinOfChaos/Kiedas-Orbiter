<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Math|function|input1|input2|...}}</nowiki></code>

=== Template ===
In template: <code><nowiki>{{#invoke:Math|__main}}</nowiki></code><br />
In articles: <code><nowiki>{{template|function|input1|input2|...}}</nowiki></code>

=== Module ===
<syntaxhighlight lang="lua">
local p = {}
local math = require('Module:Math')

local pi = math.pi
local absSTL = math.__abs

local function func(input)
    -- ...
    -- input -> stuff
    -- ...
    return math.eval(stuff)
end
</syntaxhighlight>
}}</onlyinclude>