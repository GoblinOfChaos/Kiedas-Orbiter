__TOC__
Database for [[maximization]] of [[Warframes|warframe]] stats and [[abilities]].
==Ability Entry Schema==
<syntaxhighlight lang="lua">
	["Ability Name"] = {
		ins = {
		    { name='Input Name', max='Input Max Value', cont='Content to place around the input (dictated by data-input-place)' },
		    'Input wikitext string',
		},
		outs = {
		    { 'Right column wikitext', { name='Output Name', expr='Output Formula', suff='Text placed after the output (e.g. units)' }},
		    { { expr='Output Formula', fmt='7sig' }, 'Left column wikitext' }
		},
		post = 'Any wikitext to insert after the calculator'
	},
</syntaxhighlight>
[[Module:Maximization]] constructs the overall HTML structure (using wikitext), currently it's a table with prebuilt Warframe stat inputs.   

All input/output object fields turn into <code>data-*</code> attributes for [[MediaWiki:Gadget-MathVM]] (click to see the spec), except <code>cont</code> and <code>suff</code>.
<div style="display: grid; grid-template: 'top top' 'left right'; gap: 0 40px; padding: 0 40px 0 0;">
{| class="wikitable sortable" style="grid-area:top"
|+Ability Object
|-
!Key!!Description
|-
|<code>ins</code>||Contains '''additional''' inputs as objects or strings. Object form contains a special <code>cont</code> field used as descripion of the input.
|-
|<code>outs</code>||Contains '''all''' of the outputs as 2-wide arrays of outputs as objects or strings. Object form contains a special <code>suff</code> field used as units after the output.
|-
|<code>post</code>||Contains content inserted after the calculator.
|}
{| class="wikitable sortable" style="grid-area:left"
|+Prebuilt Variables
|-
!Name!!Description
|-
|<code>STR</code>||Value of {{Stat|Ability Strength}}
|-
|<code>RNG</code>||Value of {{Stat|Ability Range}}
|-
|<code>EFF</code>||Value of {{Stat|Ability Efficiency}}
|-
|<code>DUR</code>||Value of {{Stat|Ability Duration}}
|-
|<code>COST</code>||Scaling factor for [[Ability_Efficiency#Mechanics|Ability Cost]]
|-
|<code>DRAIN</code>||Scaling factor for [[Ability_Efficiency#Mechanics|Ability Drain]]
|-
|<code>GenericIns.ModdableMelee</code>
|A set of generic ins for fully moddable [[Exalted Weapon]] melee
*Can be combined with other ins using <code>merge()</code>.
|}
{| class="wikitable" style="grid-area:right"
|+Standard Units
|-
!Unit!!Description
|-
!colspan=2|Time
|-
|<code>ms</code>||millisecond
|-
|<code>s</code>||second
|-
|<code>min</code>||minute
|-
|<code>h</code>||hour
|-
!colspan=2|Distance
|-
|<code>m</code>||metre
|-
|<code>km</code>||kilometre
|}
</div>
==Style Guide==
#Each ability's data should contain calculations of innate stats (e.g. energy, damage, [[DoT]]s), and kit interactions (i.e. passive, abilities, and augments of the original warframe). Adding calculations for third-party buffs would bloat calculators.
#*If the ability can be [[infused]], the calculator must contain toggles for original kit interactions (e.g. {{A|Shuriken}} doing less {{D|Bleed}} without {{WF|Ash}}'s passive) and must '''not''' contain potential interactions with a new warframe. 
#*For conciseness, users are expected to know their [[damage type]], and to manually apply [[faction weakness]] (shown in tooltips) and enemy [[damage reduction]].
#The type of damage an ability does innately must be stated clearly (e.g. "{{D|Cold}} damage" for {{A|Freeze}}), same applies to procs (e.g. {{D|Bleed}} is not the same as {{D|Slash}}).
#Input and output text must clearly state the intent behind its value (e.g. "damage ''bonus''" is additional damage %, "damage ''modifier''" is total damage %, "damage" is exact damage).
#Text for inputs with values should end in ":", text for checkbox inputs should end in "?" but written like a statement instead of a question.
#If multiple ability blocks are invoked together, and some inputs or outputs represent the same concept but should not be synced or shadowed - you should rename them at the source, following the <code>NAME_WARFRAME_KEY</code> format.
#*For example: both {{A|Shuriken}} and {{A|Blade Storm}} belong to {{WF|Ash}} and have base damage outputs (<code>BASE_DMG</code>). They were renamed <code>BASE_DMG_ASH_1</code> and <code>BASE_DMG_ASH_4</code>.

==See Also==
[[Module:Maximization/data/doc]]
<noinclude>
[[Category:Databases]]
</noinclude>