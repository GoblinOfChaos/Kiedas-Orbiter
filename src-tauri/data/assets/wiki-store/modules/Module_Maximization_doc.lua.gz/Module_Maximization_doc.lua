<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Maximization|ability|ability_name}}</nowiki></code>

=== Template ===
In template: <code><nowiki>{{#invoke:Maximization|ability|ability_name}}</nowiki></code><br />
In articles: <code><nowiki>{{MaximizationCalculator|ability_name}}</nowiki></code>
}}</onlyinclude>