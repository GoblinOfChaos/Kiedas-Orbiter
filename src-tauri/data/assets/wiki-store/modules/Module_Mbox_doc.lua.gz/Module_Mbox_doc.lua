<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Mbox|function|input1|input2|...}}</nowiki></code>

=== Template ===
In template: <code><nowiki>{{#invoke:Mbox|__main}}</nowiki></code><br />
In articles: <code><nowiki>{{template|function|input1|input2|...}}</nowiki></code>
}}</onlyinclude>