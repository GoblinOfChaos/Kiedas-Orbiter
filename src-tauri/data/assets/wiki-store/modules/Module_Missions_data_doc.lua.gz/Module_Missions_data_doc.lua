{{UpdateMe|Some junctions have moved around. Reflect on node progression changes. E.g. Pluto goes to Eris now and then Sedna. Mars goes to Deimos and then Jupiter now}}
Database of [[Star Chart]] mission nodes.
{{LatestEdit}}
==Mission Node Entry Schema==
<syntaxhighlight lang="lua">
{
	CreditsReward = 0,
	DropTableAlias = "Drop table entry key in Module:DropTables/data",
	Enemy = "Enemy faction",
	InternalName = "SolNode0",
	Introduced = "Vanilla",
	Link = "Node article name",
	MaxLevel = 11,
	MinLevel = 6,
	Name = "Node name",
	NextNodes = { "" },
	Planet = "Planet name",
	PreviousNodes = { "" },
	Quotes = "Quotes article name",
	Tileset = "Tileset name",
	Type = "Mission type",
},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>AdditionalCreditReward</code> || Number (integer) || ❌ || Additional number of [[Credits]] rewarded at end-of-mission (separate from Credit pickups from enemies/containers, hover over Credits in end-of-mission summary for itemized list) || <code>5000</code>
|-
| <code>Boss</code> || String || ❌ || For [[Assassination]] missions, the corresponding boss' page name on the wiki || <code>"General Sargas Ruk"</code>
|-
| <code>CacheDropTableAlias</code> || String || ❌ || Key of associated [[Resource Cache]] or Railjack [[Points of Interest]] [[Drop Tables|Drop Table]] entry as stored in [[Module:DropTables/data]] || <code>"CorpusVeilProximaCaches"</code>
|-
| <code>CreditReward</code> || Number (integer) || ❌ || Number of [[Credits]] rewarded at end-of-mission based the equation 1000 + 100 * (Minimum Enemy Level - 1) (separate from Credit pickups from enemies/containers, hover over Credits in end-of-mission summary for itemized list) || <code>5000</code>
|-
| <code>DSResourceBonus</code> || Number (float) || ❌ || For [[Dark Sectors]], the [[Resource]] drop bonus as a decimal percentage || <code>0.1</code>
|-
| <code>DSWeapon</code> || String || ❌ || For [[Dark Sectors]], the weapon class that recieves additional affinity bonus || <code>"Rifles"</code>
|-
| <code>DSWeaponBonus</code> || Number (float) || ❌ || For [[Dark Sectors]], the [[Affinity]] bonus as a decimal percentage for a specific type of weapon || <code>0.05</code>
|-
| <code>DSXPBonus</code> || Number (float) || ❌ || For [[Dark Sectors]], the [[Affinity]] bonus as a decimal percentage || <code>0.1</code>
|-
| <code>DropTableAlias</code> || String || ❌ || Key of associated end-of-mission or reward rotation [[Drop Tables|Drop Table]] entry as stored in [[Module:DropTables/data]] || <code>"Survival1"</code>
|-
| <code>Drops</code> || Table (of strings) || ❌ || For [[Assassination]] missions, the names of items that the boss drops components/blueprints for || <code>{ "Hydroid" }</code>
|-
| <code>Enemy</code> || String || ✔️ || Enemy faction name || <code>"Grineer"</code>
|-
| <code>ExtraDropTableAlias</code> || String || ❌ || Key of associated end-of-mission bonus [[Drop Tables|Drop Table]] entry as stored in [[Module:DropTables/data]] || <code>"ConjunctionSurvival1Extra"</code>
|-
| <code>FighterMaxLevel</code> || Number || ❌ ||  For Empyrean missions, maximum starting fighter level || <code>68</code>
|-
| <code>FighterMinLevel</code> || Number || ❌ || For Empyrean missions, minimum starting fighter level || <code>62</code>
|-
| <code>Image</code> || String || ❌ || Optional image file name of mission as uploaded to the wiki || <code>"Plains of Eidolon.png"</code>
|-
| <code>InternalName</code> || String || ✔️ || Internal code name of mission node || <code>"SolNode0"</code>
|-
| <code>Introduced</code> || String || ❌ || The game version in which the node was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>IsArchwing</code> || Boolean || ❌ || Denotes whether or not a node is an [[Archwing]] mission (not the same as [[Railjack]]); default false || <code>true</code>
|-
| <code>IsCrossfire</code> || Boolean || ❌ || Denotes whether or not multiple factions are actively combating on the node || <code>false</code>
|-
| <code>IsDarkSector</code> || Boolean || ❌ || Denotes whether or not a node is a [[Dark Sector]] mission; default false || <code>true</code>
|-
| <code>IsHidden</code> || Boolean || ❌ || Denotes whether or node is hidden from players to select on Star Chart || <code>true</code>
|-
| <code>IsRailjack</code> || Boolean || ❌ || Denotes whether or not a node is an [[Empyrean]] mission; default false || <code>true</code>
|-
| <code>IsTracked</code> || Boolean || ❌ || Denotes whether or not a node is counted towards [[Player Profile]] progress || <code>true</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the mission node on the wiki || <code>"Lex (Node)"</code>
|-
| <code>MaxLevel</code> || Number (integer) || ✔️ || Maximum starting enemy level || <code>11</code>
|-
| <code>MinLevel</code> || Number (integer) || ✔️ || Minimum starting enemy level || <code>6</code>
|-
| <code>Name</code> || String || ✔️ || Mission node name || <code>"Kappa"</code>
|-
| <code>NextNodes</code> || Table (of strings) || ❌ || Name of the node(s) after current node on the Star Chart || <code>{ "Baal", "Morax" }</code>
|-
| <code>Other</code> || String || ❌ || A letter that corresponds to the map on [[Defense#Defense Types]] || <code>"F"</code>
|-
| <code>Pic</code> || String || ❌ || For [[Assassination]] missions, the file name of the corresponding boss' sigil drop or the file name of the image associated with the mission node || <code>"CaptainVor_sigil_b.png"</code> or <code>"SolarisUnitedSigil.png"</code>
|-
| <code>Planet</code> || String || ✔️ || Name of region that node is on || <code>"Kuva Fortress"</code>
|-
| <code>PreviousNodes</code> || Table (of strings) || ❌ || Name of the node(s) before current node on the Star Chart || <code>{ "Stöfler", "Pavlov" }</code>
|-
| <code>Quotes</code> || String || ❌ || Name of the article containing transcriptions and audio of dialogue spoken in that mission || "Captain Vor/Quotes"
|-
| <code>RegionResources</code> || Table (of strings) || ❌ || An array of resource names that are possible drops from enemies and containers in that region. Automatically added to mission entries when script is executed so no need to add this key directly. || <code>{ "Ferrite", "Alloy Plate", "Argon Crystal", "Control Module" }</code>
|-
| <code>Requirements</code> || String || ❌ || Wikitext that describes a unique conditional that players have to meet before gaining access to a mission node (other than completing previous nodes) || <code><nowiki>"Completion of [[The War Within]]"</nowiki></code> or <code><nowiki>"Must have [[Mutalist Alad V Assassinate Key]]"</nowiki></code>
|-
| <code>Tileset</code> || String || ✔️ || [[Tile Sets|Tile set]] that is used in mission || <code>"Grineer Forest"</code>
|-
| <code>Type</code> || String || ✔️ || Mission type || <code>"Survival"</code>
|-
|}

==Mission Type Entry Schema==
<syntaxhighlight lang="lua">
		Assassination = {
			Name = "Assassination",
			Link = "Assasination",
			Introduced = "Vanilla",
			Index = 0,
			IsEndless = false,
			InternalName = "MT_ASSASSINATION",
			RewardRotation = "AABC",
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Index</code> || Number (integer) || ❌ || If known, the internal numerical index assigned to the mission type || <code>2</code>
|-
| <code>InternalName</code> || String || ✔️ || Internal code name of mission type || <code>"MT_CAPTURE"</code>
|-
| <code>IsEndless</code> || Boolean || ✔️ || If true, mission is endless meaning players can continue to get rewards after objective is complete || <code>true</code>
|-
| <code>Introduced</code> || String || ✔️ || The game version in which the mission type was first introduced in the global build of [[WARFRAME]] || <code>"29.5"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the mission type on the wiki || <code>"Orphix (Mission)"</code>
|-
| <code>Name</code> || String || ✔️ || Mission type name || <code>"Assassination"</code>
|-
| <code>RewardRotation</code> || String || ❌ || Describes the default reward rotation for endless missions. Note that [[Arbitrations]] variant of nodes will differ. || <code>"AABC"</code>
|-
|}

==Mission Modifier Entry Schema==
<syntaxhighlight lang="lua">
		["Arcana Isolation Vault Bounty"] = {
			Name = "Arcana Isolation Vault Bounty",
			Link = "Isolation Vault",
			LocationNote = "*[[Cambion Drift]], [[Deimos]]; must complete initial [[Isolation Vault]] Bounty to unlock access to Arcana Vaults from [[Mother]] outside of Vaults"
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Link</code> || String || ✔️ || Page/article link to the mission modifier on the wiki || <code>"Archon Hunt"</code>
|-
| <code>LocationNote</code> || String || ✔️ || Wikitext that briefly describes where players can encounter this modifier || <code><nowiki>"*[[Orb Vallis]], [[Venus]]"</nowiki></code>
|-
| <code>Name</code> || String || ✔️ || Mission modifier name || <code>"Sortie"</code>
|-
|}

==Different Methods Of Indexing Data==
This module will also provide additional subtables under the <code>p.by</code> key that help developers access one or more mission nodes' data entries based on certain key-value matches:
<syntaxhighlight lang="lua">
local MissionData = mw.loadData('Module:Missions/data')

-- Find all nodes with the Interception mission type (i.e. Type = "Interception")
-- Note that all values from MissionData.by.Key.["SearchTerm"] will be table types
MissionData.by.Type["Interception"]

-- Equivalent to:
local interceptionNodes = {}
for name, nodeEntry in pairs(MissionData.MissionDetails) do
    if (nodeEntry.Type == "Interception") then
        table.insert(interceptionNodes, nodeEntry)
    end
end

-- Find all nodes with the name "Hydron" (i.e. Name = "Hydron")
MissionData.by.Name["Hydron"]
</syntaxhighlight>

==Node Mastery EXP Research==
Some sources for research on Mastery EXP given by each node on first completion:
*https://www.reddit.com/r/Warframe/comments/hwk6tg/node_by_node_solar_map_mastery_numbers/
*https://www.reddit.com/r/Warframe/comments/4rzu3v/anyone_know_how_the_new_star_chart_mastery_works/

==Data Validation==
===Checking for required keys===
{{Column|3|
{{#invoke:Missions/data/validate|checkRequiredKeysExist}}
}}

===Validating data types of values===
{{Column|3|
{{#invoke:Missions/data/validate|validateDataTypes}}
}}

==Mission Node Data==
[[Category:Databases]]