<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Missions|function|input1|input2|...}}</nowiki></code>

=== Template ===
In template: <code><nowiki>{{#invoke:Missions|function|input1|input2|...}}</nowiki></code><br />
In articles: <code><nowiki>{{template|function|input1|input2|...}}</nowiki></code>

=== Module ===
<syntaxhighlight lang="lua">
local Mission = require('Module:Missions')

local function func(frame)
    return Mission.getMissions(frame)
end
</syntaxhighlight>

===Product Backlog===
*Add documentation 19:28, 3 July 2021 (UTC)

}}</onlyinclude>