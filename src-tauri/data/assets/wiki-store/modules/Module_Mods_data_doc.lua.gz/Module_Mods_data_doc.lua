Database for all [[Mod]]s in [[WARFRAME]] (with the exception of unveiled [[Riven Mods]]). Preferably put new mods in the correct alphabetical order, but it is not necessary.
{{LatestEdit}}
__TOC__
==Mod Entry Schema==
<syntaxhighlight lang="lua">
	["Mod Name"] = {
		BaseDrain = 0,
		Conclave = false,
		Description = "Description on mod card at max rank",
		Icon = "ModName.png",
		Image = "ModNameMod.png",
		InternalName = "",
		Incompatible = { "Primed Mod Name", "Flawed Mod Name" },
		Introduced = "29",
		IsExilus = false,
		IsFlawed = false,
		Link = "Page Name",
		MaxRank = 5,
		Name = "Mod Name",
		Polarity = "Madurai",
		Rarity = "Rare",
		Tradable = true,
		Transmutable = true,
		Type = "Primary",
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! [[Arsenal]] EN L10n !! [[Public Export]] Equivalent !! Internal Equivalent !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>_IgnoreEntry</code> || N/A || N/A || N/A || Boolean || ❌ || For wiki internal use, denotes entries to ignore for purposes of usage on the wiki (e.g. total mod count) and data validation || <code>true</code>
|-
| <code>BaseDrain</code> || N/A || <code>baseDrain</code> || <code>BaseDrain</code> || Number (integer) || ✔️ || Base mod capacity drain at Rank 0 || <code>2</code>
|-
| <code>Class</code> || N/A || N/A || <code>IsImmortal</code>, <code>IsGalvanized</code> || String || ❌ || For mods with a special material on their mod card, the class name that describes these types of mods (different from rarity) || <code>"Galvanized"</code> or <code>"Requiem"</code>
|-
| <code>CodexSecret</code> || N/A || <code>codexSecret</code> || <code>CodexSecret</code> || Boolean || ✔️ || Whether or not the mod has an entry in the [[Codex]] before the player acquires it; defaults to false || <code>false</code>
|-
| <code>CompatibilityTags</code> || N/A || N/A || <code>CompatibilityTags</code> or <code>compatibilityTags</code> || Table (array of strings) || ❌ || Tags that denote item compatibility. In other words, an item with one these tags can/cannot have this particular mod installed. || <code>{ "POWER_WEAPON" }</code>
|-
| <code>Conclave</code> || N/A || N/A || <code>AvailableOnPvp</code> || Boolean || ❌ || Whether or not the mod can be used in [[Conclave]] || <code>false</code>
|-
| <code>Description</code> || N/A || <code>levelStats</code> or/and <code>description</code> (some mods like auras have their in-game descriptions split between <code>levelStats</code> and <code>description</code>) || <code>LocTag</code> or <code>description</code> || String || ✔️ || Description of mod at max rank || <code>"+165% Damage"</code>
|-
| <code>Icon</code> || N/A || <code>textureLocation</code> || <code>Icon</code> || String || ✔️ || Image file name of the mod image as uploaded to the wiki. Preferably using the "ModName.png" naming convention. || <code>"BattleStations.png"</code>
|-
| <code>Image</code> || N/A || N/A || N/A || String || ✔️ || Image file name of the full mod card (with text) as uploaded to the wiki. Preferably using the "ModNameMod.png" naming convention. || <code>"BattleStationsMod.png"</code>
|-
| <code>Incompatible</code> || N/A || N/A || N/A || Table || ❌ || Table containing the mods that cannot be equipped with at the same time || <code>{ "Primed Flow", "Flawed Flow" }</code>
|-
| <code>IncompatibilityTags</code> || N/A || N/A || <code>IncompatibilityTags</code> || Table (array of strings) || ❌ || Tags that denote item incompatibility. In other words, items with these tags cannot have this particular mod installed. || <code>{ "POWER_WEAPON" }</code>
|-
| <code>InternalName</code> || N/A || <code>uniqueName</code> || <code>TypeName</code> || String || ✔️ || The full unique name of a mod formatted as a file path || <code>"/Lotus/Upgrades/Mods/Rifle/WeaponDamageAmountMod"</code>
|-
| <code>Introduced</code> || N/A || N/A || N/A || String || ✔️ || The game version in which the mod was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>IsAbilityAugment</code> || N/A || N/A || <code>IsAbilityAugment</code> || Boolean || ❌ || Whether or not the mod is classified as [[Warframe Augment Mods]] or augment mods for abilities (including Archwing) || <code>true</code>
|-
| <code>IsDefaultUpgrade</code> || N/A || N/A || N/A || Boolean || ❌ || Whether or not the mod is a hidden innate upgrade to some weapons (e.g. {{Weapon|Komorex}}'s innate ammo mutation) || <code>true</code>
|-
| <code>IsExilus</code> || N/A || <code>isUtility</code> || <code>IsUtility</code> || Boolean || ❌ || Whether or not the mod can be installed to the [[Exilus]] slot || <code>true</code>
|-
| <code>IsFlawed</code> || N/A || N/A || <code>IsStarter</code> || Boolean || ❌ || Whether or not the mod is a [[Flawed Mods|Flawed mod]] || <code>true</code>
|-
| <code>IsWeaponAugment</code> || N/A || N/A || N/A || Boolean || ❌ || Whether or not the mod is classified as [[Weapon Augments]] or augment mods for weapons. Note that there are exceptions like {{M|Harkonar Scope}} and {{M|Medi-Ray}} which are classified as augments b/c they drop from [[Kela De Thaym]] || <code>true</code>
|-
| <code>Link</code> || N/A || N/A || N/A || String || ✔️ || Page/article link to the mod on the wiki || <code>"Scorch (Mod)"</code>
|-
| <code>MaxRank</code> || N/A || <code>fusionLimit</code> || <code>FusionLimit</code> || Number (integer) || ✔️ || Maximum rank that mod can be upgraded to using [[Endo]] || <code>10</code>
|-
| <code>Name</code> || N/A || <code>name</code> || <code>LocalizeTag</code> || String || ✔️ || Name of mod || <code>"Scorch"</code>
|-
| <code>NotUpgradable</code> || N/A || N/A || N/A || Boolean || ❌ || Denotes whether or not a mod can be upgraded by the player using [[Endo]] || <code>true</code>
|-
| <code>NumUpgradesInSet</code> || N/A || <code>numUpgradesInSet</code> || N/A || Number (integer) || ❌ || For set bonuses, the total number of mods that are part of this set || <code>4</code>
|-
| <code>Polarity</code> || N/A || <code>polarity</code> || <code>ArtifactPolarity</code> || String || ✔️ || Full name of the mod's [[polarity]] || <code>"Naramon"</code> or <code>"Universal"</code>
|-
| <code>Rarity</code> || N/A || <code>rarity</code> || <code>Rarity</code> || String || ✔️ || Rarity of the mod; this also determines their [[Endo]] cost to upgrade. Not required for [[Endo]] entry. || <code>"Legendary"</code>
|-
| <code>Set</code> || N/A || <code>modSet</code> || <code>ModSet</code> || String || ❌ || For [[Set Mods]], the name of the set that the mod belongs to || <code>"Vigilante"</code>
|-
| <code>Tradable</code> || N/A || N/A || <code>TradeCapability</code> or <code>tradable</code> || Boolean || ✔️ || Whether or not the mod can be [[Trading|traded]] with other players || <code>true</code>
|-
| <code>Transmutable</code> || N/A || N/A || <code>IncludeInBoosterPack</code> or <code>canBeTransmutation</code> || Boolean || ✔️ || Whether or not the mod can be obtained from [[Transmutation]] || <code>true</code>
|-
| <code>Type</code> || N/A || <code>compatName</code> or <code>type</code> || <code>ItemCompatibility</code> and <code>ItemCompatibilityLocTag</code> or <code>compatName</code> || String || ✔️ || The class of items that the mod can be equipped on as seen on the mod card; there may be additional information for exceptions || <code>"Rifle"</code>, <code>"Trinity"</code>, or <code>"Bow (non-AoE bows and crossbows)"</code>
|-
| <code>UpgradeTypes</code> || N/A || N/A || <code>UpgradeType</code> || String || ❌ || Upgrade tags associated with the mod for categorization and to reflect the specific internal bonus it adds (sometimes localized description does not explain full functionality). Mods whose functionality are derived from Lua scripts (i.e. complex/unorthodox behavior) will not have this key set. This key is solely for mods that provide simple stat bonuses. || <code>GAMEPLAY_FACTION_DAMAGE</code>
|-
|}

==Mod Collections==
There are three main collections that store mod data:
*<code>DefaultUpgrades</code> - these are "innate" mods invisible in the modding screen. They include weapon [[passives]], [[Signature Weapon]] bonuses, and [[Progenitor Bonus]].
*<code>Sets</code> - [[Set Mod]] bonuses
*<code>Mods</code> - contains all mod data including deprecated and removed mods

==Mod Images==
Mod images without border styling, image filter, and description text can be sourced from [[Public Export]]. However, full mod images are NOT provided by Digital Extremes since they are generated within the engine (presumably they are modularly built to support different localizations and styling).<ref>https://warframe.fandom.com/f/p/2290994351439873490</ref><ref>{{Ref|title=I've talked to a DE member about this but it takes too long. Only option for them is to go trough them 1 by 1 and screencap everything. That's how they did it the last time, but this time it ain't gonna work.|author=Jeloxale|year=2014|month=9|day=12|publisher=Warframe Forums|url=https://forums.warframe.com/topic/308747-mods-image-for-wiki/?do=findComment&comment=3500491|access-date=2022-10-06|archive-url=https://web.archive.org/web/20221006011831/https://forums.warframe.com/topic/308747-mods-image-for-wiki/|archive-date=2022-10-06|extra=[[User:Jeloxale]], former wiki moderator, commenting on DE's old way of providing full mod image assets}}</ref> There are two ways to source full mod images:
*Cropping high quality screenshot of mod from a [[Chat]] link or [[Trading]] preview
*Ripping from the game

===Programmatically Creating Mod Cards===
It is possible to programmatically build mod cards using individual image assets sourced from [[Public Export]] (mod image) and [[Warframe Arsenal Twitch Extension]] (mod image frames and background). For example, see the following resources as reference for mimicking the {{M|Serration}} mod card:
*https://overframe.gg/items/arsenal/626/serration/
*https://warframe.fandom.com/uk/wiki/Зубець (Ukrainian Fandom wiki)

One benefit of this method is to be flexible to different localizations that WARFRAME supports. The same mod card template can be adapted to multiple languages if the localized mod name and descriptions are stored in this data store.

====Assets====
{{Main|Mod/Assets}}

==Where To Find Mod Metadata==
The in-game UI does not thoroughly present all the data and interactions that is provided from a mod (or any [[Upgrade]] for that matter). Here are some methods and sources to get more insight on the internal mechanics on mods:
*[[Public Export]]'s <code>ExportUpgrades</code> manifest
*https://overframe.gg/ has access to more metadata than what Digital Extremes provide to the public. This JSON data is cached locally on the client in these tags: <code><nowiki><script id="__NEXT_DATA__" type="application/json"></script></nowiki></code>
**For example, for more metadata on {{M|Serration}}, go to https://overframe.gg/items/arsenal/626/serration/ and inspect the HTML element on the page using your browser's development tools. The relevant metadata should be under the <code><nowiki><script id="__NEXT_DATA__" type="application/json"></script></nowiki></code> tags. If not, hard refresh the browser's cache so the underlying data is updated to reflect on the actual item.<syntaxhighlight lang="json">"data": {
    "ArtifactPolarity": "AP_ATTACK",
    "BaseDrain": "QA_MEDIUM",
    "ExcludeFromCodex": 0,
    "FusionLimit": "QA_VERY_HIGH",
    "Icon": "/Lotus/Interface/Cards/Images/Rifle/RifleDamageAmountMod.png",
    "IncludeInBoosterPack": 1,
    "ItemCompatibility": "/Lotus/Weapons/Tenno/Rifle/LotusRifle",
    "ItemCompatibilityLocTag": "/Lotus/Language/Items/RifleCategoryName",
    "LocalizeDescTag": "",
    "LocalizeTag": "/Lotus/Language/Items/RifleModDamageAmount",
    "MarketMode": "MM_HIDDEN",
    "ProductCategory": "Upgrades",
    "Rarity": "UNCOMMON",
    "RectangleIcon": 1,
    "Slotted": 0,
    "Upgrades": [{
            "AutoType": 1,
            "DamageType": "DT_ANY",
            "DisplayAsMultiplier": 0,
            "DisplayAsPercent": 1,
            "LocKeyWordScript": {
                "Script": ""
            },
            "LocTag": "/Lotus/Language/Upgrades/WeaponDamageModDesc",
            "OperationType": "STACKING_MULTIPLY",
            "OverrideLocalization": 1,
            "ReverseValueSymbol": 0,
            "RoundTo": 0.1,
            "RoundingMode": "RM_ROUND",
            "SmallerIsBetter": 0,
            "SymbolFilter": "",
            "UpgradeObject": "",
            "UpgradeType": "WEAPON_DAMAGE_AMOUNT",
            "ValidModifiers": [],
            "ValidPostures": [],
            "ValidProcTypes": [],
            "ValidType": "",
            "Value": 0.15000001
        }]
    },
    "id": 626,
    "parent": "/Lotus/Types/Game/LotusArtifactUpgrades/BaseArtifactUpgrade",
    "parents": ["/Lotus/Types/Game/LotusArtifactUpgrades/BaseArtifactUpgrade", "/Lotus/Types/Game/LotusArtifactUpgrade"],
    "path": "/Lotus/Upgrades/Mods/Rifle/WeaponDamageAmountMod",
    "storeData": {
        "Giftable": 0,
        "ProductCategory": "Upgrades",
        "SearchTags": ["/Lotus/Language/Items/RifleCategoryName"],
        "SellingPrice": 500,
        "ShowInMarket": 0,
        "TypeName": "/Lotus/Upgrades/Mods/Rifle/WeaponDamageAmountMod"
    },
    "storeItemType": "/Lotus/StoreItems/Upgrades/Mods/Rifle/WeaponDamageAmountMod",
    "tag": "Mod",
    "texture": "/Lotus/Interface/Cards/Images/Rifle/RifleDamageAmountMod.jpg",
    "texture_new": "/Lotus/Interface/Cards/Images/Rifle/RifleDamageAmountMod.jpg"
},
</syntaxhighlight>
**Adding some comments for context:<syntaxhighlight>
"data": {
    "ArtifactPolarity": "AP_ATTACK", -- Mod polarity as stored as an string enum
    "BaseDrain": "QA_MEDIUM", -- Base mod capacity drain as stored as a string enum
    "ExcludeFromCodex": 0, -- Boolean value as an integer (0 or 1) to determine whether to hide mod from Codex or not
    "FusionLimit": "QA_VERY_HIGH", -- Mod's max rank as stored a a string enum
    "Icon": "/Lotus/Interface/Cards/Images/Rifle/RifleDamageAmountMod.png", -- Game's internal file path to the mod image
    "IncludeInBoosterPack": 1, -- Boolean value as an integer to determine if mod is transmutable or not
    "ItemCompatibility": "/Lotus/Weapons/Tenno/Rifle/LotusRifle", - Mod item compatibility as location to object definition
    "ItemCompatibilityLocTag": "/Lotus/Language/Items/RifleCategoryName", -- Location of mod item compatibility localization string (e.g. "Rifle")
    "LocalizeDescTag": "",
    "LocalizeTag": "/Lotus/Language/Items/RifleModDamageAmount", -- Location of localization string of mod description
    "MarketMode": "MM_HIDDEN", -- Whether or not mod is available in in-game market as a string enum
    "ProductCategory": "Upgrades", - Item category
    "Rarity": "UNCOMMON", - Mod rarity as a string enum
    "RectangleIcon": 1, -- Boolean value as an integer to determine whether or not mod image has a dimensions of a rectangle
    "Slotted": 0, -- Boolean value as an integer to determine if mod is installed
    "Upgrades": [{ -- Array of stat modifiers that the mod provides
            "AutoType": 1,
            "DamageType": "DT_ANY", -- If mod's effect provides damage stat modifiers, this will determine damage type that it will apply to as a string enum
            "DisplayAsMultiplier": 0,
            "DisplayAsPercent": 1,
            "LocKeyWordScript": {
                "Script": ""
            },
            "LocTag": "/Lotus/Language/Upgrades/WeaponDamageModDesc", -- Location of localization string of stat modifier
            "OperationType": "STACKING_MULTIPLY", -- How stat modifier is applied to base stat and how it interacts with other similar stat modifiers as a string enum
            "OverrideLocalization": 1,
            "ReverseValueSymbol": 0,
            "RoundTo": 0.1,
            "RoundingMode": "RM_ROUND", -- Value rounding mode as a string enum
            "SmallerIsBetter": 0, -- Boolean value as an integer to determine if smaller stat modifier is a buff or not
            "SymbolFilter": "", -- Search filter for any symbols present in mod description (e.g. damage icons)
            "UpgradeObject": "",
            "UpgradeType": "WEAPON_DAMAGE_AMOUNT", -- Stat modifier as a string enum
            "ValidModifiers": [],
            "ValidPostures": [], -- Array of valid avatar movement states to trigger mod's effect
            "ValidProcTypes": [], -- Array of valid status effects to trigger mod's effect
            "ValidType": "",
            "Value": 0.15000001 -- Value of said stat modifier as a floating-point value
        }]
    },
    "id": 626,
    "parent": "/Lotus/Types/Game/LotusArtifactUpgrades/BaseArtifactUpgrade", -- Parent game object of mod for inheritance
    "parents": ["/Lotus/Types/Game/LotusArtifactUpgrades/BaseArtifactUpgrade", "/Lotus/Types/Game/LotusArtifactUpgrade"],
    "path": "/Lotus/Upgrades/Mods/Rifle/WeaponDamageAmountMod", -- Unique path to mod data
    "storeData": { -- In-game market data for mod
        "Giftable": 0,
        "ProductCategory": "Upgrades",
        "SearchTags": ["/Lotus/Language/Items/RifleCategoryName"],
        "SellingPrice": 500, -- Mod's sell price in Credits
        "ShowInMarket": 0,
        "TypeName": "/Lotus/Upgrades/Mods/Rifle/WeaponDamageAmountMod"
    },
    "storeItemType": "/Lotus/StoreItems/Upgrades/Mods/Rifle/WeaponDamageAmountMod",
    "tag": "Mod",
    "texture": "/Lotus/Interface/Cards/Images/Rifle/RifleDamageAmountMod.jpg",
    "texture_new": "/Lotus/Interface/Cards/Images/Rifle/RifleDamageAmountMod.jpg"
},
</syntaxhighlight>

==Data Validation==

===Checking for required keys===
{{Column|3|
{{#invoke:Mods/data/validate|checkRequiredKeysExist}}
}}

===Validating data types of values===
{{Column|3|
{{#invoke:Mods/data/validate|validateDataTypes}}
}}

===Checking naming scheme of image names===
{{Column|3|
{{#invoke:Mods/data/validate|checkImageNames}}
}}

===Validating mod incompatibility graphs for circular references===
{{Column|3|
{{#invoke:Mods/data/validate|validateIncompatibilityGraphs}}
}}

==References==
{{Reflist}}

==Mod Data==
[[Category:Databases]]