<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Mod|function|input1|input2|...}}</nowiki></code>

=== Template ===
In template: <code><nowiki>{{#invoke:Mods|function|input1|input2|...}}</nowiki></code><br />
In articles: <code><nowiki>{{template|function|input1|input2|...}}</nowiki></code>

=== Module ===
<syntaxhighlight lang="lua">
local Mod = require('Module:Mods')

local function func(input)
    return Mod.getMod(input)
end
</syntaxhighlight>
}}</onlyinclude>