<includeonly>{{#invoke:ModuleTest|main}}</includeonly>
<noinclude>[[Category:Lua test suites]]</noinclude>