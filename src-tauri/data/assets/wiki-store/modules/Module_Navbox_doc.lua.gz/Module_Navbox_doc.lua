<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Navbox|function|input1|input2|...}}</nowiki></code>
}}</onlyinclude>