<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Template ===
In template: <code><nowiki>{{#invoke:Navigation|main}}</nowiki></code><br />
In articles: <code><nowiki>{{Navigation|main|input1|input2|...}}</nowiki></code>
}}</onlyinclude>