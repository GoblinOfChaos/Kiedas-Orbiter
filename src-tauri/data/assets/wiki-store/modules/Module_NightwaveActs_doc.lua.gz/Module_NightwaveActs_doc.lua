{{Archived|Use [[NightwaveActs.json]] instead 20:39, 31 August 2021 (UTC)}}
JSON data to be parsed by [[MediaWiki:NightwaveActs.js]] to map out act name to associated image in wiki. To be used with [[Template:NightwaveActs]].

Keys are in alphabetical order and values are hexidecimal values with image name to be concatenated to the following URL: 
<pre>https://vignette.wikia.nocookie.net/warframe/images/</pre>

==Notes== 
*Some acts don't have image so their values are links to a placeholder image (i.e. <code>"4/47/Placeholder.png"</code>)
*Keys and values must be double quoted (<code>""</code>)
*No trailing comma after last element of each JSON object
*TODO: Check if ?action=raw can be used instead of ?action=parse in MediaWiki API. If that is the case, we can replace the JSON delimiters.

==See Also==
*[[Module:NightwaveActs/dev]] - for development