<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Module ===
<syntaxhighlight lang="lua">
local p = {}
local Polarity = require('Module:Polarity')

local function func(polName)
    return Polarity._polarity(polName)
end
</syntaxhighlight>
}}</onlyinclude>