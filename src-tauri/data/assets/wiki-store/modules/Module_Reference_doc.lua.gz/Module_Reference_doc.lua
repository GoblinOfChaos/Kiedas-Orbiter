<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Reference|main}}</nowiki></code>

=== Template ===
In template: <code><nowiki>{{#invoke:Reference|main}}</nowiki></code><br />
In articles: <code><nowiki>{{Ref|param1=arg1|param2=arg2|...}}</nowiki></code>

See https://dev.fandom.com/wiki/Global_Lua_Modules/Ref#Parameters for full documentation.
}}</onlyinclude>