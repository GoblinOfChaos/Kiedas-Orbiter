Removes categories of content passed in as a parameter. Usage:

<pre>{{#invoke:RemoveCategory|rem|<content>}}</pre>