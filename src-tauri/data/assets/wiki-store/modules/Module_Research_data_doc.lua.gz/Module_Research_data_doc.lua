The following data is used by [[Module:Cost]] to generate research costs automatically.

Currently used in [[Template:BuildAutomatic]].
[[Category:Databases]]