Database of [[WARFRAME]] [[Resources]], items, and components. For blueprints which require resources to be crafted, see [[Module:Blueprints/data]].
{{LatestEdit}}
==Resource Entry Schema==
<syntaxhighlight lang="lua">
	["Resource Name"] = {
		Amount = { 1, 1 },
		ContainerImage = "ResourceContainer.png",
		HelminthCategory = "Bile",
		HelminthCost = 999999,
		Description = "Description",
		Image = "Resource.png",
		Introduced = "30",
		Link = "Page Name",
		Name = "Resource Name",
		Rarity = "Rare",
		Type = "Event",
		ResourceBoostAble = true,
		BountifulHarvestAble = false,
		ResourceDropChanceBoostAble = false,
		RetrieverModAble = true
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! [[Public Export]] Equivalent !! Internal Equivalent !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Amount</code> || N/A || <code>Amount</code> || Table (of integers) || ❌ || A 2-element array with the first element being the minimum drop amount and the second being the maximum drop amount for the item. Game will uniformly choose a value between these two bounds when determining resource/item drops from enemies and containers. For mining materials, these values will serve the range of values rewarded based on mining minigame performance (e.g. perfect 5 star scores get max value). || <code>{ 150, 250 }</code>
|-
| <code>ContainerImage</code> || N/A || N/A || String || ❌ || Image file name of the resource's deposit container as uploaded to the wiki || <code>"AlloyPlateContainer.png"</code>
|-
| <code>Description</code> || <code>description</code> || <code>LocalizeDescTag</code> || String || ✔️ || Description of resource as seen in-game || <code>"Sinewy and metallic, possessed of great elastic strength."</code>
|-
| <code>HelminthCategory</code> || N/A || <code>InfestedFoundryResourceType</code> || String || ❌ || For resources that can be fed to the [[Helminth]], the secretion category that can be increased || <code>"Biotics"</code>
|-
| <code>HelminthCost</code> || N/A || <code>InfestedFoundryResourceBundleSize</code> || Number (integer) || ❌ || For resources that can be fed to the Helminth, the amount needed to increase secretion || <code>500</code>
|-
| <code>Image</code> || <code>textureLocation</code> || <code>Icon</code> || String || ✔️ || Image file name of the resource as uploaded to the wiki || <code>"Adramalium.png"</code>
|-
| <code>InternalName</code> || <code>uniqueName</code> || <code>TypeName</code> || String || ❌ || The full unique name of a resource formatted as a file path || <code>"/Lotus/Types/Items/Gems/Deimos/DeimosCommonOreAItem"</code>
|-
| <code>Introduced</code> || N/A || N/A || String || ✔️ || The game version in which the resource was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || N/A || N/A || String || ✔️ || Page/article link to the resource on the wiki || <code>"Kuva (Resource)"</code>
|-
| <code>Name</code> || <code>name</code> || <code>LocalizeTag</code> || String || ✔️ || Name of resource || <code>"Kuva"</code>
|-
| <code>Rarity</code> || N/A || <code>Rarity</code> || String || ❌ || For [[Star Chart]] resources (those that can obtained from [[Extractor]]s), the rarity of the resource || <code>"Rare"</code>
|-
| <code>SellPrice</code> || N/A || <code>SellingPrice</code> || Number (integer) || ❌ || For sellable resources, the sell price in [[Credits]] when removed from the player's inventory || <code>100</code>
|-
| <code>SortingPriority</code> || N/A || <code>SortingPriority</code> || Number (integer) || ❌ || An integer value representing the priority in which it is shown in the end-of-mission menu when rewards are sorted by "Importance". The smaller the number, the higher the priority. High priority means that item will be near the top of the reward menu || <code>3</code>
|-
| <code>Tradable</code> || N/A || <code>TradeCapability</code> || Boolean || ❌ || Denotes whether or not a resource is [[Trading|tradable]]; default is false || <code>true</code>
|-
| <code>Type</code> || N/A || N/A || String || ✔️ || The class of resource (e.g. "Resource", "Event", "Weapon", "Fish Part", "Gem", "Pigment") || <code>"Event"</code>
|-
| <code>ResourceBoostAble</code> || N/A || N/A || Boolean || ❌ || Whether the resource pickup is doubled by Resource Booster or not. || <code>true</code>
|-
| <code>BountifulHarvestAble</code> || N/A || N/A || Boolean || ❌ || Whether the resource pickup is doubled by Bountiful Harvest Decree or not. || <code>true</code>
|-
| <code>ResourceDropChanceBoostAble</code> || N/A || N/A || Boolean || ❌ || Whether the resource pickup is doubled by Resource Drop Chance Boost or not. || <code>false</code>
|-
| <code>RetrieverModAble</code> || N/A || N/A || Boolean || ❌ || Whether the resource pickup is doubled by Retriever Mods or not. || <code>true</code>
|-
|}

==Data Validation==
<!--
===Checking for required keys===
{{Column|3|
{{#invoke:Resources/data/validate|checkRequiredKeysExist}}
}}

===Validating data types of values===
{{Column|3|
{{#invoke:Resources/data/validate|validateDataTypes}}
}}
-->
===Checking naming scheme of image names===
{{Column|3|
{{#invoke:Resources/data/validate|checkImageNames}}
}}

==Resource Data==
[[Category:Databases]]