<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Product Backlog ==
{{(!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Last Update
{{!}}-
{{ProjectTableRow
|name=Data validation
|type=Dev/database
|status=Planning
|priority=Medium
|contact=
|desc=Create <code>[[Module:Resources/data/validate]]</code> subpage of <code>/data</code> for data validation functions
*Include type checking for each column/attribute
*Include checking if a table entry has the required keys
*Include boundary checking for stat values
|start=19:32, 17 September 2021 (UTC)
|end=
}}
{{ProjectTableRow
|name=Replace M:Icon as a dependency
|type=Dev
|status=New
|priority=Low
|contact=
|desc=
*Decouple template/module dependency from [[Module:Icon]] in context of getting resource image data. Replace with [[Module:Resources]] and [[Module:Resources/data]]
**No easy way to track which pages/templates use M:Icon/[[Template:Icon]] in the context of resource images since multiple image databases are clumped into one module and template (cannot use [[Special:WhatLinksHere]] to pinpoint exact <code><nowiki>{{Icon|Resource|...}}</nowiki></code> usage)
***Known templates: [[Template:BuildRequire]], [[Template:SchemaDecor]], [[Template:BuildAutomatic]] (which invokes [[Module:Cost]] which uses <code>Icon._Resource()</code>), [[Template:PlanetList]]
***Known modules: [[Module:Cost]], [[Module:Decorations]]
|start=03:49, 24 September 2021 (UTC)
|end=
}}
{{!)}}

==Finished Issues==
{{(!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Completion Date
{{!}}-
{{ProjectTableRow
|name=Resource infobox
|type=Dev/Edit
|status=Completed
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=Migrate wikitext from [[Template:Component]] used on resource pages into a infobox builder function. Resources infobox generator resides in [[Module:Resources/infobox]]. Replace said template with a new infobox template [[Template:ResourceInfobox]] to support new infobox rows.
|start=18:14, 15 September 2021 (UTC)
|end=22:36, 16 September 2021 (UTC)
}}
{{!)}}
}}
</onlyinclude>