<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Module ===
<syntaxhighlight lang="lua">
local p = {}
local shared = require('Module:Shared')

local function func(input)
    -- ...
    for i, v in shared.skpairs(table) do
        -- ...
    end
    -- ...
end
</syntaxhighlight>
}}</onlyinclude>