Database for [[Sigils]].

==Sigil Entry Schema==
<syntaxhighlight lang="lua">
	["Sigil Name"] = {
		Description = "Sigil description",
		Image = "SigilName.png",
		Name = "Sigil Name",
		Link = "Article Name",
		SellPrice = 1000,
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| Description || String || ✔️ || In-game item description || <code>"A sigil representing prestige gained with the Ostron."</code>
|-
| Image || String || ✔️ || Image file name of the sigil as seen in in-game menus || <code>"LeapingThrasherSigil.png"</code>
|-
| Name || String || ✔️ || Name of sigil as seen in-game || <code>"Bloodshed Sigil"</code>
|-
| Link || String || ✔️ || Page/article link to the related article on the wiki || <code>"Stalker"</code>
|-
| SellPrice || Number || ❌ || Sigil's selling price in [[Credits]] || <code>1000</code>
|-
|}

==Sigil Data==
[[Category:Databases]]