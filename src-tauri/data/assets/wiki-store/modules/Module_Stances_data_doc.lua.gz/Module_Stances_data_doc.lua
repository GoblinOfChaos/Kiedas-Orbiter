{{UpdateMe|Add support for Slams and Heavy Slams}}
Database of [[WARFRAME]]'s [[Stance]] movement sets for melee weapons.

{{LatestEdit}}
==Complex Combos==
Combos with additional effects or deviates from standard stance behavior, many of which are noted in the respective stance page's Notes section. Therefore, these entries may have additional information omitted from this database due to incompatibility with the schema.
{{Column|2|
*{{M|Rending Crane}} Lashing Tempest
*{{M|Cyclone Kraken}} Thunder Hydra
*{{M|Iron Phoenix}} Taking Flight
*{{M|Swirling Tiger}} Dancing Hunter
*{{M|Carving Mantis}} Ambush Predator
*{{M|Tranquil Cleave}} Breathless Lunge
*{{M|Slicing Feathers}} Scathing Plume
*{{M|Homing Fang}} Cutting Arches
*{{M|Seismic Palm}} Sudden Rockfall
*{{M|Gaia's Tragedy}} Mountain's Rage
*{{M|Cleaving Whirlwind}} Broken Bull
*{{M|Gleaming Talon}} Ruin
*{{M|Bullet Dance}} all combos
*{{M|Gemini Cross}} Baleful Sin
*{{M|Coiling Viper}} Tumbling King
*{{M|Exalted Blade}} Judged Severance
*{{M|Hysteria}} Roaring Drums
*{{M|Primal Fury}} Rolling Boulder Rush
*{{M|Butcher's Revelry}} Rip 'N Ride
}}

==Stance Entry Schema==
<syntaxhighlight lang="lua">
["Stance Name"] = {
	StanceName = "Stance Name",
	WeaponType = "Weapon Type",
	["Neutral"] = {
		Name = "Combo Name",
		Attacks = {
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
		}
	},
	["Forward"] = {
		Name = "Combo Name",
		Attacks = {
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
		}
	},
	["Forward Block"] = {
		Name = "Combo Name",
		Attacks = {
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
		}
	},
	["Block"] = {
		Name = "Combo Name",
		Attacks = {
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
		}
	},
},
</syntaxhighlight>

Shared combos:
<syntaxhighlight lang="lua">
["Weapon Type"] = {
	["Heavy"] = {
		Name = "Combo Name",
		Attacks = {
			{   Shape = "Heavy", Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Shape = "Heavy", Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
		}
	},
	["Slide"] = {
		Name = "Combo Name",
		Attacks = {
			{   Type = "Spin", Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
		}
	},
	["Aerial"] = {
		Name = "Combo Name",
		Attacks = {
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
		}
	},
	["Wall"] = {
		Name = "Combo Name",
		Attacks = {
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
		}
	},
	["Finisher"] = {
		Name = "Combo Name",
		Attacks = {
			{   Hits = { 1 }, Dmg = { 100 }, Procs = { "" } },
		}
	},
},
</syntaxhighlight>

;Stance tables
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>ConclaveOnly</code> || Boolean || ❌ || Whether or not the mod can be used in [[Conclave]] || <code>false</code>
|-
| <code>UniqueToWeapon</code> || Boolean || ❌ || For entries that contain combos that are unique to a certain weapon, overriding the default combos or combos provided by the stance mod || <code>true</code>
|-
| <code>StancelessStance</code> || Boolean || ❌ || Denotes whether or not a stance is the default stance when no stance mod is equipped || <code>true</code>
|-
| <code>StanceName</code> || String || ✔️ || [[Stance]]'s name || <code>"Cleaving Whirlwind"</code>
|-
| <code>WeaponType</code> || String || ✔️ || Melee class that stance is compatible with || <code>"Nikana"</code>
|-
| <code>Neutral</code> || Table (mixed key-value maps and numeric arrays) || ✔️ || Neutral combo entry ||
|-
| <code>Forward</code> || Table (mixed key-value maps and numeric arrays) || ✔️ || Forward combo entry ||
|-
| <code>Forward Block</code> || Table (mixed key-value maps and numeric arrays) || ✔️ || Forward while blocking combo entry ||
|-
| <code>Block</code> || Table (mixed key-value maps and numeric arrays) || ✔️ || Block combo entry ||
|-
| <code>Aerial</code> || Table (mixed key-value maps and numeric arrays) || ❌ || Air combo entry (optional, will use stanceless Aerial combo if omitted) ||
|-
| <code>Finisher</code> || Table (mixed key-value maps and numeric arrays) || ❌ || Ground finisher attack entry (optional, will use stanceless Ground Finisher combo if omitted) ||
|-
| <code>Heavy</code> || Table (mixed key-value maps and numeric arrays) || ❌ || Heavy combo entry (optional, will use stanceless Heavy combo if omitted) ||
|-
| <code>Slide</code> || Table (mixed key-value maps and numeric arrays) || ❌ || Slide attack entry (optional, will use stanceless Slide combo if omitted) ||
|-
| <code>Wall</code> || Table (mixed key-value maps and numeric arrays) || ❌ (at least one combo type) || Wall latch attack entry (optional, will use stanceless Wall combo if omitted)||
|-
|}

;Combo tables
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Attacks</code> || Table (of tables) || ✔️ || Table of attacks || 
|-
| <code>Duration</code> || Number (float) || ❌ || Approximate length of combo in seconds when melee's [[Attack Speed]] is at 1, precise to the tenths place (or two significant figures) || <code>4.5</code>
|-
| <code>Image</code> || String || ❌ || Name of .gif image file showcasing combo moveset animation || <code>"CrossingSnakesCombo0.gif"</code>
|-
| <code>Name</code> || String || ✔️ || Combo name || <code>"Morning Sun"</code>
|-
|}

;Attacks tables
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Dmg</code> || Table (of numbers) || ✔️ || Damage multipliers of each hit in a combo's attack as a percentage, with 100 representing 100% of a melee's damage || <code>{ 100, 100, 100, 50 }</code>
|-
| <code>Hits</code> || Table (of numbers) || ✔️ || Number of hits in a combo's attack || <code>{ 1, 1, 2, 1 }</code>
|-
| <code>ImpactMultiplier</code> || Table (of numbers) || ❌ || Additional {{D|Impact}} damage multiplier on hit (commonly 1.1x, 1.25x, 1.5x or 2x) || <code>{ 1.25, 1 }</code>
|-
| <code>Note</code> || String || ❌ || A note for additional details about the hit/attack in particular || <code>"Does purely Impact damage"</code>
|-
| <code>Procs</code> || Table (of strings) || ❌ || Forced procs of each hit in a combo's attack
*For no icons: nil or ""
*For single icons: "Knockback" (Impact proc), "Weakened" (Puncture proc), "Bleed" (Slash proc), "Detonate" (Blast proc), "Lifted", "Knockdown", "Ragdoll", "Stagger", "Big Stagger", "Finisher", or "Impair"
*For double icons, in place of a string value in a table, insert another table containing two proc names (e.g. { "Knockback", "Bleed" })
|| <code>{"", "Lifted", "Bleed"}</code>
|-
| <code>PunctureMultiplier</code> || Table (of numbers) || ❌ || Additional {{D|Puncture}} damage multiplier on hit (commonly 1.1x, 1.25x, 1.5x or 2x) || <code>{ 1.25, 1 }</code>
|-
| <code>Shape</code> || String || ❌ || Shape of combo attack icon ("", "Heavy", or nil (default)) || <code>"Heavy"</code>
|-
| <code>SlashMultiplier</code> || Table (of numbers) || ❌ || Additional {{D|Slash}} damage multiplier on hit (commonly 1.1x, 1.25x, 1.5x or 2x) || <code>{ 1.25, 1 }</code>
|-
| <code>Types</code> || Table || ❌ || List of attack types corresponding to each individual attack of each melee input. Attack types can be "Sweep" (default), "Thrust", "360", "Direct", "Slam", "Ranged", or nil.
*A "sweep" attack is a melee strike that intends to hit an enemy with the edge of the blade (the length of obround melee hitbox).
*A "thrust" attack is a melee strike that intends to hit an enemy with the tip of the blade (the rounded edge of obround melee hitbox).
*A "360" attack is a sliding sweep attack that hits targets around the player (not always in a 360° arc, but is usually above 180°).
*A "direct" slam attack is a melee strike that hits a single target at the epicenter of a slam attack.
*A "slam" attack is the area-of-effect component of the melee slam attack.
*A "ranged" attack is any melee attack that launches a ranged projectile.
| <code>{ "Slam", "Sweep, "Sweep" }</code>
|-
|}

Table value restrictions:
*If one of the following keys contains a table value: <code>Hits</code>, <code>Dmg</code>, or <code>Procs</code>, then the rest must be either nil or contain table values that match the same length as the largest table value.

==Stance Data==
[[Category:Databases]]