<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Stances|function|input1|input2|...}}</nowiki></code>

== Adding New Stance Types ==
Update [[Module:Stances/data]], following the schema for a stance entry.

== Adding Support For New Combo Types ==
#In [[Module:Stances]], update <code>COMBO_TYPES</code> table with the name of combo type key to be added to [[Module:Stances/data]].
#In <code>buildComboRow()</code>, add a new key-value pair associated with the new combo type for the tooltips/notes.

== Product Backlog ==
{{(!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Last Update
{{!}}-
{{ProjectTableRow
|name=Finishers
|type=Dev/database
|status=Planning
|priority=Low
|contact=
|desc=Add support for storing finisher attacks though there is a different animation for multiple body types (bipedal human, quadruped, heavy, MOA, etc.). Some weapons have unique finishers:
*{{Weapon|Rumblejack}}
|start=06:23, 30 January 2022 (UTC)
|end=
}}
{{ProjectTableRow
|name=Special attacks
|type=Database
|status=Planning
|priority=Low
|contact=
|desc=Add additional stance entries for weapons with unique combos. Name key of these entries should be just the weapon name in EN locale.
*{{Weapon|Tatsu}}'s slide attack when having at least 1 Soul Swarm charge
*{{Weapon|Zenistar}}'s heavy attack throwing a disk
*{{Weapon|Caustacyst}}'s heavy attack throwing corrosive sludge
*{{Weapon|Vaykor Sydon}}'s block + heavy attack blind (unsure if this can fit in current schema)
|start=06:23, 30 January 2022 (UTC)
|end=
}}
{{ProjectTableRow
|name=Slam and Heavy Slams
|type=Dev/database
|status=Planning
|priority=Low
|contact=
|desc=Add support for storing slam attacks and heavy slam attacks. Slam/heavy slams should be shared between melee classes with some exceptions:
*{{Weapon|Tenet Exec}}'s slam/heavy slam
*{{Weapon|Vitrica}}'s slam on glassed enemies
*{{Weapon|Ghoulsaw}}/{{M|Butcher's Revelry}}'s slam
|start=06:23, 30 January 2022 (UTC)
|end=
}}
{{ProjectTableRow
|name=Data validation
|type=Dev/database
|status=Haitus
|priority=Medium
|contact=
|desc=Create <code>[[Module:Stances/data/validate]]</code> subpage of <code>/data</code> for data validation functions
*Include type checking for each column/attribute
*Include checking if a table entry has the required keys (the minimum number of keys needed to support basic features in [[Module:Stances]])
*Include boundary checking for stat values
|start=19:01, 6 September 2021 (UTC)
|end=
}}
{{!)}}

==Finished Issues==
{{(!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Completion Date
{{!}}-
{{ProjectTableRow
|name=Update database schema
|type=Database/Dev
|status=Completed
|contact=[[User:Cephalon Scientia]]
|desc=
*✔️ Standardize typings of key-value pairs in <code>/data</code> to avoid all the type checking in the module.
*✔️ Add <code>Image</code> key to support mapping combos to animation gifs.
|start=4:06, 23 August 2021 (UTC)
|end=19:52, 6 September 2021 (UTC)
}}
{{!)}}
}}</onlyinclude>