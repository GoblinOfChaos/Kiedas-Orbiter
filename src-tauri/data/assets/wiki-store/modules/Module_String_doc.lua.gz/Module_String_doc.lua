<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Module ===
<syntaxhighlight lang="lua">
local p = {}
local String = require('Module:String')

local function func(input)
    -- ...
    -- input -> stuff
    -- ...
    return String.titleCase(stuff)
end
</syntaxhighlight>
}}</onlyinclude>