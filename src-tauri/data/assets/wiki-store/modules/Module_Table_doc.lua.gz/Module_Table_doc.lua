<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Module ===
<syntaxhighlight lang="lua">
local p = {}
local table = require('Module:Table')

local function func(t)
    return table.size(t)
end
</syntaxhighlight>
On this Wiki, Table is used in:
-----
}}</onlyinclude>