Database of [[TennoGen]] items. For more canonical data related to TennoGen cosmetics see [[Module:Cosmetics/data]].

==TennoGen Item Schema==
<syntaxhighlight lang="lua">
["Item Name"] = {
	Artists = { "Artist 1", "Artist 2" },  -- artist names in a table
	ConsolePrice = "100",  -- in platinum
	Image = "Panel.png",  -- image file name as stored on the wiki
    Link = "Page name",
    Name = "Item name",
	PcPrice = "$5.99",  -- include currency sign
	Round = "12",  -- TennoGen round number or name
	SteamLink = "https://steamcommunity.com/sharedfiles/filedetails/?id=1266378613",  -- entire URL of Steam workshop page
	Description = "Item description here, as it appears ingame",
	Type = "Syandana"   -- cosmetic type
},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Artists</code> || Table (of strings) || ✔️ || Name of artists who contributed || <code>{ "malaya", "Cobalt" }</code>
|-
| <code>ConsolePrice</code> || String || ✔️ || Price in [[Platinum]] on consoles || <code>"200"</code>
|-
| <code>Image</code> || String || ✔️ || Image file name of the item as uploaded to the wiki || <code>"ArmalystSyandana.png"</code>
|-
| <code>InternalName</code> || String || ❌ || The full unique name of item formatted as a file path || <code>"/Lotus/Upgrades/Skins/Anima/SWDivisaHelmet"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the item on the wiki || <code>"Armalyst Syandana"</code>
|-
| <code>Name</code> || String || ✔️ || Name of TennoGen item || <code>"Armalyst Syandana"</code>
|-
| <code>PcPrice</code> || String || ✔️ || Price in US dollars on PC || <code>"$5.99"</code>
|-
| <code>Round</code> || String || ✔️ || TennoGen round number or name || <code>"12"</code>
|-
| <code>SteamLink</code> || String || ✔️ || Entire URL of Steam workshop page || <code>"https://steamcommunity.com/sharedfiles/filedetails/?id=1266378613"</code>
|-
| <code>Description</code> || String || ✔️ || In-Game Description || <code>"A unique Mag Skin Warframe."</code>
|-
| <code>Type</code> || String || ✔️ || Cosmetic type || <code>"Syandana"</code>
|-
|}

[[Category:Databases]]