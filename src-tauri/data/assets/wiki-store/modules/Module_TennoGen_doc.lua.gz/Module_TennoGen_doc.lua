<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:TennoGen|function|input1|input2|...}}</nowiki></code>

=== Template ===
In template: <code><nowiki>{{#invoke:TennoGen|function|input1|input2|...}}</nowiki></code><br />
In articles: <code><nowiki>{{TennoGen|function|input1|input2|...}}</nowiki></code>
}}</onlyinclude>