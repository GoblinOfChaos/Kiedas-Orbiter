<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Text|main|input1|input2|...}}</nowiki></code>

=== Module ===
<syntaxhighlight lang="lua">
local Text = require('Module:Text')

local function func(input)
    return Text._text(input)
end
</syntaxhighlight>
}}
</onlyinclude>