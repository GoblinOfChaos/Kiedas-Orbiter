<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
On this Wiki, Tooltips is used in:
* {{t|A}}
* {{t|M}}
* {{t|WF}}
* {{t|Companion}}
* {{t|Relic}}
* {{t|Weapon}}
* {{t|Arcane}}
* {{t|D}}
* {{t|Resource}}
* {{t|Focus}}
* {{t|Faction}}
* {{t|Gear}}
* {{t|Stat}}
* {{t|E}}
* {{t|Decree}}
* {{t|Key}} ({{t|Quest}} as alias)
* {{t|Cosmetic}}

== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Tooltip|function|input1|input2|...}}</nowiki></code>

<code><nowiki>{{#invoke:Tooltip|full|name|source|r=displayname}}</nowiki></code> (<code>full</code> may be replaced with <code>icon</code> or <code>text</code>) (eg <code><nowiki>{{#invoke:Tooltips|full|Vectis|Weapons}}</nowiki></code>)

<code><nowiki>{{#invoke:Tooltip|full|name|source|index|r=displayname|color=color|i=index_override|icon=Icon.png|l=link_o|n=name_o}}</nowiki></code>

<code><nowiki>{{#invoke:Tooltip|getTip|index|module|submodule}}</nowiki></code> (eg <code><nowiki>{{#invoke:Tooltips|getTip|Vectis|Weapons|Primary}}</nowiki></code>)

==Examples==
Tooltip spans will only work if they were already on the page when it loaded.
*{{A|Haven}}
*{{M|Serration}}
*{{WF|Mirage}}
*{{Companion|Adarza Kavat}}
*{{Relic|Axi A1}}
*{{Weapon|Vectis}}
*{{Arcane|Arcane Energize}}
*{{D|Heat}}, {{D|Flesh}}, {{D|Ignite}}
*{{Resource|Auron}}
*{{Focus|Protective Sling}}
*{{Faction|Grineer}}
*{{Gear|Requiem Ultimatum}} 
*{{Stat|Ability Duration}}
*{{E|Heavy Gunner}}
*{{Decree|Tactical Repositioning}}
*{{Key|Clan Key}}

== How it works ==
#When you call a tooltip builder function (e.g. <code>Tooltips.full(itemName, moduleName, ...)</code>), it uses [[Module:Tooltips/icon]] to get the item image and page link from a module's <code>/data</code> subpage and builds the basic HTML tooltip tags to put on wiki articles (<code><nowiki><span class="tooltip tooltip-text" data-param-name="..." data-param-source="...">...</span></nowiki></code>).
#[[MediaWiki:Gadget-Tooltips.js]] uses the tooltip span's <code>data-param-name</code> (item name) & <code>data-param-source</code> (source module basename) attributes to fetch the actual tooltip from [[Module:Tooltips/tip]] (styled by [[MediaWiki:Gadget-Tooltips.css]]).
#*For example, <code><nowiki><span class="tooltip tooltip-full" data-param-name="Artemis Bow" data-param-source="Weapons">...</span></nowiki></code> will display a [[Template:Weapon]] tooltip of [[Artemis Bow (Weapon)]] while <code><nowiki><span class="tooltip tooltip-full" data-param-name="Artemis Bow" data-param-source="Ability">...</span></nowiki></code> will display a [[Template:A]] ("A" is a shorthand for abilities) tooltip of [[Artemis Bow]].
#*The processed wikitext for tooltips will be located in a div container on the bottom of articles with an id of <code>tooltip-storage</code>.
#*Data fetching uses MediaWiki's Action API.

== Errors in usage ==
If there are errors with using any tooltip template, these articles will be under the [[:Category:Pages with tooltip errors]].

== Directory ==
*[[Module:Tooltips]] - main/dispatch module, also handles tooltip text
**[[Module:Tooltips/tip]] - submodule for tooltip box (getTip)
**[[Module:Tooltips/icon]] - submodule that defines locations & icon style for supported modules
}}</onlyinclude>