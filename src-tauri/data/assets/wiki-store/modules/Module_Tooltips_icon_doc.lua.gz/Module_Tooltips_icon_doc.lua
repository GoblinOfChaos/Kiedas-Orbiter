<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
Submodule of [[Module:Tooltips]]. Not meant to be invoked by itself, see the main module page for usage.
}}</onlyinclude>