'''The tooltips only work on non-Module pages; see [[Module:Tooltips/testcases/doc|here]] for such'''
{{#invoke:ModuleTest|main}}
<noinclude>[[Category:Lua test suites]]</noinclude>