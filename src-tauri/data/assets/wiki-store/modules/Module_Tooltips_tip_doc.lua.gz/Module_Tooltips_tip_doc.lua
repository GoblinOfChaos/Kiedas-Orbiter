<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
Submodule of [[Module:Tooltips]]. Not meant to be invoked by itself, see the main module page for usage.

==Demo Tooltips==
<div style="display: block;"><div class="mw-parser-output">
{{#invoke:Tooltips|getTip|Haven|Ability|}}
<hr />
{{#invoke:Tooltips|getTip|Serration|Mods|}}
<hr />
{{#invoke:Tooltips|getTip|Mirage|Warframes|}}
<hr />
{{#invoke:Tooltips|getTip|Adarza Kavat|Companions|}}
<hr />
{{#invoke:Tooltips|getTip|Axi A1|Void|}}
<hr />
{{#invoke:Tooltips|getTip|Vectis|Weapons|}}
<hr />
{{#invoke:Tooltips|getTip|Heat|DamageTypes|}} {{#invoke:Tooltips|getTip|Blast|DamageTypes|}} {{#invoke:Tooltips|getTip|Flesh|DamageTypes|}} {{#invoke:Tooltips|getTip|Ignite|DamageTypes|}}
<hr />
{{#invoke:Tooltips|getTip|Arcane Energize|Arcane|}}
<hr />
{{#invoke:Tooltips|getTip|Auron|Resources|}}
<hr />
{{#invoke:Tooltips|getTip|Protective Sling|Focus|}}
<hr />
{{#invoke:Tooltips|getTip|Jackal Sigil|Sigils|}}
<hr />
{{#invoke:Tooltips|getTip|idk|Blueprints|}}
<hr />
{{#invoke:Tooltips|getTip|Grineer|Factions|}}
<hr />
{{#invoke:Tooltips|getTip|Ability Duration|Stats|}}
<hr />
{{#invoke:Tooltips|getTip|Requiem Ultimatum|Resources|}} 
<hr />
{{#invoke:Tooltips|getTip|Heavy Gunner|Enemies|}}
<hr />
{{#invoke:Tooltips|getTip|Tactical Repositioning|Decrees|}}
<hr />
{{#invoke:Tooltips|getTip|Awakening|Keys|}}
</div></div>
}}</onlyinclude>