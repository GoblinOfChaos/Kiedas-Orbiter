Database of [[WARFRAME]]'s usable vehicles which includes the [[Atomicycle]], [[K-Drive]] and [[Kaithe]].
__TOC__
{{LatestEdit}}
==Vehicle Data Schema==
<syntaxhighlight lang="lua">
		["Vehicle Name"] = {
			Abilities = { "1", "2", "3", "4" },
			Armor = 100,
			CodexSecret = true,
			Description = "In-Game Description (if possible)",
			Energy = 100,
			HasCustomVariants = false,
			Health = 100,
			Image = "VehicleName.png",
			InternalName = "/Lotus/Powersuits/xxx (I have no idea)",
			Introduced = "38",
			IsModdable = false,
			Missions = { "Free Roam" },
			MissionNames = { "Plains of Eidolon", "Orb Vallis" },
			Name = "Vehicle Name",
			Planets = { "Höllvania" },
			Shield = 100,
			SmallPortrait = 100,
			Speed = 10,
			Sprint = 1.1,
			SummonAbility = { "SummonAbility" },
			SummonGear = { "SummonGearItem" },
			TileSets = {},
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! [[Arsenal]] EN L10n !! [[Public Export]] Equivalent !! Internal Equivalent !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Abilities</code> || N/A || <code>abilities</code> || <code>AbilityTypes</code> || Table (of strings) || ❌ || Names of the abilities in the order of unlock || <code>{ "Atomi-Boost", "Atomi-Barrage", "Atomi-Shadow", "Atomi-Bomb" }</code>
|-
| <code>Armor</code> || Armor || <code>armor</code> || <code>ArmourRatingOverride</code> || Number (integer) || ❌ || Vehicle/Avatar's base [[Armor]] at Rank 0 || <code>100</code>
|-
| <code>CodexSecret</code> || N/A || <code>codexSecret</code> || <code>CodexSecret</code> || Boolean || ✔️ || Whether or not the Vehicle/Avatar has an entry in the [[Codex]] before the player acquires it; defaults to false || <code>false</code>
|-
| <code>Description</code> || N/A || <code>description</code> || <code>LocalizeDescTag</code> || String || ❌ || In-game description || <code>"Summons an Atomicycle for use in 1999 and free roam missions."</code>
|-
| <code>Energy</code> || Energy || <code>power</code> || <code>MaxEnergy</code> || Number (float) || ❌ || Warframe/Avatar's base [[Energy]] capacity at Rank 0 || <code>150</code>
|-
| <code>HasCustomVariants</code> || N/A || N/A || N/A || Boolean  || ✔️ || If the Vehicle has custom buildable versions, like K-Drives || <code>false</code>
|-
| <code>Health</code> || Health || <code>health</code> || <code>MaxHealthOverride</code> || Number (integer) || ❌ || Vehicle/Avatar's base [[Health]] at Rank 0 || <code>100</code>
|-
| <code>Image</code> || N/A || <code>textureLocation</code> || <code>Icon</code> || String || ✔️ || Image file name of the Vehicle/Avatar as seen in in-game menus || <code>"Atomicycle.png"</code>
|-
| <code>InternalName</code> || N/A || <code>uniqueName</code> || <code>TypeName</code> || String || ❌ || The full unique name of a Vehicle/Avatar formatted as a file path || <code>"/Lotus/Powersuits/xxxx"</code>
|-
| <code>Introduced</code> || N/A || N/A || N/A || String || ✔️ || The game version in which the Warframe/Avatar was first introduced in the global build of [[WARFRAME]] || <code>"38"</code>
|-
| <code>IsModdable</code> || N/A || N/A || N/A || Boolean || ✔️ || Can the Vehicle be modded || <code>false</code>
|-
| <code>Missions</code> || N/A || N/A || N/A || Table (of strings) || ❌ || Missions the Vehicle can be summoned in (by type) || <code>"Free Roam"</code>
|-
| <code>MissionNames</code> || N/A || N/A || N/A || Table (of strings) || ❌ || Missions the Vehicle can be summoned in (by name) || <code>"Plains of Eidolon"</code>
|-
| <code>Name</code> || N/A || <code>name</code> || <code>LocalizeTag</code> || String || ✔️ || Warframe/Avatar's name || <code>"Excalibur"</code>
|-
| <code>Planets</code> || N/A || N/A || N/A || Table (of strings) || ❌ || Planets the Vehicle can be summoned on || <code>"Höllvania"</code>
|-
| <code>Shield</code> || N/A || N/A || N/A || Number (integer) || ❌ || Vehicle's Shields (if applicable) || <code>100</code>
|-
| <code>SmallPortrait</code> || N/A || N/A || N/A || String  || ❌ || Vehicle's (Summon) Icon, at the top of the infobox next to the name || <code>100</code>
|-
| <code>Speed</code> || N/A || N/A || N/A || Number (float) || ✔️ || Vehicle's base speed in m/s || <code>15</code>
|-
| <code>Boost</code> || N/A || N/A || N/A || Number (float) || ✔️ || Vehicle's Sprint/Boost speed in m/s || <code>30</code>
|-
| <code>SummonAbility</code> || N/A || N/A || N/A || Table (of strings) || ❌ || Ability with which the vehicle can be summoned || <code>Summon Kaithe</code>
|-
| <code>SummonGear</code> || N/A || N/A || N/A || Table (of strings) || ✔️ || Gear Item with which the vehicle can be summoned || <code>K-Drive Launcher</code>
|-
| <code>TileSets</code> || N/A || N/A || N/A || Table (of strings) || ❌ || Tilesets the Vehicle can be summoned in || <code></code>
|-
|}

==For Module Use==
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>_IgnoreEntry</code> || Boolean || ❌ || For module use, indicates that this Warframe/Avatar table entry is special and should ignored when parsing table entries || <code>true</code>
|-
|}
<!--
==Data Validation==
===Validate data types of key-value pairs===
{{Column|3|
{{#invoke:Warframe/data/validate|validateDataTypes}}
}}

===Checking missing keys===
{{Column|3|
{{#invoke:Warframe/data/validate|checkForMissingData}}
}}
-->

==Data Sources==
*See [[Public Export]]

==Vehicle Data==
[[Category:Databases]]