Database of NPC vendor offerings. Items sold through the [[Market]] not included.
{{LatestEdit}}
== General Offerings Schema ==
<syntaxhighlight lang="lua">
			{
				{ "Synthesis Scanner", "Gear", { Credits = 5000 }, 25 },
				{ "Kinetic Siphon Trap", "Gear", { Credits = 5000 }, 10 },
				{ "Cephalon Simaris Sigil", "Sigil", 25000 },
				{ "Madurai Transmute Core", "Mod", 5000 },
				{ "Vazarin Transmute Core", "Mod", 5000 },
				{ "Naramon Transmute Core", "Mod", 5000 },
				{ "Exilus Adapter Blueprint", "Blueprint", 50000, 1, Prereq = "Natah (Quest)" },
				{ "Color Key Scene", "Captura", 100000, Limit = 1 },
				{ "Orokin Derelict Scene", "Captura", 100000, Limit = 1 },
				{ "Sanctuary Conduit Scene", "Captura", 100000, Limit = 1 },
				{ "Orvius Blueprint", "Blueprint", 50000, 1, Prereq = "The War Within" },
			}
</syntaxhighlight>

# First element in each table element will be the item's name as a string (required)
# Second element in each table element will represent item type as a string (required)
#* Possible values include <code>"Mod", "Blueprint", "Relic", "Endo", "Resource", "Arcane", "Item", "Sigil", "Cosmetic", "Captura", "Item", "Gear", and more</code>
# Third element in each table element will be the cost of item as an integer or a table of currencies mapped to its values (required)
# Fourth element in each table element will represent item quantity (optional)
* Optional named fields:
** <code>Timer</code> - If item is time-locked after purchasing, type in number of seconds before item is restocked in vendor
** <code>Prereq</code> - Represents the numerical Syndicate rank it is locked behind or a string containing prerequisite content required to be completed
** <code>Limit</code> - An integer that represents the maximum number of this item a player can purchase before the vendor locks you out from buying more

== Vendor Entry Schema ==
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Currency</code> || String || ❌ || For vendors that only use one currency, the name of the currency used to purchase items || <code>"Standing"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the vendor on the wiki || <code>"Vox Solaris (Syndicate)"</code>
|-
| <code>Name</code> || String || ✔️ || Name of vendor || <code>"Necraloid"</code>
|-
| <code>Offerings</code> || Table (of table entries) || ✔️ || A table of items that can be purchased from the vendor || See [[#General Offerings Schema]]
|-
| <code>Ranks</code> || Table (array-like, 0 indexed) || ❌ || An array of Syndicate rank names in the order of progression || <code>{ [0] = "Neutral", "Glinty", "Whozit", "Proper Felon", "Primo", "Logical" }</code>
|-
| <code>Type</code> || String || ✔️ || Type of vendor || <code>"Syndicate"</code>
|-
|}

==Vendor Data==
[[Category:Databases]]