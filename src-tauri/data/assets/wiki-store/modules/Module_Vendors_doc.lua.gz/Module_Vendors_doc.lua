<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Module ===
<syntaxhighlight lang="lua">
local Vendor = require('Module:Vendors')
</syntaxhighlight>
}}
</onlyinclude>