{{UpdateMe|Include official index links in schema like https://www.warframe.com/patch-notes/switch/29-0-0}}
Database for [[Module:Version]]. Entries are in order by date in ascending order and are indexed by <code>Name</code> and each element in <code>Aliases</code> tables.
{{LatestEdit}}
==Version Entry Schema==
<syntaxhighlight lang="lua">
	{
		Name = "Version name",
		Link = "Update page name",
		Aliases = { "Additional alias", "to be called" },
		ShortName = "Shorthand name (e.g. U15 or H29.10)",
		Date = "Date in YYYY-MM-DD (ISO format)",
		Parent = "Parent update alias",
		ForumLink = "URL of forum post",
		ArchiveLink = "URL of archived forum post",
		ArchiveDate = "YYYY-MM-DD",
		Timestamp = 1625583730
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Aliases</code> || Table (of strings) || ✔️ || Table containing alternative names of version || <code>{ "26.0.1" }</code>
|-
| <code>ArchiveDate</code> || String || ✔️ || ISO date in which URL was archived || <code>"2022-02-23"</code>
|-
| <code>ArchiveLink</code> || String || ✔️ || URL of archived forum post through [[wikipedia:Internet Archive|Internet Archive]] (https://archive.org/index.php). If [[wikipedia:Wayback Machine|Wayback Machine]] is down, use other fallbacks on [[wikipedia:List of web archiving initiatives|List of web archiving initiatives]] || <code>"https://web.archive.org/web/20210923205341/https://forums.warframe.com/topic/1281923-nidus-prime-plague-star-hotfix-3076/"</code>
|-
| <code>Date</code> || String || ✔️ || ISO date in which version was first introduced to the PC global build || <code>"2021-08-10"</code>
|-
| <code>ForumLink</code> || String || ✔️ || URL of PC patch notes on the official Warframe forums || <code>"https://forums.warframe.com/topic/1283036-nights-of-naberus-update-3080/"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the version on the wiki || <code>"Update 26#Hotfix 26.0.1"</code>
|-
| <code>Name</code> || String || ✔️ || Version's official name || <code>"Hotfix 26.0.1"</code>
|-
| <code>Parent</code> || String || ✔️ || Parent update version number/name or the update itself if it is a mainline || <code>"26"</code>
|-
| <code>ParentName</code> || String || ❌ || Name of parent update version or the name of update itself if it is a mainline || <code>"The War Within"</code>
|-
| <code>ShortName</code> || String || ✔️ || Shorthand name for version; use "U" for mainline updates and "H" for hotfixes || <code>"U26"</code> or <code>"H26.1"</code>
|-
| <code>Subtitle</code> || String || ❌ || Additional text alongside mainline version in forum post title that adds additional context; may share some values with <code>Alias</code> key. Text can also be derived from forum post content if title is not sufficient. || <code>"Veilbreaker"</code> or <code>"Beasts of the Sanctuary"</code>
|-
| <code>Timestamp</code> || Number (int) || ✔️ || Timestamp when forum post was made in Unix time. Human time to Unix time can be converted here: [https://www.unixtimestamp.com https://www.unixtimestamp.com] || <code>1634576666</code>
|-
|}

==Getting Timestamp of Forum Post==
On the official Warframe post, open your browser's element inspecter (default F12) and highlight over the post's timestamp (e.g. "Posted 2 hours ago") and look at the <code>time</code> tag's <code>datetime</code> attribute (e.g. <code><nowiki><time datetime="2022-01-25T18:57:47Z" title="2022-01-25 10:57  AM" data-short="2 hr">2 hours ago</time></nowiki></code>). You can convert the datetime string into Unix time using your desired online converter or parse the string in JavaScript using <code>Date.parse("timestamp string") / 1000</code>.

==Update vs. Hotfix (Warframe Development Cycle)==
{{Quote|'''What is a cert update? What is a hotfix?'''
Warframe updates in one of two ways; '''cert updates''' and '''hotfixes'''.  A '''cert update''' generally means a big title update that has been validated across all platforms. In other words, we make changes to the game’s code that must be “certified” by our platform partners before release. A '''hotfix''' on the other hand involves changes to non-code content, meaning we are able to launch a hotfix at any time without the certification process.|[DE]Momaw<ref>{{Ref|title=PSA: Citrine’s Last Wish Known Issues|author=[DE]Momaw|year=2023|month=2|day=22|publisher=Warframe Forums|url=https://forums.warframe.com/topic/1341201-psa-citrine%E2%80%99s-last-wish-known-issues/|access-date=2023-02-25|archive-url=https://web.archive.org/web/20230225003243/https://forums.warframe.com/topic/1341201-psa-citrine%E2%80%99s-last-wish-known-issues/|archive-date=2023-02-25}}</ref>
}}
*Certification updates are also known as mainline updates. Mainline updates have to go through certification processes on console platforms to ensure that Warframe's code follows console partner's requirements.
*When "code" is mentioned, the developers are referring to game engine code ("low-level code") rather than gameplay scripts, game assets, server-side changes, or game data that interface with the engine.
*Typical Warframe game development cycle:
**Mainline update 1.0
***Hotfix 1.0.1
***Hotfix 1.0.2
***... Subsequent hotfixes
**"Going dark", hotfixing paused to prepare for next mainline
**Mainline update 1.5 (additional content related to 1.0, uses "1.x" naming convention)
***Hotfix 1.5.1
***Hotfix 1.5.2
***... Subsequent hotfixes
**"Going dark"
**Mainline update 2.0 (next major content release)
**... Repeat
*See this forum post for more details: {{Ref|title=The Warframe Lexicon for Updates|first=Danielle|last=Sokolowski|year=2023|month=6|day=1|publisher=Warframe Forums|url=https://forums.warframe.com/topic/1355354-the-warframe-lexicon-for-updates/|access-date=2023-06-24|archive-url=https://web.archive.org/web/20230624170659/https://forums.warframe.com/topic/1355354-the-warframe-lexicon-for-updates/|archive-date=2023-06-24}}

==Full Version List==
{{#invoke:Version|fullVersionList}}

==References==
{{Reflist}}

==Data==
[[Category:Databases]]