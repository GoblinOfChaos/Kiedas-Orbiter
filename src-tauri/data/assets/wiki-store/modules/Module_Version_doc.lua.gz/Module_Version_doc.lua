<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Version|function|input1|input2|...}}</nowiki></code>

=== Template ===
In template: <code><nowiki>{{#invoke:Ver|function|input1|input2|...}}</nowiki></code><br />
In articles: <code><nowiki>{{Ver|input1|input2|...}}</nowiki></code>

=== Module ===
<syntaxhighlight lang="lua">
local p = {}
local Ver = require('Module:Version')

local function func(input)
    return Ver.getVersion(input)
end
</syntaxhighlight>
}}</onlyinclude>