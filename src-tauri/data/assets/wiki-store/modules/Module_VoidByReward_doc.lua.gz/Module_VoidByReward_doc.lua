{{Archived}}
All of this module's functions have been moved to [[Module:Void]] and reworked. This page is kept up for archival reasons.