{{UpdateMe}}
Contains the data for [[Void Relic]] drop tables. Does not have to be in alphabetical order. For the drop tables that Void Relics can be rewarded from, see [[Module:DropTables/data]].

Note that no drop chances are stored here since all relics of the same refinement share the same drop chances. Drop chances will be calculated by [[Module:Void/page]] for output onto articles.

Also the place to update if a Prime part's {{Resource|Orokin Ducats}} trade-in value is an anomaly for their rarity. See [[#Prime Item Ducat Sell Price]].

{{LatestEdit}}
==Relic Entry Schema==
<syntaxhighlight lang="lua">
	["Neo D3"] = {
		Drops = {
			{ Item = "Paris Prime", Part = "Lower Limb", Rarity = "Common" },
			{ Item = "Akbronco Prime", Part = "Blueprint", Rarity = "Common" },
			{ Item = "Nezha Prime", Part = "Systems Blueprint", Rarity = "Common" },
			{ Item = "Forma", ItemCount = 2, Part = "Blueprint", Rarity = "Uncommon" },
			{ Item = "Zakti Prime", Part = "Barrel", Rarity = "Uncommon" },
			{ Item = "Dethcube Prime", Part = "Blueprint", Rarity = "Rare" } 
		},
		Introduced = "30.3",
		IsBaro = false,
		Name = "Neo D3",
		Tier = "Neo",
		Vaulted = "30.3" 
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Drops</code> || Table || ✔️ || Drop table of relic; each table entry inside the <code>Drops</code> table represent a drop, each with a <code>Item</code> (a string representing item's full name), <code>ItemCount</code> (a int representing the item's amount if more than 1), <code>Part</code> (a string representing the item's part name), and <code>Rarity</code> (a string representing the rarity of drop; "Common", "Uncommon", or "Rare")
| <pre>
{
	{ Item = "Paris Prime", Part = "Lower Limb", Rarity = "Common" },
	{ Item = "Akbronco Prime", Part = "Blueprint", Rarity = "Common" },
	{ Item = "Nezha Prime", Part = "Systems Blueprint", Rarity = "Common" },
	{ Item = "Forma", ItemCount = 2, Part = "Blueprint", Rarity = "Uncommon" },
	{ Item = "Zakti Prime", Part = "Barrel", Rarity = "Uncommon" },
	{ Item = "Dethcube Prime", Part = "Blueprint", Rarity = "Rare" } 
}</pre>
|-
| <code>Introduced</code> || String || ✔️ || Shorthand name for the version in which relic was first introduced in the global build of WARFRAME || <code>"30.5"</code>
|-
| <code>IsBaro</code> || Boolean || ❌ || Denotes whether or not relic is exclusively bought from [[Baro Ki'Teer]]; default is false if not present || <code>false</code>
|-
| <code>Name</code> || String || ✔️ || The relic name || <code>"Neo D3"</code>
|-
| <code>Tier</code> || String || ✔️ || Relic tier ("Lith", "Meso", "Neo", "Axi", "Requiem", or "Vanguard") || <code>"Neo"</code>
|-
| <code>Vaulted</code> || String || ❌ || Shorthand name for the version in which relic was '''last''' removed from mission [[Drop Tables]] || <code>"30.5"</code>
|-
|}

==Prime Item Entry Schema==
Any entry added to <code>RelicData</code> will have its contents automatically inserted into in another subtable under <code>PrimeData</code> with the schema:
<syntaxhighlight lang="lua">
	Aklex Prime = {  -- Item name
		Parts = {
			Blueprint =  -- Part name
				Drops = {  
					["Axi A2"] = "Uncommon",  -- {string} Relic name and rarity of drop for that part
					["Neo O1"] = "Uncommon",
				},
				DucatValue = 45  -- {number} Ducat value when exchanged in Baro kiosk on relays
			},
			Link = 
				Drops = {
					["Axi A2"] = "Rare",
				},
				DucatValue = 100
			}
		},
		IsVaulted = false  -- {boolean} Vaulted status of item
	},
</syntaxhighlight>

===Viewing Contents via API Call===
{{JSWarning}}
For debugging purposes in browser console:
<syntaxhighlight lang="javascript">
let origin = "https://wiki.warframe.com";
let path = "/api.php";
let params = {
	action: "scribunto-console",
	format: "json",
	title: "Module:Void/data",
	content: "",
	question: `
local VoidData = require('Module:Void/data').PrimeData
local json = require('Module:JSON')
print(json.stringify(VoidData))`,
	clear: 1
};

// [ ["action", "scribunto-console"], ["format","json"], ... ] to "action=scribunto-console&format=json&..."
let queryString = new URLSearchParams([ ...Object.entries(params) ]).toString();

let url = new URL(`${origin}${path}?${queryString}`);

fetch(url)
	.then((data) => data.json())
	.then((json) => {
		if (json.print !== undefined) {
			console.log(JSON.parse(json.print));
		} else {
			throw json.html;	// Lua script error has occured
		}
	})
	.catch((error) => console.log(error));
</syntaxhighlight>

==Updating Notes==
Every [[Prime Access]] (once every ~3 months or financial quarter), DE will release new Void Relics that will contain at least one component/blueprint of the new Primes released. In addition, the oldest available Primes' relics will be removed from the game's [[Drop Table]]s to make room for the new relics and to not dilute the drop tables further. In some cases, newer/recent Prime items' parts would be unavailable to farm when DE removes these old relics, so they will add additional relics (separate from the newly released Primes) to make these items farmable.

It takes about 1-3 hours of manually editing to fully update [[Module:Void/data]] and [[Module:DropTables/data]] with the latest Prime content.

Updating the vaulted status of relics here will automatically tag the appropriate item articles with [[Template:ItemVault]].

===Prime Item Ducat Sell Price===
Editors do not need to add {{Resource|Orokin Ducats}} sell prices to every item manually. Prices can be determined based on drop rarity:
* Rare parts are worth 100 Ducats
* Uncommon parts are worth 45 Ducats
* Common parts are worth 15 Ducats
* If an item part is a uncommon and rare drop in different relics, it is worth 65 Ducats instead<ref>{{Ref|title=PSA: Future change in Ducat value for Baza Prime Blueprint|author=[DE]Momaw|year=2022|month=12|day=20|publisher=Warframe Forums|url=https://forums.warframe.com/topic/1335674-psa-future-change-in-ducat-value-for-baza-prime-blueprint/|access-date=2022-12-20|archive-url=https://web.archive.org/web/20221220171327/https://forums.warframe.com/topic/1335674-psa-future-change-in-ducat-value-for-baza-prime-blueprint/|archive-date=2022-12-20}}</ref>
* If an item part is a common and uncommon drop in different relics, it is worth 25 Ducats instead
* If an item part is a common and rare drop in different relics, it is worth 25 Ducats instead

If there is item that deviates from this rule, please update the <code>DUCAT_EXCEPTIONS</code> table.

===Creating New Void Relic Pages===
Use [[Template:VoidRelicArticle]] as reference for creating new Void Relic articles. See [[WARFRAME Wiki:Creating New Pages#Create New Void Relic Article]] for a sample text input to article wizard.

===Module:DropTables/data===
A simple find & replace should be enough to keep relic drops in [[Module:DropTables/data]] up-to-date with the latest [[Prime Access]]/[[Prime Resurgence]]. This is especially true if the number of relics introduced is equal to the number of relics removed from drop tables. However, there had been times where there is an unequal number of removed/added relics (mainly because some Prime weapons have varying numbers of parts associated with its crafting recipe; Prime parts are distributed across relics so that only one part from a unique weapon may be present in any given relic) which requires editors to manually go through each relevant mission drop table to audit for accuracy.

Good drop tables to check for what has changed:
*Tier 1 [[Survival]] for Lith relics like Mercury/Apollodorus (Survival)
*Tier 1 [[Defense]] (rotation B and C) for Meso relics like Mercury/Lares (Defense)
*Tier 3 [[Excavation]] (rotation B) for Neo relics like Pluto/Hieracon (Excavation)
*Tier 3 [[Excavation]] (rotation C) for Axi relics like Pluto/Hieracon (Excavation)

Notable patterns in relic drop distribution:
*Relics that are replaced are usually the same tier as the relic that replaces them (Lith, Meso, Neo, Axi)
*<s>[[Bounties]] usually only drop relics that have been recently unvaulted with the latest [[Prime Vault]]</s> With [[Prime Resurgence]] being a permanent feature in the game since {{ver|32.0.3}}, editors will most likely won't need to update bounty drop tables on a frequent basis. Vaulted relics that once existed in bounty drop tables are now replaced by an intermediary currency {{Resource|Aya}}.

====Examples====
=====U31.7 - Khora Prime=====
{{ver|31.7}} relic drop locations update for {{WF|Khora Prime}}/{{Weapon|Hystrix Prime}}/{{Weapon|Dual Keres Prime}} relics ({{WF|Inaros Prime}}/{{Weapon|Panthera Prime}}/{{Weapon|Karyst Prime}} vaulted):
*Old -> New
;{{WF|Inaros Prime}} -> {{WF|Khora Prime}}/{{Weapon|Hystrix Prime}}/{{Weapon|Dual Keres Prime}}
*{{Relic|Lith H4}} -> {{Relic|Lith K9}}
*{{Relic|Meso I2}} -> {{Relic|Meso H2}} (needed for {{WF|Nezha Prime}} BP, otherwise it's unobtainable)
*{{Relic|Meso N12}} -> {{Relic|Meso O5}} (needed for {{WF|Octavia Prime}} BP, otherwise it's unobtainable)
*{{Relic|Neo K4}} -> {{Relic|Neo N21}}
*{{Relic|Neo V10}} -> {{Relic|Neo D5}}
*{{Relic|Axi G7}} -> {{Relic|Axi N8}} (needed for {{WF|Nezha Prime}} Neuroptics BP, otherwise it's unobtainable)
*{{Relic|Axi K6}} -> {{Relic|Axi K8}}
*{{Relic|Axi O5}} -> {{Relic|Axi K9}}
;{{Weapon|Panthera Prime}} -> {{WF|Khora Prime}}/{{Weapon|Hystrix Prime}}/{{Weapon|Dual Keres Prime}}
*{{Relic|Meso G3}} -> {{Relic|Meso P8}}
*{{Relic|Meso P5}} -> {{Relic|Meso H3}}
*{{Relic|Meso P7}} -> {{Relic|Meso V7}}
*{{Relic|Axi S10}} -> {{Relic|Axi G8}}
*{{Relic|Axi S11}} -> {{Relic|Axi K10}} (is an additional relic for some Prime parts; not essential for a particular part to be farmable)
;{{Weapon|Karyst Prime}} -> {{Weapon|Hystrix Prime}}/{{Weapon|Dual Keres Prime}}
*{{Relic|Neo N20}} -> {{Relic|Neo G4}}
*{{Relic|Neo P4}} -> {{Relic|Neo S15}} (needed for {{Weapon|Bronco Prime}} Barrel, otherwise it's unobtainable)
*{{Relic|Axi K6}} -> {{Relic|Axi K8}}
*{{Relic|Axi K7}} -> {{Relic|Axi S12}} (needed for {{Weapon|Tenora Prime}} Stock, otherwise it's unobtainable)

=====U31.3 - Garuda Prime=====
{{ver|31.3}} relic drop locations update for {{WF|Garuda Prime}}/{{Weapon|Nagantaka Prime}}/{{Weapon|Corvas Prime}} relics ({{WF|Titania Prime}}/{{Weapon|Corinth Prime}}/{{Weapon|Pangolin Prime}} vaulted):
*Old -> New
*{{Relic|Axi S9}} -> {{Relic|Axi G7}}
*{{Relic|Axi M2}} -> {{Relic|Axi K7}}
*{{Relic|Axi P4}} -> {{Relic|Axi S10}}
*{{Relic|Axi C7}} -> {{Relic|Axi S11}}
*{{Relic|Neo P3}} -> {{Relic|Neo C2}}
*{{Relic|Neo N17}} -> {{Relic|Neo M4}}
*{{Relic|Neo N18}} -> {{Relic|Neo N20}}
*{{Relic|Meso P4}} -> {{Relic|Meso G4}}
*{{Relic|Meso Z4}} -> {{Relic|Meso N12}}
*{{Relic|Meso S11}} -> {{Relic|Meso P7}}
*{{Relic|Lith G4}} -> {{Relic|Lith G5}}
*{{Relic|Lith T8}} -> {{Relic|Lith H4}}
*{{Relic|Lith C9}} -> {{Relic|Lith N11}}
*{{Relic|Lith S11}} -> {{Relic|Lith S12}}
*{{Relic|Lith H3}} -> {{Relic|Lith Z3}}
*{{Relic|Lith N10}} -> {{Relic|Lith N12}}

=====U31.0 - Harrow Prime=====
{{ver|31}} relic drop locations update for {{WF|Harrow Prime}}/{{Weapon|Scourge Prime}}/{{Weapon|Knell Prime}} relics ({{WF|Ivara Prime}}/{{Weapon|Baza Prime}}/{{Weapon|Aksomati Prime}} vaulted):
*Old -> New
*{{Relic|Lith A4}} -> {{Relic|Lith T9}}
*{{Relic|Lith I1}} -> {{Relic|Lith S11}}
*{{Relic|Lith K7}} -> {{Relic|Lith H3}}
*{{Relic|Lith N7}} -> {{Relic|Lith C9}}
*{{Relic|Lith N8}} -> {{Relic|Lith N9}}
*{{Relic|Lith T7}} -> {{Relic|Lith T8}}
*{{Relic|Meso B5}} -> {{Relic|Meso I2}}
*{{Relic|Meso B6}} -> {{Relic|Meso G3}}
*{{Relic|Meso C6}} -> {{Relic|Meso A3}}
*{{Relic|Meso S10}} -> {{Relic|Meso S11}}
*{{Relic|Neo P2}} -> {{Relic|Neo P2}} (mistake by the devs for still being in the game at the time, fixed in {{ver|31.0.11}} by replacing with {{Relic|Neo P4}})
*{{Relic|Neo T4}} -> {{Relic|Neo K4}}
*{{Relic|Neo T5}} -> {{Relic|Neo N18}}
*{{Relic|Axi A13}} -> {{Relic|Axi T8}}
*{{Relic|Axi A14}} -> {{Relic|Axi K6}}
*{{Relic|Axi C6}} -> {{Relic|Axi P4}}
*{{Relic|Axi G6}} -> {{Relic|Axi C7}}
*{{Relic|Axi I2}} -> {{Relic|Axi S9}}

==References==
{{Reflist}}

==Void Relic Data==
[[Category:Databases]]