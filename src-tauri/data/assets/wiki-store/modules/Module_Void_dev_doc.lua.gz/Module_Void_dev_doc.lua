{{Edit|Module:Void/dev/doc|Edit /doc}}
{{#invoke:Void/dev|item|Braton|Barrel|Lith}}
{{#invoke:Void/dev|item|BRATON|BARREL|Lith}}
{{#invoke:Void/dev|ducatRelicList|relicTier=Axi|listMode=unvaulted}}