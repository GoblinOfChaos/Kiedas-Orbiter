<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Module ===
<syntaxhighlight lang="lua">
local Void = require('Module:Void')

local function func(input)
    return Void.getRelicTotal()
end
</syntaxhighlight>

== Product Backlog ==
{{{!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Last Update
{{!}}-
{{ProjectTableRow
|name=Data validation
|type=Dev
|status=New
|priority=Low
|contact=
|desc=Add validation functions for <code>RelicData</code> and <code>PrimeData</code> in [[Module:Void/data/validate]]. This is to ensure the accuracy of our data based on known patterns and/or rules.
|start=19:21, 30 June 2021 (UTC)
|end=
}}
{{ProjectTableRow
|name=Refactor and clean up
|type=Dev
|status=Active
|priority=Medium
|contact=
|desc=Remove unused functions and perform some refactoring, especially with triple loop situations (though not entirely clear how to optimize table accesses since when we are building wikitables, we loop through all the data)

04:28, 16 October 2021 (UTC) update: Removed <code>p._getItemName()</code> which was used to convert item names from M:Void/data from SCREAMING UPPER CASE to Title Case. This is not needed as all names are stored in Title Case to avoid extra function calls.
|start=21:36, 22 June 2021 (UTC)
|end=04:28, 16 October 2021 (UTC)
}}
{{!}}}

==Finished Issues==
{{{!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Completion Date
{{!}}-
{{ProjectTableRow
|name=Luafy [[Template:RelicInfobox]], [[Template:RelicTable]], and [[Template:RelicTable/Check]]
|type=Dev & Refactor
|status=Active
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=Luafy the contents of these templates which will also remove the need for <code>p.getRelicDrop(frame)</code>, <code>p._getItemIconForDrop(itemName)</code>, and <code>p.getDucatValue(frame)</code>
|start=02:15, 24 June 2021 (UTC)
|end=18:55, 30 June 2021 (UTC)
}}
{{ProjectTableRow
|name=Ducat values in /data
|type=Dev
|status=Completed
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=Add a new "DucatValue" key to each prime part in the PrimeData subtable of M:Void/data.
|start=3:56, 23 June 2021 (UTC)
|end=[https://wiki.warframe.com/w/Module:Void?oldid=2208439 02:11, 24 June 2021 (UTC)]
}}
{{ProjectTableRow
|name=Documentation
|type=Documentation
|status=Completed
|priority=High
|contact=[[User:Cephalon Scientia]]
|desc=Add LuaDoc-style documentation for all functions.
|start=
|end=21:36, 22 June 2021 (UTC)
}}
{{ProjectTableRow
|name=Merging [[Module:VoidByReward]] to [[Module:Void]]
|type=Dev
|status=Completed
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=Migrating all functions from M:VoidByReward to this module.
|start=
|end=21:36, 22 June 2021 (UTC)
}}
{{ProjectTableRow
|name=Relic infobox
|type=Dev
|status=Active
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=Luafy the contents of [[Template:RelicInfobox]] which use parser functions to render the infobox and message boxes.
|start=
|end=21:36, 22 June 2021 (UTC)
}}
{{ProjectTableRow
|name=Introduced and vaulted keys
|type=Dev
|status=Completed
|priority=High
|contact=[[User:Cephalon Scientia]]
|desc=Adding <code>Introduced</code> and <code>Vaulted</code> key corresponding to the versions that they were first introduced and last vaulted for each relic table entry.
|start=
|end=21:36, 22 June 2021 (UTC)
}}
{{ProjectTableRow
|name=Access relic data by item and part names
|type=Dev
|status=Completed
|priority=High
|contact=[[User:Cephalon Scientia]]
|desc=Adding a new subtable part of /data that uses item and part names to get the relics that they are dropped from; think of it as the 'inverse' of the original relic data table.
|start=
|end=21:36, 22 June 2021 (UTC)
}}
{{!}}}
}}</onlyinclude>