<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
==About==
Since all individual [[Void Relic]] articles follow the same format and require frequent updates to its drop locations whenever a new [[Prime Access]] is released (every fiscal quarter), we can port their contents to a Lua module for semi-automation based on changes to [[Module:DropTables/data]], [[Module:Void/data]] (Void Relic rewards), [[Module:Missions/data]] (mission nodes and mission types), [[Module:Warframes/data]] (Prime Warframes), [[Module:Weapons/data]] (Prime weapons), [[Module:Companions/data]] (Prime companions), and [[Module:Resources/data]] (misc resources like {{Resource|Forma}}) data stores. This allows scaling of content generation without the help of a bot editor and allows for consistency in how content are structured. Message localization is also possible if done this way, but is not fully implemented.

Normally editors wouldn't need to edit this module but beware of script errors occurring if one decides to update how Void Relic articles are formatted. The module's main function <code>p.buildRelicPage()</code> outputs the wikitext that is used to render the article's content. You can view the raw wikitext/HTML output by invoking the function on [[Special:ExpandTemplates]].

==Usage==
===Template===
In template: <code><nowiki>{{#invoke:Void/infobox|buildRelicPage}}</nowiki></code><br />
In articles: <code><nowiki>{{RelicPage}}</nowiki></code>

==Notes==
*Successor of [[Template:RelicInfobox]], [[Template:RelicTable]], and [[Template:RelicTable/Check]]; saves around 0-0.1 seconds and 3-6 MB of memory of Lua scripts running on relic pages
*If you want to edit the wikitext output, go to <code>p.buildRelicInfobox()</code> and <code>p.buildRelicDropTable()</code>
}}</onlyinclude>