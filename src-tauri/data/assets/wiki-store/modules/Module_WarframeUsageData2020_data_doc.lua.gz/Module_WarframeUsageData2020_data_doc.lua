Warframe and weapon usage stats in 2020 (2020-01-01 to 2020-12-31) for all platforms on the global build of [[WARFRAME]]:
*<code>ALL</code> - All of the below
*<code>NI</code> - Nintendo Switch
*<code>PC</code> - PC
*<code>PS</code> - Playstation 4 (Playstation 5 build was also released in late 2020, but do not think it is significant enough to be reflected in data)
*<code>XB</code> - Xbox One

Each platform is divided by equipment type:
*<code>Melee</code> - Melee weapons, including Zaw strikes
*<code>Primary</code> - Primary weapons, including primary Kitgun chambers
*<code>Secondary</code> - Secondary weapons, including secondary Kitgun chambers
*<code>Warframe</code> - Warframes

Each item has percent usage stats divided among Mastery Ranks of cumulative playtime of all players within a platform. Percent usage stat is based on amount of time item was equipped at Rank 30 or higher, omitting the time spent leveling for the first time.

Data source: https://www-static.warframe.com/repos/WarframeUsageData2020.json

Website version: https://www.warframe.com/2020stats

==Notes==
*<code>DARK HYBRID SWORD - DUAL</code> refers to Dark Split Sword w/ Dual Swords stance
*<code>DARK HYBRID SWORD - SINGLE</code> refers to Dark Split Sword w/ Heavy Blade stance

==TODO==
*MediaWiki v1.39 will introduce <code>mw.loadJsonData()</code> (https://gerrit.wikimedia.org/r/c/mediawiki/extensions/Scribunto/+/853713/) which will allow efficient loading of JSON objects from JSON content model pages on the wiki. Move JSON data out of Lua module to a JSON content model page when the time comes.