Database of [[WARFRAME]]'s playable avatars which includes [[Warframes]], [[Necramech]]s, [[Archwing]]s, and [[Operator]]s.
__TOC__
{{LatestEdit}}
==Warframe/Avatar Data Schema==
<syntaxhighlight lang="lua">
		["Warframe Name"] = {
			_IgnoreEntry = true,
			Abilities = { "1", "2", "3", "4" },
			Armor = 100,
			AuraPolarity = "Madurai",
			Conclave = false,
			CodexSecret = false,
			Description = "In-Game Description",
			Energy = 100,
			FullImages = { { TabName = "Default", Image = "WarframeName.png" } },
			Health = 100,
			Helmet = "WarframeHelmet.png"
			Image = "WarframeName_Thumb.png"
			InitialEnergy = 50,
			InternalName = "/Lotus/Powersuits/Warframe/Warframe",
			Introduced = "30.0",
			Link = "Article Name",
			MaxRank = 30,
			Name = "Warframe Name",
			Passive = "In-game passive description",
			Polarities = { "Madurai", "Naramon" },
			Portrait = "FrameIcon272.png",
			Progenitor = "Element Name",
			Shield = 100,
			Playstyle = { "" },
			Sprint = 1.10,
			SquadPortrait = "WarframeNameLargePortrait.png",
			Themes = "Space Ninja",
			Subsumed = "Ability Name",
			Sex = "Female" 
		},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! [[Arsenal]] EN L10n !! [[Public Export]] Equivalent !! Internal Equivalent !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Abilities</code> || N/A || <code>abilities</code> || <code>AbilityTypes</code> || Table (of strings) || ✔️ || Names of the abilities in the order of unlock || <code>{ "Tail Wind", "Airburst", "Turbulence", "Tornado" }</code>
|-
| <code>Armor</code> || Armor || <code>armor</code> || <code>ArmourRatingOverride</code> || Number (integer) || ✔️ || Warframe/Avatar's base [[Armor]] at Rank 0 || <code>100</code>
|-
| <code>ArmorRank30</code> || Armor || N/A || N/A || Number (integer) || ❌ || Warframe/Avatar's unmodded [[Armor]] at Rank 30 (not base armor) || <code>300</code>
|-
| <code>AuraPolarity</code> || N/A || N/A || <code>ArtifactSlots</code> || String or Table (array of strings) || ✔️ || [[Polarity]] of Aura slot || <code>"V"</code> or <code>"Madurai"</code>
|-
| <code>CodexSecret</code> || N/A || <code>codexSecret</code> || <code>CodexSecret</code> || Boolean || ✔️ || Whether or not the Warframe/Avatar has an entry in the [[Codex]] before the player acquires it; defaults to false || <code>false</code>
|-
| <code>CompatibilityTags</code> || N/A || N/A || <code>CompatibilityTags</code> || Table (array of strings) || ❌ || Tags that denote item compatibility. In other words, items with these tags can/cannot have a particular mod installed with the same tag. || <code>{ "SANDMAN" }</code>
|-
| <code>Conclave</code> || N/A || N/A || <code>AvailableOnPvp</code> || Boolean || ❌ || Whether or not the Warframe/Avatar can be used in [[Conclave]] || <code>false</code>
|-
| <code>Description</code> || N/A || <code>description</code> || <code>LocalizeDescTag</code> || String || ✔️ || In-game description || <code>"Excalibur epitomizes the warrior spirit. His master swordsmanship deals high damage. He is the embodiment of martial excellence."</code>
|-
| <code>Energy</code> || Energy || <code>power</code> || <code>MaxEnergy</code> || Number (float) || ✔️ || Warframe/Avatar's base [[Energy]] capacity at Rank 0 || <code>150</code>
|-
| <code>EnergyRank30</code> || Energy || N/A || N/A || Number (integer) || ❌ || Warframe/Avatar's unmodded [[Energy]] capacity at Rank 30 (not base energy) || <code>300</code>
|-
| <code>FullImages</code> || N/A || N/A || N/A || Table (array of objects with key/value pairs) || ✔️ || Full body image file name(s) of the Warframe/Avatar as uploaded to the wiki (for infoboxes) in order of appearance in the infobox. <code>TabName</code> describes the avatar form associated with the image. || <code>{ { TabName = "Composite", Image = "Equinox.png" }, { TabName = "Day", Image = "Equinox-Day.png" }, { TabName = "Night", Image = "Equinox-Night.png" } }</code>
|-
| <code>Health</code> || Health || <code>health</code> || <code>MaxHealthOverride</code> || Number (integer) || ✔️ || Warframe/Avatar's base [[Health]] at Rank 0 || <code>100</code>
|-
| <code>HealthRank30</code> || Health || N/A || N/A || Number (integer) || ❌ || Warframe/Avatar's unmodded [[Health]] at Rank 30 (not base health) || <code>300</code>
|-
| <code>Helmet</code> || N/A || N/A || N/A || String || ✔️ || Image file name of the Warframe-Helmet as seen in in-game menus || <code>"AshHelmet.png"</code>
|-
| <code>Image</code> || N/A || <code>textureLocation</code> || <code>Icon</code> || String || ✔️ || Image file name of the Warframe/Avatar as seen in in-game menus || <code>"Ash_Thumb.png"</code>
|-
| <code>InitialEnergy</code> || Starting Energy || N/A || <code>InitialEnergy</code> || Number (integer) || ✔️ || Warframe/Avatar's initial/starting energy value when spawning (not the same as base energy capacity) || <code>50</code>
|-
| <code>InternalName</code> || N/A || <code>uniqueName</code> || <code>TypeName</code> || String || ❌ || The full unique name of a Warframe/Avatar formatted as a file path || <code>"/Lotus/Powersuits/Ninja/Ninja"</code>
|-
| <code>Introduced</code> || N/A || N/A || N/A || String || ✔️ || The game version in which the Warframe/Avatar was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || N/A || N/A || N/A || String || ✔️ || Page/article link to the Warframe/Avatar on the wiki || <code>"Excalibur"</code>
|-
| <code>Mastery</code> || N/A || <code>masteryReq</code> || <code>RequiredLevel</code> || Number (integer) || ✔️ || [[Mastery Rank]] requirement || <code>5</code>
|-
| <code>MaxRank</code> || N/A || N/A || <code>LevelCap</code> || Number (integer) || ❌ || The maximum rank that they can level up to || <code>40</code>
|-
| <code>Name</code> || N/A || <code>name</code> || <code>LocalizeTag</code> || String || ✔️ || Warframe/Avatar's name || <code>"Excalibur"</code>
|-
| <code>Passive</code> || N/A || <code>passiveDescription</code> || <code>PassiveAbilityLocTag</code> || String || ✔️ || In-game passive description as seen in arsenal || <code>"Zephyr moves faster and falls slower while airborne. Also gain 150% Critical Hit chance with weapons while airborne."</code>
|-
| <code>Playstyle</code> || N/A || N/A || N/A || Table (of strings) || ✔️ || General playstyle of Warframe/Avatar. Initial values are seeded from this spreadsheet by DE: https://docs.google.com/document/d/13CzaOU3XeBGRDEtKU-RFu_qb4LkPqyveXl6iFcFOlKE || <code>{ "Damage", "Support" }</code>
|-
| <code>Polarities</code> || N/A || N/A || <code>ArtifactSlots</code> || Table (array of strings) || ✔️ || Full names of the Warframe/Avatar's non-Universal [[polarity|polarities]] || <code>{ "Naramon", "Madurai" }</code>
|-
| <code>Portrait</code> || N/A || N/A || N/A || String || ✔️ || Half body image file name of Warframe/Avatar as uploaded to the wiki || <code>"AshIcon272.png"</code>
|-
| <code>Progenitor</code> || N/A || N/A || N/A || String || ✔️ || For the [[Adversary System]], the damage type associated with using the Warframe/Avatar to generate a new lich || <code>"Radiation"</code>
|-
| <code>SellPrice</code> || N/A || N/A || <code>SellingPrice</code> || Number (integer) || ❌ || Warframe/Avatar's selling price in [[Credits]] when removed from the player's inventory || <code>10000</code>
|-
| <code>Sex</code> || N/A || N/A || N/A || String || ✔️ || Warframe/Avatar's official sex and/or gender || <code>"Male"</code>
|-
| <code>Shield</code> || Shield || <code>shield</code> || <code>MaxShieldOverride</code> || Number (integer) || ✔️ || Warframe/Avatar's base [[Shield]] at Rank 0 || <code>100</code>
|-
| <code>ShieldRank30</code> || Shield || N/A || N/A || Number (integer) || ❌ || Warframe/Avatar's unmodded [[Shield]] at Rank 30 (not base shield) || <code>300</code>
|-
| <code>Sprint</code> || Sprint Speed || <code>sprintSpeed</code>|| <code>MovementSpeedMultiplier</code> || Number (float) || ✔️ || Warframe/Avatar's base [[Sprint Speed]] || <code>1.1</code>
|-
| <code>SquadPortrait</code> || N/A || N/A || N/A || String || ✔️ || Squad icon image file name of Warframe/Avatar as uploaded to the wiki || <code>"AshLargePortrait.png"</code>
|-
| <code>Stamina</code> || N/A || N/A || <code>MaxStaminaOverride</code> || Number (integer) || ❌ || For [[Necramech]]s, the base stamina/engine capacity at Rank 0 || <code>200</code>
|-
| <code>Subsumed</code> || N/A || N/A || <code>IsHelminth</code> || String || ✔️ || For the [[Helminth]], the name of the ability that is unlocked for transfer onto other Warframes/Avatars after sacrificing a base Warframe/Avatar to the Helminth || <code>"Shuriken"</code>
|-
| <code>Tactical</code> || N/A || N/A || N/A || String || ✔️ || The ability that can be remotely used through the Tactical Menu while on a [[Railjack]]. See [[Railjack/Tactical Menu#Ability Kinesis]] for more details. || <code>"Smoke Screen"</code>
|-
| <code>Themes</code> || N/A || N/A || N/A || String || ✔️ || Warframe/Avatar's thematic inspirations and references || <code>"Ninja, Assassin"</code>   
|-
|}

==For Module Use==
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>_IgnoreEntry</code> || Boolean || ❌ || For module use, indicates that this Warframe/Avatar table entry is special and should ignored when parsing table entries || <code>true</code>
|-
|}
<!--
==Data Validation==
===Validate data types of key-value pairs===
{{Column|3|
{{#invoke:Warframe/data/validate|validateDataTypes}}
}}

===Checking missing keys===
{{Column|3|
{{#invoke:Warframe/data/validate|checkForMissingData}}
}}
-->

==Data Sources==
*See [[Public Export]].
*Portrait images are created by the community: [[WARFRAME Wiki:Warframe Portraits]].

==Warframe/Avatar Data==
[[Category:Databases]]