<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Direct Invocation ===
<code><nowiki>{{#invoke:Warframes|function|input1|input2|...}}</nowiki></code>

=== Module ===
<syntaxhighlight lang="lua">
local Warframe = require('Module:Warframes')

local function func(input)
    return Warframe.getWarframe(input)
end
</syntaxhighlight>

== Product Backlog ==
{{(!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Last Update
{{!}}-
{{ProjectTableRow
|name=Remove the need for Portrait key
|type=Refactor/Dev/Edit
|status=New
|priority=Low
|contact=
|desc=
*Keep only one key related to Warframe images (e.g. <code>Image</code>) and have it set to the name of the image file of the full portrait Warframe.
*Remove <code>Portrait</code> key.
*Use CSS to crop full portrait image to around 50% of the height from the top in order to use in [[Template:WarframeNavVisual]].
**This is done instead of saving a separate file that already crops the image to a half-body portrait.
|start=06:46, 6 December 2021 (UTC)
|end=
}}
{{!)}}
}}</onlyinclude>