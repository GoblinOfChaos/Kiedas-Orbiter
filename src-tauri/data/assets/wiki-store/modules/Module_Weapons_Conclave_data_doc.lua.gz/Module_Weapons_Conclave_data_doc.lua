Database for [[WARFRAME]]'s [[Conclave]] weapon stat data.

Google docs on Conclave weapon stats: https://docs.google.com/spreadsheets/d/1q2BcFDKtIz_P5RC1b0cH0JUVP_UEgyDasjQq9Ck4kV0/edit?usp=sharing

{{LatestEdit}}
==Horizontal Partitions (and where to update data)==
*[[Module:Weapons/Conclave/data/primary]] - primary guns
*[[Module:Weapons/Conclave/data/secondary]] - secondary guns
*[[Module:Weapons/Conclave/data/melee]] - melee weapons

==Attack Data Schema==
<syntaxhighlight lang="lua">
	{
		AttackName = "Normal Attack",
		AmmoCost = 0.5,
		BurstCount = 1,
		Damage = { Impact = 1, Puncture = 1, Slash = 1 },
		FireRate = 1.0,
		Falloff = { StartRange = 400, EndRange = 600, Reduction = 0.2 },
		ShotType = "Hit-Scan",
		ShotSpeed = 80,
		Trigger = "Semi-Auto"
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>AttackName</code> || String || ❌ || Name of attack; defaults to "Normal Attack" || <code>"Normal Attack"</code> or <code>"AoE Explosion"</code> 
|-
| <code>AmmoCost</code> || Number (float) || ❌ || Ammo consumed on a single attack input; defaults to 1 || <code>0.5</code> or <code>10</code>
|-
| <code>AmmoType</code> || String || ❌ || Type of ammo pickups that replenishes ammo reserves; "None" for battery weapons and "Energy" for those that use Warframe energy || <code>"Sniper"</code>
|-
| <code>BurstCount</code> || Number (integer) || ❌ || For burst-fire weapons, the number of shots per burst; for attacks that shoot bursts that scale off magazine size (e.g {{Weapon|Pandero}}), use the base magazine amount as the burst count || <code>4</code>
|-
| <code>BurstDelay</code> || Number (float) || ❌ || For burst-fire weapons, the time in seconds between each burst; omit this for attacks that shoot bursts that scale off magazine size as reload time is the delay effectively || <code>0.04</code>
|-
| <code>BurstFireRate</code> || Number (float) || ❌ || For burst-fire weapons, the [[Fire Rate|fire rate]] of weapon during burst || <code>9.09</code>
|-
| <code>Damage</code> || Table (map of floats) || ✔️ || Table of [[damage]] types that the weapon deals and their individual damage values. Possible keys: Impact, Puncture, Slash, Cold, Electricity, Heat, Toxin, Blast, Corrosive, Gas, Magnetic, Radiation, Viral, Void, and MinProgenitorBonus (random element for Kuva/Tenet weapons) || <code>{ Impact = 100, Puncture = 25, Slash = 30 }</code>
|-
| <code>ChargeTime</code> || Number (float) || ❌ || For charged attacks, the base charge time for a fully charged attack || <code>0.5</code>
|-
| <code>EffectDuration</code> || Number (float) || ❌ || For special attacks, the time in seconds that a special effect lasts for (e.g. {{Weapon|Pox}}'s toxin clouds or {{Weapon|Zenistar}}'s disc) || <code>5</code>
|-
| <code>ExplosionDelay</code> || Number (float) || ❌ || For AoE attacks, the time in seconds between initial shot and explosion; the same as "Embedded Delay" stat in-game || <code>0.5</code>
|-
| <code>Falloff</code> || Table (map of floats) || ❌ || Attack's base [[Damage Falloff]] stats; includes starting distance in meters when falloff multiplier comes into play, ending distance in meters when falloff multipler is at max reduction, and the maximum damage reduction as a decimal || <code>{ StartRange = 0, EndRange = 5, Reduction = 0.5 }</code>
|-
| <code>FireRate</code> || Number (float) || ✔️ || Attack's base [[Fire Rate]] or [[Attack Speed]] || <code>6.5</code>
|-
| <code>ForcedProcs</code> || Table (array of strings) || ❌ || Attack's forced procs, if any || <code>{ "Impact", "Slash" }</code>
|-
| <code>IsSilent</code> || Boolean || ❌ || Whether or not an attack has a silent [[Noise Level]]; defaults to false || <code>true</code>
|-
| <code>Multishot</code> || Number (integer) || ❌ || Attack's base [[Multishot]] value; defaults to 1 || <code>10</code>
|-
| <code>PunchThrough</code> || Number (float) || ❌ || Attack's base [[Punch Through]] value in meters; defaults to 0  || <code>1.5</code>
|-
| <code>Radius</code> || Number (float) || ❌ || For AoE attacks, the base radius of area of effect in meters || <code>5</code>
|-
| <code>Range</code> || Number (float) || ❌ || For maximum range of a particular attack in meters || <code>40</code>
|-
| <code>ShotType</code> || String || ✔️ || Attack's shot type (e.g. "Hit-Scan", "Projectile", "Discharge" for beam/continuous weapons, and "AoE" for area of effects) || <code>Projectile</code>
|-
| <code>ShotSpeed</code> || Number (integer) || ❌ || For projectile attacks, attack's [[Projectile Speed|projectile speed]] || <code>50</code>
|-
| <code>Trigger</code> || String || ❌ || For weapons with multiple [[Trigger Type]]s, attack's trigger type || <code>"Semi-Auto"</code>
|-
|}

==Gun Entry Schema==
<syntaxhighlight lang="lua">
["Long Gun Weapon Name"] = {
	Accuracy = 100,
    Attacks = {
		{
			AttackName = "Normal",
			AmmoCost = 0.5,
			BurstCount = 1,
			Damage = { Impact = 1, Puncture = 1, Slash = 1 },
			FireRate = 1.0,
			Falloff = { StartRange = 400, EndRange = 600, Reduction = 0.2 },
			HeadshotMultiplier = 2,
			ShotType = "Hit-Scan",
			ShotSpeed = 100,
			Trigger = "Semi-Auto"
 		}
	},
	Introduced = "",
    Link = "Page Name",
	Magazine = 1,
	MaxAmmo = 540,
	Reload = 1,
	ReloadStyle = "Regenerate",
	SniperComboMin = 1,
	SniperComboReset = 1,
	Spool = 5,
	Trigger = "Semi-Auto",
	Traits = { "Grineer" },
	Users = { },
	Zoom = { "2.0x", "4.0x" }
},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Accuracy</code> || Number (float) || ✔️ || Gun's base [[Accuracy]] value || <code>100</code>
|-
| <code>Attacks</code> || Table || ✔️ || Contains attack data for the weapon || See [[#Attack Data Schema]]
|-
| <code>Class</code> || String || ❌ || Weapon class for modding or a subclass of the weapon in its equip slot; in the case of [[Exalted Weapon]]s, it is just "Exalted Weapon" || <code>"Sniper Rifle"</code>
|-
| <code>ExilusPolarity</code> || String || ❌ || Polarity on Exilus slot || <code>"Madurai"</code>
|-
| <code>Family</code> || String || ❌ || Weapon family that it belongs to, corresponding to the [[Riven Mods|Riven Mod]] compatibility || <code>"Latron"</code>
|-
| <code>HeadshotMultiplier</code> || Number (float) || ✔️ || Damage multiplier on headshots || <code>2</code>
|-
| <code>Image</code> || String || ❌ || Image file name of the weapon as uploaded to the wiki || <code>CrpBFG.png</code>
|-
| <code>Introduced</code> || String || ❌ || The game version in which the weapon was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the weapon on the wiki || <code>"Conclave:Artemis Bow (Weapon)"</code>
|-
| <code>Magazine</code> || Number (integer) || ✔️ || Gun's base magazine size || <code>45</code>
|-
| <code>Mastery</code> || Number (integer) || ❌ || [[Mastery Rank]] requirement || <code>5</code>
|-
| <code>MaxAmmo</code> || Number (integer) || ✔️ || Gun's base maximum reserve ammo (this excludes magazine size) || <code>210</code>
|-
| <code>Name</code> || String || ❌ || Weapon's name || <code>"Primary Vermisplicer Chamber"</code>
|-
| <code>Polarities</code> || Table (array of strings) || ❌ || Full names of the weapon's non-Universal [[polarity|polarities]] || <code>{ "Naramon", "Madurai" }</code>
|-
| <code>Reload</code> || Number (float) || ✔️ || Gun's base [[reload]] time in seconds || <code>3.5</code>
|-
| <code>ReloadDelay</code> || Number (float) || ❌ || For rechargeable/battery weapons, the time in seconds after firing before magazine 'recharges' or is replenished || <code>0.5</code>
|-
| <code>ReloadRate</code> || Number (float) || ❌ || For rechargeable/battery weapons, the rate at which magazine 'recharges' or is replenished per second || <code>40</code>
|-
| <code>ReloadStyle</code> || String || ❌ || Gun's unique reload type for weapons like {{Weapon|Cycron}} or {{Weapon|Corinth}} || <code>"Regenerate"</code> or <code>"ByRound"</code>
|-
| <code>Slot</code> || String || ❌ || The weapon slot that the weapon can be equipped on; in the case of [[Exalted Weapon]]s, it is just their modding class || <code>"Primary"</code>
|-
| <code>SniperComboMin</code> || Number (integer) || ❌ || For sniper rifles, the minimum number of hits to gain combo bonus || <code>1</code>
|-
| <code>SniperComboReset</code> || Number (integer) || ❌ || For sniper rifles, the number of seconds after last hit before combo number goes down || <code>3</code>
|-
| <code>Spool</code> || Number (integer) || ❌ || For auto-spool weapons, number of shots until weapon reaches max [[Fire Rate|fire rate]] || <code>5</code>
|-
| <code>Trigger</code> || String || ✔️ || Gun's [[Trigger Type]] || <code>"Auto"</code> or <code>"Auto / Burst"</code>
|-
| <code>Traits</code> || Table (array of strings) || ❌ || Gun's categorical traits || <code>{ "Grineer", "Wraith" }</code>
|-
| <code>Zoom</code> || Table (array of strings) || ❌ || The levels of zoom that the gun offers || <code>{ "2.0x", "4.5x" }</code>
|-
|}

==Melee Entry Schema==
<syntaxhighlight lang="lua">
["Melee Weapon Name"] = {
	Attacks = {
    	{
			Damage = { Impact = 1, Puncture = 1, Slash = 1 },
			FireRate = 1
		}
	},
	FollowThrough = 0.7,
	HeavyAttack = 1284,
	HeavySlamAttack = 1070,
	HeavyRadialDmg = 1070,
	HeavySlamRadius = 8,
	Introduced = "",
	MeleeRange = 3,
	SlamAttack = 642,
	SlamElement = "Heat",
	SlamRadialDmg = 214,
	SlamRadialElement = "Heat",
	SlamRadialProcs = { "Heat" },
	SlamRadius = 7,
	SlideAttack = 1,
	StancePolarity = "V",
	Traits = { "Tenno" },
},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Attacks</code> || Table || ✔️ || Contains attack data for the weapon || See [[#Attack Data Schema]]
|-
| <code>Class</code> || String || ❌ || Weapon class for modding or a subclass of the weapon in its equip slot; in the case of [[Exalted Weapon]]s, it is just "Exalted Weapon" || <code>"Nikana"</code>
|-
| <code>Family</code> || String || ❌ || Weapon family that it belongs to, corresponding to the [[Riven Mods|Riven Mod]] compatibility || <code>"Machete"</code>
|-
| <code>FollowThrough</code> || Number (float) || ✔️ || Melee's base follow through multiplier as a decimal || <code>0.6</code>
|-
| <code>HeavyAttack</code> || Number (float) || ✔️ || Melee's base heavy attack damage || <code>1284</code>
|-
| <code>HeavySlamAttack</code> || Number (float) || ✔️ || Melee's base heavy slam direct hit damage || <code>1070</code>
|-
| <code>HeavyRadialDmg</code> || Number (float) || ✔️ || Melee's base heavy slam radial attack damage || <code>1070</code>
|-
| <code>HeavySlamRadius</code> || Number (integer) || ✔️ || Melee's base heavy slam radius in meters || <code>8</code>
|-
| <code>Image</code> || String || ❌ || Image file name of the weapon as uploaded to the wiki || <code>CrpBFG.png</code>
|-
| <code>Introduced</code> || String || ❌ || The game version in which the weapon was first introduced in the global build of [[WARFRAME]] || <code>"30.5"</code> or <code>"Specters of the Rail"</code>
|-
| <code>Link</code> || String || ✔️ || Page/article link to the weapon on the wiki || <code>"Exalted Blade (Weapon)"</code>
|-
| <code>Mastery</code> || Number (integer) || ❌ || [[Mastery Rank]] requirement || <code>5</code>
|-
| <code>MeleeRange</code> || Number (float) || ✔️ || Melee's base attack range in meters || <code>2</code>
|-
| <code>Name</code> || String || ❌ || Weapon's name || <code>"Galatine Prime"</code>
|-
| <code>Polarities</code> || Table (array of strings) || ❌ || Full names of the weapon's non-Universal [[polarity|polarities]] || <code>{ "Naramon", "Madurai" }</code>
|-
| <code>SlamAttack</code> || Number (float) || ✔️ || Melee's base normal slam direct hit damage || <code>642</code>
|-
| <code>SlamElement</code> || String || ❌ || Melee's base normal slam direct hit damage type || <code>"Heat"</code>
|-
| <code>SlamRadialDmg</code> || Number (float) || ✔️ || Melee's base normal slam radial damage || <code>214</code>
|-
| <code>SlamRadialElement</code> || String || ❌ || Melee's base normal slam radial attack damage type || <code>"Heat"</code>
|-
| <code>SlamRadialProcs</code> || Table (array of strings) || ❌ || Melee's base normal slam radial attack forced proc(s) || <code>{ "Heat" }</code>
|-
| <code>SlamRadius</code> || Number (integer) || ✔️ || Melee's base normal slam radius in meters || <code>7</code>
|-
| <code>SlideAttack</code> || Number (float) || ✔️ || Melee's base slide attack damage || <code>100</code>
|-
| <code>SlamElement</code> || String || ❌ || Melee's base slide attack damage type || <code>"Toxin"</code>
|-
| <code>Slot</code> || String || ❌ || The weapon slot that the weapon can be equipped on; in the case of [[Exalted Weapon]]s, it is just their modding class || <code>"Melee"</code>
|-
| <code>StancePolarity</code> || String || ❌ || Polarity on [[Stance]] slot || <code>"Madurai"</code>
|-
| <code>Traits</code> || Table (array of strings) || ❌ || Gun's categorical traits || <code>{ "Grineer", "Wraith" }</code>
|-
|}

==For Module Use==
{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>_IgnoreEntry</code> || Boolean || ❌ || For module use, indicates that this weapon table entry is special and should ignored when parsing table entries || <code>true</code>
|-
| <code>_IgnoreInCSV</code> || Boolean || ❌ || For module use, indicates that this weapon table entry should be ignored when outputting CSV (via [[Module:Weapons/csv]]) || <code>true</code>
|-
| <code>_TooltipAttackDisplay</code> || Number || ❌ || For module use, tells what table entry in <code>Attack</code> table to use when processing weapon tooltips and comparing weapon variants in Comparison sections; <code>1</code> will be used if no value is assigned || <code>4</code>
|-
|}

==Weapon Data==