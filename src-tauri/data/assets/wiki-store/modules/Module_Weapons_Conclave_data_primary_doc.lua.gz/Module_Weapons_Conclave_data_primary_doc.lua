Database of [[WARFRAME]]'s [[Primary Weapon]]s in [[Conclave]] (PvP).

{{Transclude|Module:Weapons/Conclave/data/doc}}

[[Category:Databases]]