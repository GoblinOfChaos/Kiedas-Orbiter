Database of [[WARFRAME]]'s [[companion]] [[weapons]].

{{Transclude|Module:Weapons/data/doc}}

[[Category:Databases]]