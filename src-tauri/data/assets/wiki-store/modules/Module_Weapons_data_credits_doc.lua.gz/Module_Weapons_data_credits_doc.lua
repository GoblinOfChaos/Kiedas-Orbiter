WIP database for storing the data on the designers behind the weapons.
{{LatestEdit}}
==Credits Entry Schema==
<syntaxhighlight lang="lua">
	["Weapon Internal Name"] = {
		Animator = "",
		ConceptArtist = "",
		Modeller = "",
		SoundDesigner = "",
		SourceLink = "URL",
		SourceArchive = "URL"
	},
</syntaxhighlight>

{| class="wikitable sortable"
|-
! Key/Column Name !! Data Type || Required? || Explanation/Description || Example(s)
|-
| <code>Animator</code> || String or Table (of strings) || ❌ || Weapon animator(s) || <code></code>
|-
| <code>ConceptArtist</code> || String or Table (of strings) || ❌ || Weapon concept artist(s) || <code>""</code>
|-
| <code>Modeller</code> || String or Table (of strings) || ❌ || Weapon modeller(s) || <code>""</code>
|-
| <code>SoundDesigner</code> || String or Table (of strings) || ❌ || Weapon sound designer(s) || <code>""</code>
|-
| <code>SourceLink</code> || String or Table (of strings) || ✔️ || URL(s) that provide proof of work such as those on artstation.com or from official [[Devstreams]] || <code>"https://www.artstation.com/artwork/3dDJlm"</code>
|-
| <code>SourceArchive</code> || String or Table (of strings) || ✔️ || Archive link(s) to <code>SourceLink</code> || <code>""</code>
|-
|}

==Data==