Database of [[WARFRAME]]'s miscellaneous [[weapons]]. These do not necessarily have to be accessible by players.

{{Transclude|Module:Weapons/data/doc}}

[[Category:Databases]]