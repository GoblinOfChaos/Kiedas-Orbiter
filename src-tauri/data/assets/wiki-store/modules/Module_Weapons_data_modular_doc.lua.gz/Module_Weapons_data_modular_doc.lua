Database for [[WARFRAME]]'s [[:Category:Modular Weapons|modular weapons]]. See [[Module:Modular]] and [[Module:Modular/data]] for data on specific modular parts and their stat modifiers.

{{Transclude|Module:Weapons/data/doc}}

[[Category:Databases]]