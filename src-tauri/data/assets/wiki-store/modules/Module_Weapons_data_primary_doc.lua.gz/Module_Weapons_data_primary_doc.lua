Database of [[WARFRAME]]'s [[Primary Weapon]]s.

{{Transclude|Module:Weapons/data/doc}}

[[Category:Databases]]