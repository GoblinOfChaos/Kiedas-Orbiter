Database of [[WARFRAME]]'s [[Railjack]] [[Railjack/Armaments|armaments]].

{{Transclude|Module:Weapons/data/doc}}

[[Category:Databases]]