<pre>{{#invoke:Weapons/data/validate|validateDataTypes}}</pre>
{{CustomCollapsible||validate_data_types}}
{{Column|3|
{{#invoke:Weapons/data/validate|validateDataTypes}}
}}
{{CustomCollapsible/End}}

<pre>{{#invoke:Weapons/data/validate|checkForMissingData}}</pre>
{{CustomCollapsible||check_missing_data}}
{{Column|3|
{{#invoke:Weapons/data/validate|checkForMissingData}}
}}
{{CustomCollapsible/End}}

<pre>{{#invoke:Weapons/data/validate|validateAttacks}}</pre>
{{CustomCollapsible||validate_attacks}}
{{Column|3|
{{#invoke:Weapons/data/validate|validateAttacks}}
}}
{{CustomCollapsible/End}}

<pre>{{#invoke:Weapons/data/validate|validateRequiredKeys}}</pre>
{{Column|3|
{{#invoke:Weapons/data/validate|validateRequiredKeys}}
}}