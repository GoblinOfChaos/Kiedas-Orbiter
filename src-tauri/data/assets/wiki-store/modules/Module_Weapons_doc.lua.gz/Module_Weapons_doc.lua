<onlyinclude>
{{Docbunto|ulist=1|sort=0|noluaref=1|preface=
== Usage ==
=== Template ===
In template and articles: <code><nowiki>{{#invoke:Weapons|function|input1|input2|...}}</nowiki></code>

== Navigation ==
Quick navigation to submodules:
*[[Module:Weapons/Conclave/data]] - data store for [[Conclave]]-specific weapon stats
*[[Module:Weapons/characteristics]] - for generating advantage/disadvantage text under Characteristic sections of weapon articles based on stored data in [[Module:Weapons/data]]
*[[Module:Weapons/compare]] - for generating text for side-by-side comparison between two weapons
*[[Module:Weapons/comptable]]
*[[Module:Weapons/csv]] - for generating CSV output of a subset of weapon stats as stored in [[Module:Weapons/data]]
*[[Module:Weapons/data]] - main submodule for weapon data store
**[[Module:Weapons/data/credits]] - in-progress data store for mapping weapons to their development credits
**[[Module:Weapons/data/dev]] - sandbox page for data store
*[[Module:Weapons/data/validate]] - data validation scripts
*[[Module:Weapons/dev]] - sandbox page
*[[Module:Weapons/infobox]] - builds weapon infoboxes
*[[Module:Weapons/nav]] - builds weapon navigation box as seen at the bottom of weapon articles
*[[Module:Weapons/ppdata]] - preprocessed weapon data containing statistical 
**[[Module:Weapons/preprocess]] - script for seeding ppdata
**[[Module:Weapons/ppdata/seeder]] - archived script for seeding ppdata
*[[Module:Weapons/testcases]] - unit test suite for [[Module:Weapons]]

== Product Backlog ==
{{(!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Last Update
{{!}}-
{{ProjectTableRow
|name=[[Module:StatObject]] as OOP paradigm
|type=Dev
|status=Planning
|priority=Low
|contact=
|desc=
Currently our usage of [[Module:StatObject]] is as a static class with <code>statRead</code> and <code>statFormat</code> functions. Update [[Module:Weapons]] and [[Module:StatObject]] so we can 'instantiate' an actual StatObject object that takes in a weapon table entry as an argument. This way we can just do:
<syntaxhighlight lang="lua">
local StatObject = require('Module:StatObject') -- Base class
local WeaponData = require('Module:Weapons/data')

-- Doing some metaprogramming to extend functionality of StatObject class
StatObject.default = {
    Name = { nil, 'Weapon Name: %s' },  -- Sample definition for Name field getter/formatter
    ...
}

local BratonStatObject = StatObject(WeaponData['Braton'])

-- Get raw Name value "Braton" instead of StatObject.statRead(WeaponData['Braton'], 'Name')
local name = BratonStatObject.Name
-- Get formatted Name value "Weapon Name: Braton" (as defined in StatObject.default) instead of StatObject.statFormat(WeaponData['Braton'], 'Name')
print(BratonStatObject.Name)
mw.log(BratonStatObject.Name)
local formattedName = tostring(BratonStatObject.Name)
-- If the above is not possible in Lua then maybe add a __call metamethod to Name key to return its formatted value
formattedName = BratonStatObject.Name()
-- Or add a format() function to instantiated StatObject's metatable, passing in key name as argument
formattedName = BratonStatObject:format('Name')
</syntaxhighlight>
|start=22:01, 5 December 2022 (UTC)
|end=
}}
{{ProjectTableRow
|name=Include attack name/context in [[Module:Weapons/ppdata]]
|type=Dev
|status=Planning
|priority=Low
|contact=
|desc=
Update [[Module:Weapons/ppdata/seeder]] to add attack names associated with the respective stats used for comparing so that [[Module:Weapons/characteristics]] can add additional context to the stat comparisons. See https://warframe.fandom.com/wiki/Quassus?commentId=4400000000003635575. For {{Weapon|Quassus}}'s case, {{Weapon|Jat Kusar}} has a base 35% crit chance, but since we are comparing against non-normal attacks, {{Weapon|Quassus}}'s Ethereal Daggers will have second highest crit chance (30%) behind {{Weapon|Tenet Exec}}'s slam shockwaves (38%).
|start=22:09, 5 August 2022 (UTC)
|end=
}}
{{ProjectTableRow
|name=Weapon and Attack classes
|type=Refactor and Dev
|status=Planning
|priority=Low
|contact=
|desc=
*Create a new Weapon and Attack class that can be instantiated by passing in a weapon table entry and attack table entry respectively. Each of these classes should contain a <code>statRead()</code> and <code>statFormat()</code> function that can be called to return an particular weapon stat, aggregate data, or computed stat based on <code>/data</code> contents.
|start=21:18, 18 January 2022 (UTC)
|end=
}}
{{ProjectTableRow
|name=<code>ExplosionDelay</code> key
|type=Refactor
|status=Planning
|priority=Low
|contact=
|desc=
*Update this to store a table with two values: shortest delay time and longest delay time. This is to support {{Weapon|Kompressa}}'s variable delay time. For weapons that have a single delay time, use the same value for both table elements.
|start=22:10, 6 January 2022 (UTC)
|end=
}}
{{ProjectTableRow
|name=<code>Reload</code> key
|type=Refactor
|status=Planning
|priority=Low
|contact=
|desc=
*Move <code>Reload</code> key to attack tables? Nagantaka and Ambassador have two different reload times depending on attack.

*21:35, 19 January 2022 (UTC) update: [[User:Gigamicro]] suggests that any duplicate keys nested in Attack table entries should 'override' the base values for the weapon. In this case, add a another <code>Reload</code> key under the appropriate attack that has a different value than the <code>Reload</code> key in the main weapon entry.
|start=
|end=
}}
{{ProjectTableRow
|name=Augments in <code>/data</code>
|type=Refactor
|status=New
|priority=Low
|contact=
|desc=
*Remove weapon augments list from <code>/data</code> and use [[Module:Mods]] and/or [[Module:Mods/data]] instead to fetch augment mods data.
**Would require dev work in M:Mods/data too to index by mod type.
|start=01:37, 31 May 2021 (UTC)
|end=
}}
{{ProjectTableRow
|name=Data validation
|type=Dev/database
|status=Active
|priority=Medium
|contact=
|desc=Create <code>[[Module:Weapons/data/validate]]</code> subpage of <code>/data</code> for data validation functions
*Include type checking for each column/attribute
*Include checking if a table entry has the required keys (the minimum number of keys needed to support basic features in [[Module:Weapons]])
*Include boundary checking for stat values (e.g. <code>CritChance</code> cannot be negative)
|start=01:37, 31 May 2021 (UTC)
|end=23:33, 1 August 2021 (UTC)
}}
{{ProjectTableRow
|name=Error handling
|type=Clean up
|status=New
|priority=Medium
|contact=
|desc=Change all return statements with "ERROR" to either <code>assert()</code> or <code>error()</code> to standardize error handling.
*Error messages should be in the form of "functionName(argument names): argument value 1 is not a valid number".
|start=01:37, 31 May 2021 (UTC)
|end=
}}
{{ProjectTableRow
|name=Update database schema
|type=Database
|status=Active
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=Reworking how attacks are stored in tables for flexibility. Should have one Attack column that contains multiple tables, each representing a unique attack for that weapon. Would probably improve/simplify [[Weapon Comparison]] and [[Template:WeaponInfoboxAutomatic]] in displaying multiple attacks of a weapon. Right now we are hacking the use of <code>ChargeAttack</code> and <code>SecondaryAttack</code> for some attacks that are not necessarily charged or alt-fire (see [[Deconstructor]]'s entry in the database). Also include forced proc data for all possible attacks (e.g. Glaives, some forced Impact weapons, etc.).

23:33, 1 August 2021 (UTC) update: There are lots of changes to these tables as I slowly create validation functions to check what keys-value pairs are needed or not, see documentation in [[Module:Weapons/data/doc]] for possible key-value pairs. Right now, attacks are stored in generic <code>Attack1</code>, <code>Attack2</code>, ... keys when we were changing the names of attack keys (e.g. <code>NormalAttack</code> became <code>Attack1</code>).

21:18, 18 January 2022 (UTC) update: [[User:Gigamicro]] implemented a new <code>attack</code> key (should be named <code>Attacks</code> to match key naming convention) that points to an array of attack tables. <code>Attack1</code> to <code>Attack9</code> keys are still in the data, just we now have a new way of indexing the same attack data by reference.

21:35, 19 January 2022 (UTC) update: <code>Attack1</code> to <code>Attack9</code> are now depreciated and removed from data tables. All optional keys are now explicitly stored in database (but are still optional b/c we set default values for getter functions in [[Module:Weapons]]. Some error clean up is still needed but for the most part, all weapon submodules and weapon tooltips should properly use <code>Attacks</code> table.
|start=01:50, 31 May 2021 (UTC)
|end=21:35, 19 January 2022 (UTC)
}}
{{ProjectTableRow
|name=Unit tests
|type=Testing
|status=Archived
|priority=High
|contact=[[User:Cephalon Scientia]]
|desc=Add unit tests in [[Module:Weapons/testcases]] for each function in [[Module:Weapons]]. See [[Module:Math/testcases]] for examples and https://dev.fandom.com/wiki/Global_Lua_Modules/Testharness for documentation on how to format tests.

20:29, 31 July 2021 (UTC) update: Do not feel like it is appropriate to add unit tests using [[Module:TestHarness]] to most of the functions in this module since they mostly pertain to building wikitext to display to the reader. We can add a [[Module:Weapons/testcases]] subpage for visual tests to ensure rendered wikitext is not broken. Otherwise, I think it is more important to validate the data in [[Module:Weapons/data]] which are being formatted and displayed to the reader.
|start=02:01, 31 May 2021 (UTC)
|end=20:29, 31 July 2021 (UTC)
}}
{{!)}}

==Finished Issues==
{{(!}}class="wikitable sortable" width=100% style="text-align:center;"
{{!}}-
! style="width:5%;" {{!}} Name
! style="width:2.5%;" {{!}} Type
! style="width:2.5%;" {{!}} Status
! style="width:2.5%;" {{!}} Priority
! style="width:2.5%;" {{!}} Assignee
! style="width:25%;" {{!}} Description
! Date Issued
! Completion Date
{{!}}-
{{ProjectTableRow
|name=Advantages/disadvantages
|type=Refactor
|status=Completed
|priority=Low
|contact=[[User:Cephalon Scientia]]
|desc=
*Move advantages/disadvantages builder to a new submodule page for organization.
|start=06:05, 3 October 2021 (UTC)
|end=17:47, 2 November 2021 (UTC)
}}
{{ProjectTableRow
|name=Railjack Weapons
|type=Dev/Edit/Database
|status=Long-term support
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=
*Officially support Railjack weapons being in database. This allows Railjack weapons to make use of our infobox builder and do automatic comparisons.
*Update <code>/data</code> with current user-contributed data in [[Railjack/Armaments]]

02:32, 6 September 2021 (UTC) update: Added most Railjack turrets and ordnances to <code>/data</code>. Missing Zetki Photor MK II, Zetki Carcinnox MK II, and Zetki Apoc MK I. First two are not obtainable in-game at this time since they are missing from drop tables, but are still in players' inventories.

00:12, 29 September 2021 (UTC) update: Added Zetki Photor MK II, Zetki Carcinnox MK II, and Zetki Apoc MK I stats according to the [[Mobile Export]].
|start=22:17, 2 August 2021 (UTC)
|end=00:12, 29 September 2021 (UTC)
}}
{{ProjectTableRow
|name=Update Conclave database schema
|type=Database
|status=Long-term support
|priority=Low
|contact=[[User:Cephalon Scientia]]
|desc=Remove keys that represent PvE stats as they are irrelevant to PvP. Most other key-value pairs (except those in attack tables) are shared with <code>/data</code> and can be looped through to add shared key-value pairs.
|start=06:18, 10 August 2021 (UTC)
|end=03:10, 16 August 2021 (UTC)
}}
{{ProjectTableRow
|name=Clean up
|type=Clean up
|status=Completed
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=
*Remove unused functions. Also remove redundant functions that can be otherwise be used as as simple condition check (e.g. <code>HasAttack()</code> and <code>DoNotHasAttack()</code>).
*Standardize styling to [[WARFRAME Wiki:Programming Standards]].
|start=01:37, 31 May 2021 (UTC)
|end=06:20, 10 August 2021 (UTC)
}}
{{ProjectTableRow
|name=Refactoring
|type=Refactor
|status=Long-term support
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=Refactor these functionalities for code reuse, better performance, better maintainability, and etc.:
*<s>Weapon comparison tables (see [[Weapon Comparison]])</s> ✔️
**<s>Includes [[Conclave]]</s> ✔️
**00:19, 7 August 2021 (UTC) update: Weapon comparison tables are moved to [[Module:Weapons/comptable]] submodule for seperations of concerns design
*<s>Polarity table (see [[Polarity]])</s> ✔️
*<s>Mastery table (see [[Mastery Rank]])</s> ✔️
*<s>Highest physical damage type table (see [[Damage/Impact Damage]])</s> ✔️
*<s>Getter function(s) for weapon statistics/properties</s> ✔️
*<s>Weapon gallery</s> ✔️
|start=17:43, 3 June 2021 (UTC)
|end=00:19, 7 August 2021 (UTC)
}}
{{ProjectTableRow
|name=Documentation
|type=Documentation
|status=New
|priority=High
|contact=
|desc=Add LuaDoc-style documentation for all functions.
|start=01:37, 31 May 2021 (UTC)
|end=06:35, 31 July 2021 (UTC)
}}
{{ProjectTableRow
|name=Comparison tables and comparing two weapons
|type=Refactor
|status=Completed
|priority=High
|contact=[[User:Cephalon Scientia]]
|desc=Refactor <code>BuildCompRow()</code>, <code>BuildCompTable()</code>, <code>BuildGunComparisonString</code>, and their sister functions.
*<code>BuildCompRow()</code> should have at max 2 nested if/else blocks
*Do not remove functions such as <code>getCompTableGuns(frame)</code> and <code>p.getCompTableArchGuns(frame)</code> as those will be exposed to articles. <s>Do not think there is a way to pass in table arguments in <code><nowiki>{{#invoke:}}</nowiki></code> calls so we could not have a single table builder function.</s> Not true, can pass a multitude of named arguments and use <code>frame.args['argName']</code> to get those arguments.

20:53, 29 July 2021 (UTC) update: We now use <code>getValue(Weapon, keyName, attackName)</code> and dictionaries (e.g. <code>GUN_KEY_MAP</code>) that contain simple getter functions to get specific weapon stat values. No more complicated nested if/else blocks.
|start=01:37, 31 May 2021 (UTC)
|end=20:53, 29 July 2021 (UTC)
}}
{{ProjectTableRow
|name=<code>getAttackValue()</code>
|type=Refactor
|status=Completed
|priority=Medium
|contact=[[User:Cephalon Scientia]]
|desc=Refactor <code>getAttackValue(Weapon, Attack, ValName, giveDefault, asString, forTable)</code>.
*If/else blocks can be converted into a dictionary or objects that can be constructed through the use of tables and metatables.

20:53, 29 July 2021 (UTC) update: <code>getAttackValue()</code> has been removed and its functionality is moved to <code>getValue(Weapon, keyName, attackName)</code> using dictionaries (e.g. <code>GUN_KEY_MAP</code>) that contain simple getter functions.
|start=01:37, 31 May 2021 (UTC)
|end=20:53, 29 July 2021 (UTC)
}}
{{ProjectTableRow
|name=<code>p.getRivenDispositionTable()</code>
|type=Refactor
|status=Completed
|priority=Low
|contact=
|desc=
*Optimized <code>p.getRivenDispositionTable()</code> so we don't literally have to perform over a thousand loops through each exact possible Disposition value to find weapons with that exact Disposition.
*Remove <code>p.getRivenDispositionList()</code> since it is not invoked by itself on pages and was used by old <code>p.getRivenDispositionTable()</code>.
|start=3:42, 21 July 2021 (UTC)
|end=4:49, 21 July 2021 (UTC)
}}
{{ProjectTableRow
|name=<code>p.buildDamageTypeTable(frame)</code>
|type=Refactor
|status=Completed
|priority=Low
|contact=
|desc=
*Use multi-line strings for table building.
*Updated validate function to only get non-Kitgun weapons and only display damage type distribution of <code>Attack1</code> or the attack listed in <code>TooltipAttackDisplay</code>.
*Refactored to modern programming standards.
|start=01:37, 31 May 2021 (UTC)
|end=21:54, 20 July 2021 (UTC)
}}
{{ProjectTableRow
|name=<code>p.buildAutoboxCategories(frame)</code>
|type=Refactor
|status=Completed
|priority=Medium
|contact=
|desc=Implement a map/dictionary for mapping traits and trigger types to category link.
|start=01:37, 31 May 2021 (UTC)
|end=21:54, 20 July 2021 (UTC)
}}
{{ProjectTableRow
|name=Weapon nav
|type=Dev
|status=Completed
|priority=Medium
|contact=[[User:FINNER]]
|desc=Add a new function that constructs the same navbox as [[Template:WeaponNav]]. Goal is to reduce memory used by calling [[Template:Weapon]] 400+ times on every weapon page as well as automating navbox updates whenever a new weapon is added. Right now, [[Template:Weapon]] uses ~11MB, sometimes ~20MB on pages like [[Volnus Prime]].

Weapon navigation box generator resides in [[Module:Weapons/nav]].
|start=03:24, 5 June 2021 (UTC)
|end=[https://warframe.fandom.com/wiki/Module:Weapons/nav 6:07, 7 June 2021 (UTC)]
}}
{{ProjectTableRow
|name=Weapon infobox
|type=Dev
|status=Completed
|priority=Medium
|contact=[[User:FINNER]]
|desc=Migrate wikitext from [[Template:WeaponInfoboxAutomatic]] into a infobox builder function.
*This will probably remove the need for <code>getValue()</code> and their equilvalents.

Weapon infobox generator resides in [[Module:Weapons/infobox]].
|start=01:37, 31 May 2021 (UTC)
|end=[https://warframe.fandom.com/wiki/Module:Weapons/infobox?oldid=2206329 22:14, 8 June 2021 (UTC)]
}}
{{ProjectTableRow
|name=High lua memory usage
|type=Dev/Debugging
|status=Completed
|priority=High
|contact=[[User:FINNER]]
|desc=Some weapon pages have unusually high memory usage for Lua scripts, this will be problematic the moment we add new weapons to [[Template:WeaponNav]]:
*[[Latron Prime]]: 43.13 MB/50 MB
*[[Astilla Prime]]: 50 MB/50 MB
*[[Volnus Prime]]: 45.11 MB/50 MB
*[[Rubico Prime]]: 50 MB/50 MB
*[[Soma Prime]]: 49.63 MB/50 MB

Normally, memory usage is ~37 MB which is why this is odd.

This issue has been fixed when we now generate [[Template:WeaponNav]] using this module, instead of calling [[Template:Weapon]] 400+ times per page.
|start=02:04, 1 June 2021 (UTC)
|end=18:03, 7 June 2021 (UTC)
}}
{{!)}}

== Forked Repos ==
*https://warframe.fandom.com/fr/wiki/Module:Weapons
*https://warframe.fandom.com/es/wiki/M%C3%B3dulo:Weapons
*https://warframe.fandom.com/it/wiki/Modulo:Weapons
*https://warframe.fandom.com/de/wiki/Modul:Weapons
*https://warframe.fandom.com/pt-br/wiki/M%C3%B3dulo:Weapons
*https://warframe.fandom.com/zh-tw/wiki/%E6%A8%A1%E7%B5%84:Weapons
*https://warframe.huijiwiki.com/wiki/%E6%A8%A1%E5%9D%97:Weapons#
}}
</onlyinclude>