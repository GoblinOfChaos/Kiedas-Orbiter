Preprocessed version of [[Module:Weapons/data]] in the form of a [[wikipedia:Lookup table|lookup table]]. Contains top three values of a particular stat (e.g. crit chance) per weapon class (e.g. Arch-guns) and the weapons that have those values as well as the stat values that are boundaries for the following percentiles:
<pre>
90-100% - "Very high"
75-90% - "High"
60-75% - "Above average"
45-60% - "Average", does not display anything
30-45% - "Below average"
15-30% - "Low"
0-15% - "Very low"
</pre>
This classification will be used on most Characteristics sections on weapon articles when comparing a weapon's advantages and disadvantages to other weapons in the same domain.

To update the database seeder script, go to [[Module:Weapons/preprocess]].

See [[WARFRAME Wiki:Stat Comparison]] for the design document on this topic.
{{LatestEdit}}
{{Tocleft|limit=3}}
{{clr}}
==Computed Values In Human-Readable Format==
{{#invoke:Weapons/preprocess|printPPData}}

==Generated Data for Copypasta==
If you want to update the values that are used for stat comparison/rankings copy/paste the below Lua code into M:Weapons/ppdata. Please do this every time a new weapon is released or when a major balance change occurs.
{{CustomCollapsible|Data to copy into M:Weapons/ppdata}}
{{#invoke:Weapons/preprocess|ppData}}
{{CustomCollapsible/End}}

=Data=
[[Category:Databases]]
__FORCETOC__