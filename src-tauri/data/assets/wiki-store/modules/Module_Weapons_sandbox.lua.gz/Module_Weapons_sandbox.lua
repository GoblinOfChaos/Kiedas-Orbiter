local Table = require([[Module:Table]])
local Weapons = Table.loadData([[Module:Weapons/data/primary]])
local LuaSerializer = require([[Module:LuaSerializer]])

local p = {}

-- Adds AttackIndex and AttackParentIndex to every weapon's Attacks table.
-- Parent inference rule:
--   Projectile → parent
--   AoE → child of the nearest preceding Projectile attack

for weaponName, weapon in pairs(Weapons) do
    if weapon.Attacks then
        local lastProjectileIndex = nil

        for i, attack in ipairs(weapon.Attacks) do
            -- Assign AttackIndex
            attack.AttackIndex = i

            -- Detect direct-hit vs AoE
            local shotType = attack.ShotType and attack.ShotType:lower()

            if shotType == "projectile" then
                -- This is a direct hit; becomes the parent for following AoE
                lastProjectileIndex = i
                attack.AttackParentIndex = nil

            elseif shotType == "aoe" then
                -- Explosion inherits the last projectile as parent
                attack.AttackParentIndex = lastProjectileIndex

            else
                -- Unknown shot type; no parent
                attack.AttackParentIndex = nil
            end
        end
    end
end

p.Weapons = LuaSerializer._serializeTable(Weapons)

return p