<includeonly></includeonly>
<noinclude>[[Category:Lua test suites]]</noinclude>